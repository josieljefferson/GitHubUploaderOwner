#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
=============================================================
                    📺 EPG GENERATOR 4.3
=============================================================

Gera automaticamente:

    output/epg.xml
    output/epg.xml.gz
    output/playlist.m3u
    output/epg_aliases.json
    output/epg-report.json

Fontes EPG:

    1. mi.tv
    2. Guia de TV
    3. IPTV-ORG

LOGOS:

    1. Guia de TV
    2. mi.tv

Os logos são descobertos automaticamente a partir das
páginas dos canais.

Não é necessário preencher manualmente:

    "logo": ""

no channels.json.

=============================================================
"""

from __future__ import annotations

import concurrent.futures
import gzip
import html
import json
import logging
import os
import re
import sys
import time
import unicodedata

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote, urljoin, urlparse

import requests
from bs4 import BeautifulSoup


# ============================================================
# CONFIGURAÇÃO
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

CONFIG_FILE = ROOT / "config" / "channels.json"

OUTPUT_DIR = ROOT / "output"

EPG_XML = OUTPUT_DIR / "epg.xml"
EPG_GZ = OUTPUT_DIR / "epg.xml.gz"
PLAYLIST_M3U = OUTPUT_DIR / "playlist.m3u"
ALIASES_JSON = OUTPUT_DIR / "epg_aliases.json"
REPORT_JSON = OUTPUT_DIR / "epg-report.json"


# ------------------------------------------------------------
# URLs EPG
# ------------------------------------------------------------

MITV_SITEMAP = "https://mi.tv/br/sitemap"

GUIDETV_HOME = [
    "https://www.guiadetv.com/",
    "https://www.guiadetv.com/canais",
    "https://www.guiadetv.com/categorias/canais",
    "https://www.guiadetv.com/categorias/filmes-e-series",
]

GUIDETV_API_NOW = "https://apiv1.guiadetv.com/programacao"

IPTV_ORG_BR = "https://iptv-org.github.io/epg/guides/br.xml"


# ------------------------------------------------------------
# URL pública da playlist/EPG
# ------------------------------------------------------------

PLAYLIST_EPG_URL = (
    "https://raw.githubusercontent.com/josieljefferson/"
    "channels/main/output/epg.xml.gz"
)


# ------------------------------------------------------------
# LOGOS
# ------------------------------------------------------------

LOGO_SOURCES = [
    "guiadetv",
    "mitv",
]

LOGO_TIMEOUT = int(
    os.getenv("EPG_LOGO_TIMEOUT", "20000")
)

LOGO_RETRIES = int(
    os.getenv("EPG_LOGO_RETRIES", "1")
)


# ------------------------------------------------------------
# HTTP
# ------------------------------------------------------------

USER_AGENT = os.getenv(
    "EPG_USER_AGENT",
    (
        "Mozilla/5.0 (Linux; Android 10; K) "
        "AppleWebKit/537.36 "
        "(KHTML, like Gecko) "
        "Chrome/140.0.0.0 Mobile Safari/537.36"
    ),
)

HTTP_TIMEOUT = int(
    os.getenv("EPG_HTTP_TIMEOUT", "30000")
)

HTTP_RETRIES = int(
    os.getenv("EPG_HTTP_RETRIES", "3")
)


# ------------------------------------------------------------
# GERAL
# ------------------------------------------------------------

DAYS = int(
    os.getenv("EPG_DAYS", "2")
)

MAX_WORKERS = int(
    os.getenv("EPG_MAX_WORKERS", "8")
)

MIN_PROGRAMS = int(
    os.getenv("EPG_MIN_PROGRAMS", "1")
)

DEBUG_SAVE_HTML = os.getenv(
    "EPG_DEBUG_SAVE_HTML",
    "0",
).lower() in {
    "1",
    "true",
    "yes",
    "on",
}


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

LOGGER = logging.getLogger("EPG")


# ============================================================
# HTTP SESSION
# ============================================================

SESSION = requests.Session()

SESSION.headers.update(
    {
        "User-Agent": USER_AGENT,
        "Accept": (
            "text/html,application/xhtml+xml,"
            "application/xml;q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
    }
)


# ============================================================
# DATACLASS
# ============================================================

@dataclass
class Program:
    title: str
    start: datetime
    stop: datetime
    description: str = ""
    category: str = ""
    icon: str = ""


@dataclass
class Channel:
    id: str
    name: str
    logo: str = ""
    group: str = "Brasil"
    aliases: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    urls: dict[str, str] = field(default_factory=dict)
    stream_url: str = ""


# ============================================================
# UTILITÁRIOS
# ============================================================

def normalize_text(value: Any) -> str:
    if value is None:
        return ""

    value = str(value)

    value = html.unescape(value)

    value = unicodedata.normalize(
        "NFKD",
        value,
    )

    value = "".join(
        char
        for char in value
        if not unicodedata.combining(char)
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    )

    return value.strip()


def normalize_name(value: Any) -> str:
    value = normalize_text(value).lower()

    value = value.replace("&", " e ")

    value = re.sub(
        r"\b(hd|fhd|uhd|4k|sd|tv|canal)\b",
        " ",
        value,
    )

    value = re.sub(
        r"[^a-z0-9]+",
        " ",
        value,
    )

    return re.sub(
        r"\s+",
        " ",
        value,
    ).strip()


def slugify(value: Any) -> str:
    value = normalize_text(value).lower()

    value = re.sub(
        r"[^a-z0-9]+",
        "-",
        value,
    )

    value = re.sub(
        r"-+",
        "-",
        value,
    )

    return value.strip("-")


def unique_preserve_order(items):
    result = []
    seen = set()

    for item in items:
        item = normalize_text(item)

        if not item:
            continue

        key = item.lower()

        if key in seen:
            continue

        seen.add(key)
        result.append(item)

    return result


def xml_escape(value: Any) -> str:
    return html.escape(
        str(value or ""),
        quote=True,
    )


def safe_json_dump(data: Any, path: Path):
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=2,
        )


def env_int(
    name: str,
    default: int,
    minimum: int = 0,
) -> int:
    try:
        value = int(
            os.getenv(name, str(default))
        )
    except ValueError:
        value = default

    return max(
        minimum,
        value,
    )


# ============================================================
# DATA / CONFIG
# ============================================================

def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {CONFIG_FILE}"
        )

    with CONFIG_FILE.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(file)


def load_channels() -> list[Channel]:
    config = load_config()

    raw_channels = config.get(
        "channels",
        [],
    )

    channels: list[Channel] = []

    for item in raw_channels:
        if not isinstance(item, dict):
            continue

        channel_id = normalize_text(
            item.get("id")
        )

        name = normalize_text(
            item.get("name")
        )

        if not channel_id or not name:
            continue

        aliases = item.get(
            "aliases",
            [],
        )

        if isinstance(
            aliases,
            str,
        ):
            aliases = [aliases]

        sources = item.get(
            "sources",
            [],
        )

        if isinstance(
            sources,
            str,
        ):
            sources = [sources]

        urls = item.get(
            "urls",
            {},
        )

        if not isinstance(
            urls,
            dict,
        ):
            urls = {}

        stream_url = normalize_text(
            item.get(
                "url",
                item.get(
                    "stream_url",
                    "",
                ),
            )
        )

        channel = Channel(
            id=channel_id,
            name=name,
            logo=normalize_text(
                item.get("logo", "")
            ),
            group=normalize_text(
                item.get(
                    "group",
                    "Brasil",
                )
            ) or "Brasil",
            aliases=unique_preserve_order(
                aliases
            ),
            sources=unique_preserve_order(
                sources
            ),
            urls={
                str(k): normalize_text(v)
                for k, v in urls.items()
                if normalize_text(v)
            },
            stream_url=stream_url,
        )

        channels.append(channel)

    return channels


# ============================================================
# HTTP
# ============================================================

def http_get(
    url: str,
    timeout: int | None = None,
    retries: int | None = None,
    allow_redirects: bool = True,
) -> requests.Response | None:

    timeout = timeout or HTTP_TIMEOUT
    retries = HTTP_RETRIES if retries is None else retries

    last_error = None

    for attempt in range(
        retries + 1
    ):
        try:
            response = SESSION.get(
                url,
                timeout=timeout / 1000,
                allow_redirects=allow_redirects,
            )

            response.raise_for_status()

            return response

        except Exception as exc:
            last_error = exc

            if attempt < retries:
                time.sleep(
                    1.0 * (attempt + 1)
                )

    LOGGER.warning(
        "⚠️ Falha ao acessar %s: %s",
        url,
        last_error,
    )

    return None


# ============================================================
# DISCOVERY — GUIA DE TV
# ============================================================

def discover_guiadetv() -> dict[str, str]:
    discovered: dict[str, str] = {}

    LOGGER.info(
        "🔎 Procurando canais no Guia de TV..."
    )

    for home_url in GUIDETV_HOME:
        response = http_get(
            home_url,
            timeout=HTTP_TIMEOUT,
            retries=HTTP_RETRIES,
        )

        if not response:
            continue

        soup = BeautifulSoup(
            response.text,
            "html.parser",
        )

        for anchor in soup.find_all(
            "a",
            href=True,
        ):
            href = normalize_text(
                anchor.get("href")
            )

            if not href:
                continue

            absolute_url = urljoin(
                response.url,
                href,
            )

            parsed = urlparse(
                absolute_url
            )

            path = parsed.path.lower()

            if "/canal/" not in path:
                continue

            text = normalize_text(
                anchor.get_text(
                    " ",
                    strip=True,
                )
            )

            if not text:
                text = (
                    anchor.get("title")
                    or ""
                )

            if not text:
                continue

            key = normalize_name(text)

            if key:
                discovered[key] = absolute_url

    LOGGER.info(
        "📺 Guia de TV: %d canais descobertos",
        len(discovered),
    )

    return discovered


# ============================================================
# DISCOVERY — MI.TV
# ============================================================

def discover_mitv() -> dict[str, str]:
    discovered: dict[str, str] = {}

    LOGGER.info(
        "🔎 Procurando canais no mi.tv..."
    )

    response = http_get(
        MITV_SITEMAP,
        timeout=HTTP_TIMEOUT,
        retries=HTTP_RETRIES,
    )

    if not response:
        return discovered

    soup = BeautifulSoup(
        response.text,
        "html.parser",
    )

    for anchor in soup.find_all(
        "a",
        href=True,
    ):
        href = normalize_text(
            anchor.get("href")
        )

        if not href:
            continue

        absolute_url = urljoin(
            response.url,
            href,
        )

        parsed = urlparse(
            absolute_url
        )

        path = parsed.path.lower()

        if "/br/canais/" not in path:
            continue

        text = normalize_text(
            anchor.get_text(
                " ",
                strip=True,
            )
        )

        if not text:
            text = (
                anchor.get("title")
                or ""
            )

        if not text:
            continue

        key = normalize_name(text)

        if key:
            discovered[key] = absolute_url

    LOGGER.info(
        "📺 mi.tv: %d canais descobertos",
        len(discovered),
    )

    return discovered


# ============================================================
# MATCHING
# ============================================================

def channel_search_names(
    channel: Channel,
) -> list[str]:

    names = [
        channel.name,
        channel.id,
        *channel.aliases,
    ]

    result = []

    for name in names:
        name = normalize_text(name)

        if not name:
            continue

        result.append(name)

        cleaned = re.sub(
            r"\b(HD|FHD|UHD|4K|SD)\b",
            "",
            name,
            flags=re.I,
        )

        if cleaned.strip():
            result.append(
                cleaned.strip()
            )

    return unique_preserve_order(
        result
    )


def match_discovered_url(
    channel: Channel,
    discovered: dict[str, str],
) -> str:

    if not discovered:
        return ""

    candidates = [
        normalize_name(name)
        for name in channel_search_names(
            channel
        )
    ]

    candidates = [
        value
        for value in candidates
        if value
    ]

    # --------------------------------------------------------
    # 1. Correspondência exata
    # --------------------------------------------------------

    for candidate in candidates:
        if candidate in discovered:
            return discovered[candidate]

    # --------------------------------------------------------
    # 2. Correspondência por palavras
    # --------------------------------------------------------

    for candidate in candidates:
        candidate_words = set(
            candidate.split()
        )

        if len(candidate_words) < 1:
            continue

        for key, url in discovered.items():
            key_words = set(
                key.split()
            )

            if not key_words:
                continue

            common = (
                candidate_words
                & key_words
            )

            if not common:
                continue

            ratio = (
                len(common)
                / max(
                    len(candidate_words),
                    len(key_words),
                )
            )

            if ratio >= 0.5:
                return url

    return ""


# ============================================================
# URLS DE PÁGINA PARA LOGO
# ============================================================

def logo_slug_variants(
    channel: Channel,
) -> list[str]:

    values = []

    for name in channel_search_names(
        channel
    ):
        slug = slugify(name)

        if slug:
            values.append(slug)

    return unique_preserve_order(
        values
    )


def build_logo_page_candidates(
    channel: Channel,
    source: str,
    discovered_mitv: dict[str, str],
    discovered_guiadetv: dict[str, str],
) -> list[str]:

    candidates = []

    # --------------------------------------------------------
    # URL explicitamente configurada
    # --------------------------------------------------------

    explicit = normalize_text(
        channel.urls.get(source, "")
    )

    if explicit:
        candidates.append(
            explicit
        )

    # --------------------------------------------------------
    # URL descoberta
    # --------------------------------------------------------

    discovered = (
        discovered_guiadetv
        if source == "guiadetv"
        else discovered_mitv
    )

    discovered_url = match_discovered_url(
        channel,
        discovered,
    )

    if discovered_url:
        candidates.append(
            discovered_url
        )

    # --------------------------------------------------------
    # URLs construídas
    # --------------------------------------------------------

    slugs = logo_slug_variants(
        channel
    )

    if source == "mitv":
        for slug in slugs:
            candidates.append(
                f"https://mi.tv/br/canais/{slug}"
            )

    elif source == "guiadetv":
        for slug in slugs:
            candidates.append(
                f"https://www.guiadetv.com/canal/{slug}"
            )

    return unique_preserve_order(
        candidates
    )


# ============================================================
# EXTRAÇÃO DE IMAGEM
# ============================================================

def image_url_from_tag(
    tag,
    page_url: str,
) -> str:

    attributes = [
        "src",
        "data-src",
        "data-original",
        "data-lazy-src",
        "data-image",
        "data-img",
    ]

    for attribute in attributes:
        value = normalize_text(
            tag.get(attribute)
        )

        if value:
            if value.startswith(
                "data:"
            ):
                continue

            return urljoin(
                page_url,
                value,
            )

    srcset = normalize_text(
        tag.get("srcset")
    )

    if srcset:
        parts = [
            item.strip()
            for item in srcset.split(",")
            if item.strip()
        ]

        if parts:
            value = parts[-1].split()[0]

            if value:
                return urljoin(
                    page_url,
                    value,
                )

    return ""


def score_image_candidate(
    url: str,
    tag,
    channel: Channel,
    source: str,
) -> int:

    value = url.lower()

    score = 0

    # --------------------------------------------------------
    # Imagem realmente hospedada no domínio da fonte
    # --------------------------------------------------------

    if source == "mitv":
        if "mi.tv" in value:
            score += 20

    if source == "guiadetv":
        if "guiadetv.com" in value:
            score += 20

    # --------------------------------------------------------
    # Termos relacionados a logo/canal
    # --------------------------------------------------------

    if "logo" in value:
        score += 35

    if "channel" in value:
        score += 15

    if "canal" in value:
        score += 15

    if "station" in value:
        score += 10

    # --------------------------------------------------------
    # Nome do canal
    # --------------------------------------------------------

    channel_terms = set(
        normalize_name(
            channel.name
        ).split()
    )

    url_normalized = normalize_name(
        value
    )

    for term in channel_terms:
        if len(term) >= 3 and term in url_normalized:
            score += 10

    # --------------------------------------------------------
    # ALT / TITLE / CLASS / ID
    # --------------------------------------------------------

    metadata = " ".join(
        [
            normalize_text(
                tag.get("alt")
            ),
            normalize_text(
                tag.get("title")
            ),
            normalize_text(
                tag.get("class")
            ),
            normalize_text(
                tag.get("id")
            ),
        ]
    )

    metadata_normalized = normalize_name(
        metadata
    )

    if "logo" in metadata_normalized:
        score += 40

    if "canal" in metadata_normalized:
        score += 15

    for term in channel_terms:
        if len(term) >= 3 and term in metadata_normalized:
            score += 15

    # --------------------------------------------------------
    # Penalizações
    # --------------------------------------------------------

    generic_terms = [
        "favicon",
        "sprite",
        "avatar",
        "placeholder",
        "default",
        "loading",
        "banner",
        "advert",
        "ads",
        "facebook",
        "twitter",
    ]

    for term in generic_terms:
        if term in value:
            score -= 30

    return score


def extract_logo_url(
    content: str,
    page_url: str,
    channel: Channel,
    source: str,
) -> str:

    soup = BeautifulSoup(
        content,
        "html.parser",
    )

    candidates: list[
        tuple[int, str]
    ] = []

    # --------------------------------------------------------
    # Open Graph / Twitter
    # --------------------------------------------------------

    for meta in soup.find_all(
        "meta"
    ):

        prop = normalize_text(
            meta.get("property")
            or meta.get("name")
        ).lower()

        if prop not in {
            "og:image",
            "og:image:url",
            "twitter:image",
            "twitter:image:src",
        }:
            continue

        value = normalize_text(
            meta.get("content")
        )

        if not value:
            continue

        if value.startswith(
            "data:"
        ):
            continue

        image_url = urljoin(
            page_url,
            value,
        )

        score = 90

        image_lower = image_url.lower()

        if "logo" in image_lower:
            score += 25

        if "favicon" in image_lower:
            score -= 50

        candidates.append(
            (
                score,
                image_url,
            )
        )

    # --------------------------------------------------------
    # Tags <img>
    # --------------------------------------------------------

    for image in soup.find_all(
        "img"
    ):

        image_url = image_url_from_tag(
            image,
            page_url,
        )

        if not image_url:
            continue

        score = score_image_candidate(
            image_url,
            image,
            channel,
            source,
        )

        candidates.append(
            (
                score,
                image_url,
            )
        )

    # --------------------------------------------------------
    # Elementos com background-image
    # --------------------------------------------------------

    for element in soup.find_all(
        style=True
    ):

        style = normalize_text(
            element.get("style")
        )

        matches = re.findall(
            r"background-image\s*:\s*url\(['\"]?([^'\")]+)",
            style,
            flags=re.I,
        )

        for match in matches:
            image_url = urljoin(
                page_url,
                normalize_text(match),
            )

            score = score_image_candidate(
                image_url,
                element,
                channel,
                source,
            )

            candidates.append(
                (
                    score,
                    image_url,
                )
            )

    if not candidates:
        return ""

    # --------------------------------------------------------
    # Remove duplicados
    # --------------------------------------------------------

    unique = {}

    for score, url in candidates:
        if not url:
            continue

        if url not in unique:
            unique[url] = score
        else:
            unique[url] = max(
                unique[url],
                score,
            )

    ranked = sorted(
        unique.items(),
        key=lambda item: item[1],
        reverse=True,
    )

    for url, score in ranked:
        if score < 10:
            continue

        return url

    return ""


# ============================================================
# DESCOBERTA DO LOGO DE UM CANAL
# ============================================================

def find_channel_logo(
    channel: Channel,
    discovered_mitv: dict[str, str],
    discovered_guiadetv: dict[str, str],
) -> tuple[str, str, str]:

    # --------------------------------------------------------
    # Se já existe logo, preservar
    # --------------------------------------------------------

    if channel.logo:
        return (
            channel.logo,
            "config",
            "",
        )

    # --------------------------------------------------------
    # Guia de TV → mi.tv
    # --------------------------------------------------------

    for source in LOGO_SOURCES:

        page_candidates = (
            build_logo_page_candidates(
                channel,
                source,
                discovered_mitv,
                discovered_guiadetv,
            )
        )

        for page_url in page_candidates:

            LOGGER.info(
                "🖼️ %s | tentando logo em %s | %s",
                channel.name,
                source,
                page_url,
            )

            response = http_get(
                page_url,
                timeout=LOGO_TIMEOUT,
                retries=LOGO_RETRIES,
            )

            if not response:
                continue

            final_page_url = (
                response.url
                or page_url
            )

            logo_url = extract_logo_url(
                response.text,
                final_page_url,
                channel,
                source,
            )

            if logo_url:

                LOGGER.info(
                    "✅ %s | logo=%s | fonte=%s",
                    channel.name,
                    logo_url,
                    source,
                )

                return (
                    logo_url,
                    source,
                    final_page_url,
                )

    LOGGER.warning(
        "⚠️ %s | logo não encontrado",
        channel.name,
    )

    return (
        "",
        "",
        "",
    )


# ============================================================
# RESOLUÇÃO DOS LOGOS
# ============================================================

def resolve_channel_logos(
    channels: list[Channel],
    discovered_mitv: dict[str, str],
    discovered_guiadetv: dict[str, str],
) -> dict[str, dict[str, Any]]:

    results: dict[
        str,
        dict[str, Any]
    ] = {}

    LOGGER.info(
        "=================================================="
    )

    LOGGER.info(
        "🖼️ DESCOBRINDO LOGOS DOS CANAIS"
    )

    LOGGER.info(
        "=================================================="
    )

    def worker(
        channel: Channel,
    ):
        return (
            channel,
            find_channel_logo(
                channel,
                discovered_mitv,
                discovered_guiadetv,
            ),
        )

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=MAX_WORKERS
    ) as executor:

        futures = [
            executor.submit(
                worker,
                channel,
            )
            for channel in channels
        ]

        for future in concurrent.futures.as_completed(
            futures
        ):

            channel, result = (
                future.result()
            )

            logo_url, source, page_url = (
                result
            )

            if logo_url:
                channel.logo = logo_url

            results[channel.id] = {
                "channel": channel.name,
                "logo": channel.logo,
                "source": source,
                "page": page_url,
                "found": bool(
                    channel.logo
                ),
            }

    found = sum(
        1
        for item in results.values()
        if item["found"]
    )

    LOGGER.info(
        "🖼️ Logos encontrados: %d/%d",
        found,
        len(channels),
    )

    return results


# ============================================================
# EPG — MATCHING
# ============================================================

def get_source_url(
    channel: Channel,
    source: str,
    discovered_mitv: dict[str, str],
    discovered_guiadetv: dict[str, str],
) -> str:

    explicit = normalize_text(
        channel.urls.get(source, "")
    )

    if explicit:
        return explicit

    if source == "mitv":
        return match_discovered_url(
            channel,
            discovered_mitv,
        )

    if source == "guiadetv":
        return match_discovered_url(
            channel,
            discovered_guiadetv,
        )

    return ""


# ============================================================
# PARSE DE DATAS
# ============================================================

def parse_datetime(
    value: Any,
) -> datetime | None:

    if value is None:
        return None

    value = normalize_text(
        value
    )

    if not value:
        return None

    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%dT%H:%M%z",
    ]

    for fmt in formats:
        try:
            result = datetime.strptime(
                value,
                fmt,
            )

            if result.tzinfo is None:
                result = result.replace(
                    tzinfo=timezone.utc
                )

            return result

        except ValueError:
            continue

    try:
        result = datetime.fromisoformat(
            value
        )

        if result.tzinfo is None:
            result = result.replace(
                tzinfo=timezone.utc
            )

        return result

    except ValueError:
        return None


def normalize_program(
    item: dict[str, Any],
) -> Program | None:

    title = normalize_text(
        item.get(
            "title",
            item.get(
                "name",
                "",
            ),
        )
    )

    if not title:
        return None

    start = parse_datetime(
        item.get(
            "start",
            item.get(
                "start_time",
                item.get(
                    "begin",
                    "",
                ),
            ),
        )
    )

    stop = parse_datetime(
        item.get(
            "stop",
            item.get(
                "end",
                item.get(
                    "end_time",
                    "",
                ),
            ),
        )
    )

    if not start or not stop:
        return None

    if stop <= start:
        return None

    description = normalize_text(
        item.get(
            "description",
            item.get(
                "desc",
                "",
            ),
        )
    )

    category = normalize_text(
        item.get(
            "category",
            "",
        )
    )

    icon = normalize_text(
        item.get(
            "icon",
            item.get(
                "image",
                "",
            ),
        )
    )

    return Program(
        title=title,
        start=start,
        stop=stop,
        description=description,
        category=category,
        icon=icon,
    )


# ============================================================
# MI.TV
# ============================================================

def fetch_mitv(
    channel: Channel,
    page_url: str,
) -> list[Program]:

    if not page_url:
        return []

    response = http_get(
        page_url,
        timeout=HTTP_TIMEOUT,
        retries=HTTP_RETRIES,
    )

    if not response:
        return []

    soup = BeautifulSoup(
        response.text,
        "html.parser",
    )

    programs = []

    # --------------------------------------------------------
    # Tentativa JSON-LD
    # --------------------------------------------------------

    for script in soup.find_all(
        "script",
        type="application/ld+json",
    ):

        raw = script.string

        if not raw:
            continue

        try:
            data = json.loads(raw)
        except Exception:
            continue

        if isinstance(
            data,
            dict,
        ):
            data = [data]

        if not isinstance(
            data,
            list,
        ):
            continue

        for item in data:

            if not isinstance(
                item,
                dict,
            ):
                continue

            start = (
                item.get(
                    "startDate"
                )
            )

            stop = (
                item.get(
                    "endDate"
                )
            )

            title = (
                item.get(
                    "name"
                )
            )

            if not title or not start or not stop:
                continue

            program = normalize_program(
                {
                    "title": title,
                    "start": start,
                    "stop": stop,
                    "description": item.get(
                        "description",
                        "",
                    ),
                }
            )

            if program:
                programs.append(
                    program
                )

    return programs


# ============================================================
# GUIA DE TV
# ============================================================

def fetch_guiadetv(
    channel: Channel,
    page_url: str,
) -> list[Program]:

    if not page_url:
        return []

    response = http_get(
        page_url,
        timeout=HTTP_TIMEOUT,
        retries=HTTP_RETRIES,
    )

    if not response:
        return []

    soup = BeautifulSoup(
        response.text,
        "html.parser",
    )

    programs = []

    # --------------------------------------------------------
    # JSON embutido
    # --------------------------------------------------------

    for script in soup.find_all(
        "script"
    ):

        text = script.string or ""

        if not text:
            continue

        if (
            "program" not in text.lower()
            and "schedule" not in text.lower()
        ):
            continue

        matches = re.findall(
            r'"start"\s*:\s*"([^"]+)".*?'
            r'"(?:stop|end)"\s*:\s*"([^"]+)".*?'
            r'"(?:title|name)"\s*:\s*"([^"]+)"',
            text,
            flags=re.I | re.S,
        )

        for start, stop, title in matches:

            program = normalize_program(
                {
                    "start": start,
                    "stop": stop,
                    "title": title,
                }
            )

            if program:
                programs.append(
                    program
                )

    return programs


# ============================================================
# IPTV-ORG
# ============================================================

def fetch_iptv_org_xml() -> str:
    response = http_get(
        IPTV_ORG_BR,
        timeout=HTTP_TIMEOUT,
        retries=HTTP_RETRIES,
    )

    if not response:
        return ""

    return response.text


def parse_iptv_org_channel(
    xml_text: str,
    channel: Channel,
) -> list[Program]:

    if not xml_text:
        return []

    soup = BeautifulSoup(
        xml_text,
        "xml",
    )

    aliases = [
        normalize_name(
            name
        )
        for name in channel_search_names(
            channel
        )
    ]

    aliases = [
        value
        for value in aliases
        if value
    ]

    target_channel = None

    for element in soup.find_all(
        "channel"
    ):

        display_names = [
            normalize_name(
                item.get_text(
                    strip=True
                )
            )
            for item in element.find_all(
                "display-name"
            )
        ]

        channel_id = normalize_name(
            element.get(
                "id",
                "",
            )
        )

        values = (
            display_names
            + [channel_id]
        )

        for value in values:

            if not value:
                continue

            for alias in aliases:

                if (
                    value == alias
                    or alias in value
                    or value in alias
                ):
                    target_channel = (
                        element.get(
                            "id"
                        )
                    )
                    break

            if target_channel:
                break

        if target_channel:
            break

    if not target_channel:
        return []

    programs = []

    for element in soup.find_all(
        "programme",
        attrs={
            "channel": target_channel
        },
    ):

        title_element = (
            element.find("title")
        )

        if not title_element:
            continue

        title = normalize_text(
            title_element.get_text(
                " ",
                strip=True,
            )
        )

        start_raw = element.get(
            "start"
        )

        stop_raw = element.get(
            "stop"
        )

        if not start_raw or not stop_raw:
            continue

        start = parse_xmltv_datetime(
            start_raw
        )

        stop = parse_xmltv_datetime(
            stop_raw
        )

        if not start or not stop:
            continue

        desc = element.find(
            "desc"
        )

        category = element.find(
            "category"
        )

        icon = element.find(
            "icon"
        )

        programs.append(
            Program(
                title=title,
                start=start,
                stop=stop,
                description=(
                    normalize_text(
                        desc.get_text(
                            " ",
                            strip=True,
                        )
                    )
                    if desc
                    else ""
                ),
                category=(
                    normalize_text(
                        category.get_text(
                            " ",
                            strip=True,
                        )
                    )
                    if category
                    else ""
                ),
                icon=(
                    normalize_text(
                        icon.get("src")
                    )
                    if icon
                    else ""
                ),
            )
        )

    return programs


def parse_xmltv_datetime(
    value: str,
) -> datetime | None:

    value = normalize_text(
        value
    )

    match = re.match(
        r"^(\d{14})(?:\s*([+-]\d{4}))?",
        value,
    )

    if not match:
        return None

    date_part = match.group(1)
    offset_part = match.group(2)

    try:
        result = datetime.strptime(
            date_part,
            "%Y%m%d%H%M%S",
        )

    except ValueError:
        return None

    if offset_part:
        sign = (
            1
            if offset_part[0] == "+"
            else -1
        )

        hours = int(
            offset_part[1:3]
        )

        minutes = int(
            offset_part[3:5]
        )

        result = result.replace(
            tzinfo=timezone(
                sign
                * timedelta(
                    hours=hours,
                    minutes=minutes,
                )
            )
        )

    else:
        result = result.replace(
            tzinfo=timezone.utc
        )

    return result


# ============================================================
# FILTRO DE DATA
# ============================================================

def filter_programs(
    programs: list[Program],
) -> list[Program]:

    now = datetime.now(
        timezone.utc
    )

    end = now + timedelta(
        days=DAYS
    )

    result = []

    for program in programs:

        if program.stop <= now:
            continue

        if program.start >= end:
            continue

        result.append(
            program
        )

    result.sort(
        key=lambda item: item.start
    )

    return result


# ============================================================
# BUSCA DE EPG DE UM CANAL
# ============================================================

def fetch_channel_programs(
    channel: Channel,
    discovered_mitv: dict[str, str],
    discovered_guiadetv: dict[str, str],
    iptv_org_xml: str,
) -> tuple[Channel, list[Program], str]:

    source_list = (
        channel.sources
        or [
            "mitv",
            "guiadetv",
            "iptv-org",
        ]
    )

    for source in source_list:

        source = normalize_text(
            source
        ).lower()

        if source == "mitv":

            url = get_source_url(
                channel,
                "mitv",
                discovered_mitv,
                discovered_guiadetv,
            )

            LOGGER.info(
                "🔎 %s | fonte=mitv",
                channel.name,
            )

            programs = fetch_mitv(
                channel,
                url,
            )

        elif source == "guiadetv":

            url = get_source_url(
                channel,
                "guiadetv",
                discovered_mitv,
                discovered_guiadetv,
            )

            LOGGER.info(
                "🔎 %s | fonte=guiadetv",
                channel.name,
            )

            programs = fetch_guiadetv(
                channel,
                url,
            )

        elif source == "iptv-org":

            LOGGER.info(
                "🔎 %s | fonte=iptv-org",
                channel.name,
            )

            programs = parse_iptv_org_channel(
                iptv_org_xml,
                channel,
            )

        else:

            LOGGER.warning(
                "⚠️ %s | fonte desconhecida: %s",
                channel.name,
                source,
            )

            continue

        programs = filter_programs(
            programs
        )

        if len(programs) >= MIN_PROGRAMS:
            LOGGER.info(
                "✅ %s | %d programas | fonte=%s",
                channel.name,
                len(programs),
                source,
            )

            return (
                channel,
                programs,
                source,
            )

    LOGGER.warning(
        "❌ %s | nenhuma fonte retornou programação",
        channel.name,
    )

    return (
        channel,
        [],
        "",
    )


# ============================================================
# XMLTV
# ============================================================

def format_xmltv_datetime(
    value: datetime,
) -> str:

    if value.tzinfo is None:
        value = value.replace(
            tzinfo=timezone.utc
        )

    offset = value.strftime(
        "%z"
    )

    if not offset:
        offset = "+0000"

    return (
        value.strftime(
            "%Y%m%d%H%M%S"
        )
        + " "
        + offset
    )


def build_xml(
    channels_data: list[
        tuple[
            Channel,
            list[Program],
        ]
    ],
) -> str:

    lines = []

    lines.append(
        '<?xml version="1.0" encoding="UTF-8"?>'
    )

    lines.append(
        '<tv generator-info-name="EPG Generator 4.3" '
        'generator-info-url="https://github.com/">'
    )

    # --------------------------------------------------------
    # CHANNELS
    # --------------------------------------------------------

    for channel, _programs in channels_data:

        lines.append(
            f'  <channel id="{xml_escape(channel.id)}">'
        )

        lines.append(
            f'    <display-name lang="pt-BR">'
            f'{xml_escape(channel.name)}'
            f'</display-name>'
        )

        if channel.logo:

            lines.append(
                "    <icon "
                f'src="{xml_escape(channel.logo)}" />'
            )

        lines.append(
            f'    <category>{xml_escape(channel.group)}</category>'
        )

        lines.append(
            "  </channel>"
        )

    # --------------------------------------------------------
    # PROGRAMAS
    # --------------------------------------------------------

    for channel, programs in channels_data:

        for program in programs:

            start = format_xmltv_datetime(
                program.start
            )

            stop = format_xmltv_datetime(
                program.stop
            )

            lines.append(
                "  <programme "
                f'channel="{xml_escape(channel.id)}" '
                f'start="{xml_escape(start)}" '
                f'stop="{xml_escape(stop)}">'
            )

            lines.append(
                f'    <title lang="pt-BR">'
                f'{xml_escape(program.title)}'
                f'</title>'
            )

            if program.description:

                lines.append(
                    f'    <desc lang="pt-BR">'
                    f'{xml_escape(program.description)}'
                    f'</desc>'
                )

            if program.category:

                lines.append(
                    f'    <category lang="pt-BR">'
                    f'{xml_escape(program.category)}'
                    f'</category>'
                )

            if program.icon:

                lines.append(
                    "    <icon "
                    f'src="{xml_escape(program.icon)}" />'
                )

            lines.append(
                "  </programme>"
            )

    lines.append(
        "</tv>"
    )

    return "\n".join(
        lines
    )


# ============================================================
# M3U
# ============================================================

def build_m3u(
    channels: list[Channel],
) -> str:

    lines = [
        "#EXTM3U "
        f'url-tvg="{PLAYLIST_EPG_URL}" '
        'x-tvg-url="'
        f'{PLAYLIST_EPG_URL}'
        '"'
    ]

    for channel in channels:

        if not channel.stream_url:
            continue

        attributes = [
            f'tvg-id="{channel.id}"',
            f'tvg-name="{channel.name}"',
        ]

        if channel.logo:

            attributes.append(
                f'tvg-logo="{channel.logo}"'
            )

        if channel.group:

            attributes.append(
                f'group-title="{channel.group}"'
            )

        extinf = (
            "#EXTINF:-1 "
            + " ".join(
                attributes
            )
            + ","
            + channel.name
        )

        lines.append(
            extinf
        )

        lines.append(
            channel.stream_url
        )

    return "\n".join(
        lines
    ) + "\n"


# ============================================================
# ALIASES
# ============================================================

def build_aliases(
    channels: list[Channel],
) -> dict[str, Any]:

    result = {}

    for channel in channels:

        names = unique_preserve_order(
            [
                channel.name,
                *channel.aliases,
            ]
        )

        result[channel.id] = {
            "name": channel.name,
            "aliases": names,
            "logo": channel.logo,
        }

    return result


# ============================================================
# RELATÓRIO
# ============================================================

def build_report(
    channels: list[Channel],
    results: dict[
        str,
        tuple[
            Channel,
            list[Program],
            str,
        ],
    ],
    logo_results: dict[
        str,
        dict[str, Any],
    ],
) -> dict[str, Any]:

    total_programs = sum(
        len(item[1])
        for item in results.values()
    )

    channels_with_epg = sum(
        1
        for item in results.values()
        if item[1]
    )

    channels_with_logo = sum(
        1
        for channel in channels
        if channel.logo
    )

    source_counts = {}

    for _channel, _programs, source in results.values():

        if not source:
            continue

        source_counts[source] = (
            source_counts.get(
                source,
                0,
            )
            + 1
        )

    logo_source_counts = {}

    for item in logo_results.values():

        source = item.get(
            "source",
            "",
        )

        if not source:
            continue

        logo_source_counts[source] = (
            logo_source_counts.get(
                source,
                0,
            )
            + 1
        )

    return {
        "generator": "EPG Generator 4.3",
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "days": DAYS,
        "max_workers": MAX_WORKERS,
        "total_channels": len(
            channels
        ),
        "channels_with_epg": channels_with_epg,
        "channels_without_epg": (
            len(channels)
            - channels_with_epg
        ),
        "total_programs": total_programs,
        "channels_with_logo": channels_with_logo,
        "channels_without_logo": (
            len(channels)
            - channels_with_logo
        ),
        "epg_sources": source_counts,
        "logo_sources": logo_source_counts,
        "logos": logo_results,
        "outputs": {
            "epg_xml": str(
                EPG_XML.relative_to(ROOT)
            ),
            "epg_gz": str(
                EPG_GZ.relative_to(ROOT)
            ),
            "playlist": str(
                PLAYLIST_M3U.relative_to(ROOT)
            ),
            "aliases": str(
                ALIASES_JSON.relative_to(ROOT)
            ),
            "report": str(
                REPORT_JSON.relative_to(ROOT)
            ),
        },
    }


# ============================================================
# VALIDAÇÃO
# ============================================================

def validate_xml(
    path: Path,
) -> bool:

    if not path.exists():
        return False

    content = path.read_text(
        encoding="utf-8"
    )

    if "<tv" not in content:
        return False

    if "</tv>" not in content:
        return False

    if "<channel " not in content:
        return False

    if "<programme " not in content:
        return False

    return True


def validate_outputs():

    required = [
        EPG_XML,
        EPG_GZ,
        PLAYLIST_M3U,
        ALIASES_JSON,
        REPORT_JSON,
    ]

    for path in required:

        if not path.exists():
            raise RuntimeError(
                f"Arquivo não gerado: {path}"
            )

        if path.stat().st_size <= 0:
            raise RuntimeError(
                f"Arquivo vazio: {path}"
            )

    if not validate_xml(
        EPG_XML
    ):
        raise RuntimeError(
            "EPG XML inválido ou sem canais/programas."
        )

    LOGGER.info(
        "✅ Todos os arquivos foram validados."
    )


# ============================================================
# MAIN
# ============================================================

def main() -> int:

    start_time = time.time()

    LOGGER.info(
        "=================================================="
    )

    LOGGER.info(
        "📺 EPG GENERATOR 4.3"
    )

    LOGGER.info(
        "=================================================="
    )

    try:

        OUTPUT_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        # ----------------------------------------------------
        # CONFIG
        # ----------------------------------------------------

        channels = load_channels()

        if not channels:
            raise RuntimeError(
                "Nenhum canal encontrado no channels.json."
            )

        LOGGER.info(
            "📺 Canais carregados: %d",
            len(channels),
        )

        # ----------------------------------------------------
        # DISCOVERY
        # ----------------------------------------------------

        discovered_mitv = (
            discover_mitv()
        )

        discovered_guiadetv = (
            discover_guiadetv()
        )

        # ----------------------------------------------------
        # LOGOS
        # ----------------------------------------------------

        logo_results = (
            resolve_channel_logos(
                channels,
                discovered_mitv,
                discovered_guiadetv,
            )
        )

        # ----------------------------------------------------
        # IPTV-ORG
        # ----------------------------------------------------

        needs_iptv_org = any(
            "iptv-org"
            in [
                normalize_text(source).lower()
                for source in (
                    channel.sources
                    or []
                )
            ]
            for channel in channels
        )

        iptv_org_xml = ""

        if needs_iptv_org:

            LOGGER.info(
                "🌐 Baixando EPG IPTV-ORG..."
            )

            iptv_org_xml = (
                fetch_iptv_org_xml()
            )

        # ----------------------------------------------------
        # EPG
        # ----------------------------------------------------

        results = {}

        LOGGER.info(
            "=================================================="
        )

        LOGGER.info(
            "📡 BUSCANDO PROGRAMAÇÃO"
        )

        LOGGER.info(
            "=================================================="
        )

        def worker(channel):

            return fetch_channel_programs(
                channel,
                discovered_mitv,
                discovered_guiadetv,
                iptv_org_xml,
            )

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=MAX_WORKERS
        ) as executor:

            futures = [
                executor.submit(
                    worker,
                    channel,
                )
                for channel in channels
            ]

            for future in concurrent.futures.as_completed(
                futures
            ):

                channel, programs, source = (
                    future.result()
                )

                results[channel.id] = (
                    channel,
                    programs,
                    source,
                )

        # ----------------------------------------------------
        # ORDENAR
        # ----------------------------------------------------

        channels_data = []

        for channel in channels:

            result = results.get(
                channel.id
            )

            if not result:
                continue

            result_channel, programs, _source = (
                result
            )

            channels_data.append(
                (
                    result_channel,
                    programs,
                )
            )

        # ----------------------------------------------------
        # XML
        # ----------------------------------------------------

        LOGGER.info(
            "📝 Gerando epg.xml..."
        )

        xml_content = build_xml(
            channels_data
        )

        EPG_XML.write_text(
            xml_content,
            encoding="utf-8",
        )

        # ----------------------------------------------------
        # GZIP
        # ----------------------------------------------------

        LOGGER.info(
            "🗜️ Gerando epg.xml.gz..."
        )

        with gzip.open(
            EPG_GZ,
            "wt",
            encoding="utf-8",
        ) as file:

            file.write(
                xml_content
            )

        # ----------------------------------------------------
        # M3U
        # ----------------------------------------------------

        LOGGER.info(
            "📺 Gerando playlist.m3u..."
        )

        playlist = build_m3u(
            channels
        )

        PLAYLIST_M3U.write_text(
            playlist,
            encoding="utf-8",
        )

        # ----------------------------------------------------
        # ALIASES
        # ----------------------------------------------------

        LOGGER.info(
            "🔗 Gerando epg_aliases.json..."
        )

        aliases = build_aliases(
            channels
        )

        safe_json_dump(
            aliases,
            ALIASES_JSON,
        )

        # ----------------------------------------------------
        # REPORT
        # ----------------------------------------------------

        LOGGER.info(
            "📊 Gerando epg-report.json..."
        )

        report = build_report(
            channels,
            results,
            logo_results,
        )

        safe_json_dump(
            report,
            REPORT_JSON,
        )

        # ----------------------------------------------------
        # VALIDAR
        # ----------------------------------------------------

        validate_outputs()

        elapsed = (
            time.time()
            - start_time
        )

        total_programs = sum(
            len(item[1])
            for item in results.values()
        )

        total_logos = sum(
            1
            for channel in channels
            if channel.logo
        )

        LOGGER.info(
            "=================================================="
        )

        LOGGER.info(
            "🎉 EPG FINALIZADO COM SUCESSO"
        )

        LOGGER.info(
            "=================================================="
        )

        LOGGER.info(
            "📺 Canais: %d",
            len(channels),
        )

        LOGGER.info(
            "🖼️ Logos: %d/%d",
            total_logos,
            len(channels),
        )

        LOGGER.info(
            "📡 Programas: %d",
            total_programs,
        )

        LOGGER.info(
            "⏱️ Tempo: %.2f segundos",
            elapsed,
        )

        LOGGER.info(
            "📄 %s",
            EPG_XML,
        )

        LOGGER.info(
            "🗜️ %s",
            EPG_GZ,
        )

        LOGGER.info(
            "📺 %s",
            PLAYLIST_M3U,
        )

        LOGGER.info(
            "🔗 %s",
            ALIASES_JSON,
        )

        LOGGER.info(
            "📊 %s",
            REPORT_JSON,
        )

        return 0

    except KeyboardInterrupt:

        LOGGER.warning(
            "⛔ Execução interrompida."
        )

        return 130

    except Exception as exc:

        LOGGER.exception(
            "❌ Erro fatal: %s",
            exc,
        )

        return 1


# ============================================================
# ENTRYPOINT
# ============================================================

if __name__ == "__main__":
    sys.exit(
        main()
    )