# script/epg_generator.py
"""
Gerador de EPG (XMLTV) robusto para o IPTV ULTRA SYSTEM.

- Suporta múltiplos layouts de sites (mi.tv, guiadetv, alepi).
- Trata rollover de meia-noite corretamente.
- Faz XML escaping e não quebra se um canal falhar.
- Lê tudo do config/channels.json.
"""

from __future__ import annotations

import html
import json
import logging
import os
import re
import sys
from datetime import datetime, timedelta
from typing import Iterable
from xml.sax.saxutils import escape, quoteattr

import requests
from bs4 import BeautifulSoup

# ---------------------------------------------------------------------------
# Config / logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("epg")

CONFIG_PATH = "config/channels.json"
OUTPUT_PATH = "output/epg.xml"
DEFAULT_TIMEZONE = "-0300"
DEFAULT_DAYS = 2
HTTP_TIMEOUT = 25

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
}

# Várias formas comuns de representar "HH:MM - Título"
TIME_TITLE_PATTERNS = [
    re.compile(r"^\s*(\d{1,2}[:h]\d{2})\s*[-–—:]\s*(.+?)\s*$"),
    re.compile(r"^\s*(\d{1,2}:\d{2})\s+(.+?)\s*$"),
]

# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
def fetch_html(url: str) -> str | None:
    try:
        r = requests.get(url, headers=HEADERS, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        r.encoding = r.apparent_encoding or r.encoding
        return r.text
    except requests.RequestException as e:
        log.warning("Falha ao baixar %s: %s", url, e)
        return None


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------
def _normalize_hour(raw: str) -> str | None:
    """Aceita '8:00', '08h00', '08:00' e devolve 'HH:MM'."""
    raw = raw.strip().lower().replace("h", ":")
    m = re.match(r"^(\d{1,2}):(\d{2})$", raw)
    if not m:
        return None
    hh, mm = int(m.group(1)), int(m.group(2))
    if not (0 <= hh <= 23 and 0 <= mm <= 59):
        return None
    return f"{hh:02d}:{mm:02d}"


def _match_time_title(line: str) -> tuple[str, str] | None:
    for pat in TIME_TITLE_PATTERNS:
        m = pat.match(line)
        if m:
            hora = _normalize_hour(m.group(1))
            titulo = m.group(2).strip()
            if hora and titulo and len(titulo) > 1:
                return hora, titulo
    return None


def parse_programs(html_text: str | None) -> list[tuple[str, str]]:
    """Extrai [(HH:MM, título), ...] de qualquer HTML de grade."""
    if not html_text:
        return []

    soup = BeautifulSoup(html_text, "lxml")
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()

    programs: list[tuple[str, str]] = []
    seen: set[str] = set()

    # Estratégia 1: linhas de texto diretas
    for line in soup.get_text("\n").split("\n"):
        line = line.strip()
        if not line:
            continue
        hit = _match_time_title(line)
        if hit:
            hora, titulo = hit
            if hora not in seen:
                seen.add(hora)
                programs.append((hora, titulo))

    # Estratégia 2 (fallback): junta horário e título em elementos irmãos
    if len(programs) < 3:
        for el in soup.find_all(["li", "div", "tr", "article"]):
            text = el.get_text(" ", strip=True)
            hit = _match_time_title(text)
            if hit:
                hora, titulo = hit
                if hora not in seen:
                    seen.add(hora)
                    programs.append((hora, titulo))

    programs.sort(key=lambda p: (int(p[0][:2]), int(p[0][3:])))
    return programs


# ---------------------------------------------------------------------------
# Seleção de URL de programação
# ---------------------------------------------------------------------------
def pick_source_url(ch: dict) -> str | None:
    """Prioriza o primeiro source da lista `sources` do canal."""
    urls = ch.get("urls") or {}
    for src in ch.get("sources", []):
        u = (urls.get(src) or "").strip()
        if u:
            return u
    for u in urls.values():
        if u:
            return u
    return ch.get("programacao_url") or None


# ---------------------------------------------------------------------------
# Geração XMLTV
# ---------------------------------------------------------------------------
def _fmt(dt: datetime) -> str:
    return dt.strftime("%Y%m%d%H%M%S")


def build_xmltv(channels: Iterable[dict], days: int, tz: str) -> str:
    parts: list[str] = []
    parts.append('<?xml version="1.0" encoding="UTF-8"?>')
    parts.append(
        '<tv generator-info-name="IPTV ULTRA SYSTEM" '
        'generator-info-url="https://github.com/josieljefferson/epg-system">'
    )

    # ---- Canais ----
    for ch in channels:
        cid = escape(str(ch.get("id", "")))
        name = escape(str(ch.get("name") or cid))
        logo = (ch.get("logo") or "").strip()
        parts.append(f'  <channel id={quoteattr(ch.get("id", ""))}>')
        parts.append(f"    <display-name>{name}</display-name>")
        if logo:
            parts.append(f"    <icon src={quoteattr(logo)} />")
        parts.append("  </channel>")

    # ---- Programas ----
    now = datetime.now().replace(second=0, microsecond=0)

    for ch in channels:
        url = pick_source_url(ch)
        cid = ch.get("id", "")
        if not url:
            log.info("⚠️  %s sem URL de programação — pulando.", cid)
            continue

        log.info("📡 Buscando EPG de %s → %s", cid, url)
        html_text = fetch_html(url)
        programs = parse_programs(html_text)

        if not programs:
            log.warning("⚠️  Nenhum programa extraído para %s", cid)
            continue

        log.info("   ✅ %d programas encontrados", len(programs))

        for d in range(days):
            base = now + timedelta(days=d)

            for i, (hora, titulo) in enumerate(programs):
                hh, mm = map(int, hora.split(":"))
                start = base.replace(hour=hh, minute=mm, second=0, microsecond=0)

                # Próximo programa (rollover tratado)
                if i < len(programs) - 1:
                    nh, nm = map(int, programs[i + 1][0].split(":"))
                    stop = base.replace(hour=nh, minute=nm, second=0, microsecond=0)
                    if stop <= start:
                        stop += timedelta(days=1)
                else:
                    stop = start + timedelta(hours=1)

                # Segurança: duração mínima de 5min
                if stop <= start:
                    stop = start + timedelta(minutes=5)

                parts.append(
                    f'  <programme start="{_fmt(start)} {tz}" '
                    f'stop="{_fmt(stop)} {tz}" '
                    f'channel={quoteattr(cid)}>'
                )
                parts.append(f"    <title lang=\"pt\">{escape(titulo)}</title>")
                parts.append("  </programme>")

    parts.append("</tv>")
    return "\n".join(parts) + "\n"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    if not os.path.exists(CONFIG_PATH):
        log.error("Config não encontrada: %s", CONFIG_PATH)
        return 1

    with open(CONFIG_PATH, encoding="utf-8") as f:
        cfg = json.load(f)

    channels = cfg.get("channels", [])
    days = int(cfg.get("days", DEFAULT_DAYS))
    tz = cfg.get("timezone", DEFAULT_TIMEZONE)

    log.info("Gerando EPG — %d canais × %d dias (TZ %s)", len(channels), days, tz)

    xml = build_xmltv(channels, days, tz)

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(xml)

    log.info("✅ EPG gravado em %s (%d bytes)", OUTPUT_PATH, len(xml.encode("utf-8")))
    return 0


if __name__ == "__main__":
    sys.exit(main())