# script/m3u_builder.py
"""
Gerador de playlist M3U a partir de config/channels.json.
"""

from __future__ import annotations

import json
import logging
import os
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("m3u")

CONFIG_PATH = "config/channels.json"
OUTPUT_PATH = "output/playlist.m3u"
EPG_URL = (
    "https://raw.githubusercontent.com/josieljefferson/epg-system/"
    "refs/heads/main/output/epg.xml"
)


def sanitize(value: str | None) -> str:
    """Remove aspas e quebras de linha de atributos M3U."""
    return (value or "").replace('"', "'").replace("\n", " ").strip()


def build_m3u(channels: list[dict]) -> str:
    lines: list[str] = []
    lines.append(f'#EXTM3U url-tvg="{EPG_URL}" x-tvg-url="{EPG_URL}"')

    total = 0
    for ch in channels:
        stream = (ch.get("url") or "").strip()
        if not stream:
            log.warning("⚠️  Canal sem URL de stream: %s", ch.get("id"))
            continue

        cid = sanitize(ch.get("id", ""))
        name = sanitize(ch.get("name") or cid)
        logo = sanitize(ch.get("logo") or "")
        group = sanitize(ch.get("group") or "Geral")

        lines.append(
            f'#EXTINF:-1 tvg-id="{cid}" tvg-name="{name}" '
            f'tvg-logo="{logo}" group-title="{group}",{name}'
        )
        lines.append(stream)
        total += 1

    log.info("✅ %d canais escritos na playlist", total)
    return "\n".join(lines) + "\n"


def main() -> int:
    if not os.path.exists(CONFIG_PATH):
        log.error("Config não encontrada: %s", CONFIG_PATH)
        return 1

    with open(CONFIG_PATH, encoding="utf-8") as f:
        cfg = json.load(f)

    content = build_m3u(cfg.get("channels", []))

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(content)

    log.info("✅ Playlist gravada em %s", OUTPUT_PATH)
    return 0


if __name__ == "__main__":
    sys.exit(main())