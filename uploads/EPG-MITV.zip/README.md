📺 EPG mi.tv Brasil

Gerador automatizado de EPG (Electronic Program Guide) no formato XMLTV, utilizando a programação pública disponibilizada pelo "mi.tv Brasil" (https://mi.tv/br/).

O projeto coleta a programação de múltiplos canais, processa e normaliza os dados, gera arquivos XMLTV, cria uma versão compactada em GZIP e pode publicar automaticamente os resultados através do GitHub Actions.

---

📌 Características

- Coleta automatizada de programação.
- Suporte a múltiplos canais.
- Suporte a múltiplos dias.
- Extração de páginas com conteúdo dinâmico.
- Chromium via Playwright.
- Retry automático.
- Timeout configurável.
- User-Agent configurável.
- Deduplicação de programas.
- Ordenação cronológica.
- Normalização de horários.
- Fuso horário "-0300".
- Geração de XMLTV.
- Geração de GZIP.
- Validação estrutural do XML.
- Proteção contra EPG vazio.
- Proteção contra dados inválidos.
- Backup da versão anterior.
- Logs detalhados.
- Execução local.
- Execução manual pelo GitHub Actions.
- Atualização automática pelo GitHub Actions.
- Commit somente quando houver alterações.

---

📂 Estrutura

epg-mitv/
│
├── .github/
│   └── workflows/
│       └── epg.yml
│
├── config/
│   └── channels.json
│
├── script/
│   └── epg_generator.py
│
├── output/
│   ├── epg.xml
│   └── epg.xml.gz
│
├── debug_mitv/
│   └── arquivos de diagnóstico
│
├── requirements.txt
├── .gitignore
└── README.md

---

⚙️ Requisitos

Software

- Python "3.11+"
- pip
- Chromium
- Playwright

Ambiente

O projeto pode ser executado em:

- Linux
- Windows
- macOS
- GitHub Actions

---

🚀 Instalação

Clone o repositório:

git clone https://github.com/josielluz/epg-mitv.git

Entre no diretório:

cd REPOSITORIO

Atualize o "pip":

python -m pip install --upgrade pip

Instale as dependências:

python -m pip install -r requirements.txt

Instale o Chromium:

python -m playwright install chromium

No Linux, caso sejam necessárias as dependências do sistema:

python -m playwright install --with-deps chromium

---

📦 Dependências

O arquivo "requirements.txt" deve conter as bibliotecas utilizadas pelo gerador.

Exemplo:

requests>=2.32.0
beautifulsoup4>=4.12.3
lxml>=5.3.0
playwright>=1.50.0

Instalação:

python -m pip install -r requirements.txt

---

📺 Configuração dos canais

Os canais são definidos em:

config/channels.json

Formato:

{
  "channels": [
    {
      "id": "Globo.br",
      "name": "Globo",
      "slug": "rede-globo"
    },
    {
      "id": "SBT.br",
      "name": "SBT",
      "slug": "sbt"
    }
  ]
}

Campos

Campo| Tipo| Obrigatório| Descrição
"id"| string| Sim| Identificador único do canal no XMLTV
"name"| string| Sim| Nome do canal
"slug"| string| Sim| Identificador utilizado pelo mi.tv

Exemplo

{
  "id": "Globo.br",
  "name": "Globo",
  "slug": "rede-globo"
}

O "slug" é utilizado para localizar a página correspondente no mi.tv.

---

▶️ Execução local

Execute:

python script/epg_generator.py

O processo deverá:

1. carregar "channels.json";
2. iniciar o mecanismo de coleta;
3. acessar as páginas do mi.tv;
4. extrair a programação;
5. normalizar os dados;
6. remover duplicidades;
7. ordenar cronologicamente;
8. validar os programas;
9. gerar o XMLTV;
10. gerar o GZIP;
11. validar os arquivos finais.

---

📤 Arquivos de saída

Após uma execução válida:

output/
├── epg.xml
└── epg.xml.gz

XMLTV

output/epg.xml

GZIP

output/epg.xml.gz

---

🧾 Formato XMLTV

O arquivo gerado segue a estrutura XMLTV.

Exemplo:

<?xml version="1.0" encoding="UTF-8"?>
<tv>
    <channel id="Globo.br">
        <display-name>Globo</display-name>
    </channel>

    <programme
        start="20260809060000 -0300"
        stop="20260809070000 -0300"
        channel="Globo.br">

        <title>Programa</title>

    </programme>
</tv>

Os horários são gerados utilizando o offset:

-0300

---

🛡️ Validação

O gerador deve impedir a publicação de um EPG inválido.

São verificadas condições como:

- XML bem formado;
- elemento raiz "<tv>";
- existência de canais;
- existência de programas;
- IDs válidos;
- horários válidos;
- início anterior ao término;
- ausência de duplicidades;
- ordenação cronológica.

Um resultado como:

Canais: 4
Programas: 0

deve ser tratado como falha.

---

🚫 Proteção contra EPG vazio

O projeto possui proteção para impedir que uma falha de coleta substitua um EPG válido.

Fluxo:

Coleta
   │
   ▼
Processamento
   │
   ▼
Validação
   │
   ├── Inválido ──► Cancelar publicação
   │
   ▼
EPG válido
   │
   ▼
Gerar XML
   │
   ▼
Gerar GZIP
   │
   ▼
Publicar

Se nenhum programa for encontrado, o processo deve terminar com erro e preservar a versão anterior.

---

🔄 Retry

Falhas temporárias de rede não devem interromper imediatamente o processamento.

O mecanismo de coleta pode repetir automaticamente uma operação quando ocorrer:

- timeout;
- erro HTTP;
- falha de conexão;
- erro temporário de navegação;
- indisponibilidade momentânea.

O número de tentativas e o intervalo entre elas devem ser configuráveis no gerador.

---

🌐 Playwright

O mi.tv pode utilizar conteúdo carregado dinamicamente.

Por esse motivo, o projeto suporta Playwright e Chromium.

Instalação:

python -m playwright install chromium

GitHub Actions:

- name: 🌐 Instalar Chromium
  run: |
    python -m playwright install --with-deps chromium

A instalação deve ocorrer depois das dependências Python e antes da execução do gerador.

---

🤖 GitHub Actions

O workflow está localizado em:

.github/workflows/epg.yml

O workflow pode executar:

- manualmente;
- automaticamente por CRON.

Exemplo:

on:
  workflow_dispatch:

  schedule:
    - cron: "5 */6 * * *"

Nesse exemplo, a execução ocorre aproximadamente a cada seis horas.

«O agendamento do GitHub Actions utiliza UTC.»

---

🔐 Permissões

Para permitir que o workflow publique alterações no repositório:

permissions:
  contents: write

---

🧩 Fluxo do GitHub Actions

Checkout
   │
   ▼
Configurar Python
   │
   ▼
Instalar dependências
   │
   ▼
Instalar Chromium
   │
   ▼
Validar channels.json
   │
   ▼
Executar epg_generator.py
   │
   ▼
Validar epg.xml
   │
   ▼
Gerar epg.xml.gz
   │
   ▼
Validar GZIP
   │
   ▼
Comparar arquivos
   │
   ▼
Alterações?
   │
   ├── Não ──► Finalizar
   │
   └── Sim ──► Commit / Push

---

▶️ Execução manual

No GitHub:

Repository
    ↓
Actions
    ↓
📺 Atualizar EPG mi.tv
    ↓
Run workflow
    ↓
Run

A execução manual é recomendada após alterações em:

script/epg_generator.py
config/channels.json
requirements.txt
.github/workflows/epg.yml

---

🌐 URLs do EPG

Depois que o workflow publicar os arquivos:

XML

https://raw.githubusercontent.com/josielluz/epg-mitv/main/output/epg.xml

GZIP

https://raw.githubusercontent.com/josielluz/epg-mitv/main/output/epg.xml.gz

Substitua:

USUARIO

pelo usuário ou organização do GitHub.

Substitua:

REPOSITORIO

pelo nome do repositório.

---

🔎 Diagnóstico

Quando a coleta falhar, os arquivos de diagnóstico podem ser encontrados em:

debug_mitv/

Exemplo:

debug_mitv/
├── rede-globo_20260809.html
├── sbt_20260809.html
└── ...

Esses arquivos permitem verificar o conteúdo efetivamente recebido do mi.tv e facilitam a manutenção do parser.

---

🐞 Troubleshooting

Nenhum programa encontrado

Mensagem:

Nenhum programa encontrado

Possíveis causas:

- alteração da estrutura HTML;
- conteúdo carregado dinamicamente;
- mudança no JavaScript;
- mudança de endpoint;
- "slug" incorreto;
- bloqueio temporário;
- timeout;
- indisponibilidade da programação.

Verifique:

debug_mitv/

e os logs do workflow.

---

Chromium não encontrado

Execute:

python -m playwright install chromium

No GitHub Actions:

- name: 🌐 Instalar Chromium
  run: |
    python -m playwright install --with-deps chromium

---

Playwright não encontrado

Erro:

ModuleNotFoundError: No module named 'playwright'

Execute:

python -m pip install playwright

E confirme que "requirements.txt" contém:

playwright>=1.50.0

---

"channels.json" inválido

Valide o JSON:

python -m json.tool config/channels.json

Se estiver correto, será exibida a estrutura formatada.

---

⚡ Desempenho

Para grandes quantidades de canais, recomenda-se:

- reutilizar a sessão HTTP;
- reutilizar a instância do navegador;
- evitar iniciar um Chromium para cada canal;
- limitar concorrência;
- utilizar timeout;
- utilizar retry;
- deduplicar antes da geração;
- ordenar os dados apenas após a coleta;
- evitar requisições desnecessárias;
- utilizar cache quando apropriado.

A inicialização de uma única instância do Chromium e a reutilização das páginas/sessões reduz significativamente o custo de processamento.

---

🔄 Atualização

O processo de atualização segue:

channels.json
      │
      ▼
Coleta mi.tv
      │
      ▼
Normalização
      │
      ▼
Deduplicação
      │
      ▼
Ordenação
      │
      ▼
Validação
      │
      ▼
XMLTV
      │
      ▼
GZIP
      │
      ▼
Publicação

O repositório deve ser atualizado somente quando os arquivos gerados realmente sofrerem alterações.

---

⚠️ Compatibilidade com o mi.tv

Este projeto depende da estrutura e da disponibilidade pública do mi.tv.

O mi.tv pode alterar:

- HTML;
- CSS;
- JavaScript;
- endpoints;
- URLs;
- estrutura dos dados;
- mecanismos de carregamento;
- proteção contra automação.

Por isso, o parser pode precisar de manutenção quando ocorrerem alterações no serviço.

---

📋 Boas práticas

Antes de adicionar alterações ao projeto:

1. valide "channels.json";
2. execute o gerador localmente;
3. confirme a quantidade de programas;
4. valide o XML;
5. teste o GZIP;
6. verifique os logs;
7. execute o workflow manualmente;
8. somente depois mantenha o agendamento automático.

---

📜 Licença

Defina a licença do projeto no arquivo:

LICENSE

Exemplo:

MIT License

Não declare uma licença no README caso o projeto ainda não tenha uma licença definida.

---

⚠️ Aviso

Este projeto utiliza informações públicas disponibilizadas pelo mi.tv para geração de dados de programação.

O projeto não hospeda nem redistribui sinais de televisão.

A disponibilidade e o formato dos dados dependem do serviço de origem e podem sofrer alterações sem aviso prévio.

---

📊 Status

Recurso| Status
Coleta de programação| ✅
Múltiplos canais| ✅
Múltiplos dias| ✅
XMLTV| ✅
GZIP| ✅
Retry| ✅
Timeout| ✅
Deduplicação| ✅
Ordenação| ✅
Validação| ✅
Proteção contra EPG vazio| ✅
Playwright| ✅
Chromium| ✅
GitHub Actions| ✅
Atualização automática| ✅

---

📺 Saída

Os arquivos finais são:

output/epg.xml
output/epg.xml.gz

Esses arquivos podem ser utilizados por aplicações compatíveis com o formato XMLTV.
