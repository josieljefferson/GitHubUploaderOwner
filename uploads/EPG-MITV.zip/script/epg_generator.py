#!/usr/bin/env python3

"""
EPG mi.tv -> XMLTV

Estratégia:

1. Abre a página do mi.tv com Chromium real.
2. Executa JavaScript.
3. Aguarda a grade ser carregada.
4. Captura HTML renderizado.
5. Analisa elementos da página.
6. Analisa scripts/JSON.
7. Analisa texto da página.
8. Gera XMLTV.
9. Recusa publicar EPG vazio.

Compatível com GitHub Actions / Ubuntu.
Python 3.11+
"""

from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import re
import sys
import time
import unicodedata
import xml.etree.ElementTree as ET

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


# ============================================================
# CONFIGURAÇÃO
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

CONFIG_FILE = ROOT / "config" / "channels.json"

OUTPUT_DIR = ROOT / "output"

OUTPUT_FILE = OUTPUT_DIR / "epg.xml"

DEBUG_DIR = ROOT / "debug_mitv"


DAYS_AHEAD = int(
    os.getenv(
        "MITV_DAYS_AHEAD",
        "2",
    )
)

MIN_PROGRAMS = int(
    os.getenv(
        "MITV_MIN_PROGRAMS",
        "1",
    )
)

PAGE_TIMEOUT = int(
    os.getenv(
        "MITV_PAGE_TIMEOUT",
        "60000",
    )
)

WAIT_AFTER_LOAD = int(
    os.getenv(
        "MITV_WAIT",
        "5000",
    )
)

HEADLESS = True


# ============================================================
# LOG
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

log = logging.getLogger(
    "mi-tv-epg"
)


# ============================================================
# MODELOS
# ============================================================

@dataclass
class Channel:

    id: str

    name: str

    slug: str

    logo: str = ""


@dataclass
class Program:

    channel_id: str

    title: str

    start: datetime

    stop: datetime

    description: str = ""

    category: str = ""

    icon: str = ""


# ============================================================
# TEXTO
# ============================================================

def clean_text(
    value: Any,
) -> str:

    if value is None:
        return ""

    value = html.unescape(
        str(value)
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    )

    return value.strip()


def normalize(
    value: str,
) -> str:

    value = clean_text(
        value
    )

    value = unicodedata.normalize(
        "NFKD",
        value,
    )

    value = "".join(
        char
        for char in value
        if not unicodedata.combining(
            char
        )
    )

    return value.lower()


def xml_escape(
    value: str,
) -> str:

    return html.escape(
        clean_text(value),
        quote=True,
    )


# ============================================================
# CONFIG
# ============================================================

def load_channels() -> list[Channel]:

    if not CONFIG_FILE.exists():

        raise RuntimeError(
            f"Arquivo não encontrado: "
            f"{CONFIG_FILE}"
        )

    with CONFIG_FILE.open(
        "r",
        encoding="utf-8",
    ) as file:

        data = json.load(
            file
        )

    raw_channels = data.get(
        "channels"
    )

    if not isinstance(
        raw_channels,
        list,
    ):

        raise RuntimeError(
            "'channels' deve ser uma lista."
        )

    result = []

    ids = set()

    for index, item in enumerate(
        raw_channels,
        start=1,
    ):

        if not isinstance(
            item,
            dict,
        ):

            raise RuntimeError(
                f"Canal {index} inválido."
            )

        channel_id = clean_text(
            item.get("id")
        )

        name = clean_text(
            item.get("name")
        )

        slug = clean_text(
            item.get("slug")
        )

        logo = clean_text(
            item.get("logo")
        )

        if not channel_id:
            raise RuntimeError(
                f"Canal {index}: id ausente."
            )

        if not name:
            raise RuntimeError(
                f"Canal {index}: name ausente."
            )

        if not slug:
            raise RuntimeError(
                f"Canal {index}: slug ausente."
            )

        if channel_id in ids:

            raise RuntimeError(
                f"ID duplicado: {channel_id}"
            )

        ids.add(
            channel_id
        )

        result.append(
            Channel(
                id=channel_id,
                name=name,
                slug=slug,
                logo=logo,
            )
        )

    if not result:

        raise RuntimeError(
            "Nenhum canal configurado."
        )

    return result


# ============================================================
# URL
# ============================================================

def make_url(
    channel: Channel,
    day: date,
) -> str:

    base = (
        "https://mi.tv/br/canais/"
        + channel.slug
    )

    today = date.today()

    if day == today:

        return base

    return (
        f"{base}/"
        f"{day.isoformat()}"
    )


# ============================================================
# DATETIME
# ============================================================

def parse_time(
    value: str,
) -> tuple[int, int] | None:

    if not value:
        return None

    match = re.search(
        r"\b([01]?\d|2[0-3]):([0-5]\d)\b",
        value,
    )

    if not match:
        return None

    return (
        int(match.group(1)),
        int(match.group(2)),
    )


def build_datetime(
    day: date,
    value: str,
) -> datetime | None:

    parsed = parse_time(
        value
    )

    if parsed is None:
        return None

    hour, minute = parsed

    return datetime(
        day.year,
        day.month,
        day.day,
        hour,
        minute,
    )


# ============================================================
# PLAYWRIGHT
# ============================================================

async def create_browser():

    try:

        from playwright.async_api import (
            async_playwright,
        )

    except ImportError:

        raise RuntimeError(
            "Playwright não está instalado."
        )

    playwright = await async_playwright().start()

    browser = await playwright.chromium.launch(
        headless=HEADLESS,
        args=[
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu",
            "--no-zygote",
            "--disable-blink-features=AutomationControlled",
        ],
    )

    return playwright, browser


# ============================================================
# CAPTURA DA PÁGINA
# ============================================================

async def load_page(
    page,
    url: str,
) -> str:

    log.info(
        "=" * 70
    )

    log.info(
        "URL: %s",
        url,
    )

    log.info(
        "=" * 70
    )

    try:

        response = await page.goto(
            url,
            wait_until="domcontentloaded",
            timeout=PAGE_TIMEOUT,
        )

        status = (
            response.status
            if response
            else 0
        )

        log.info(
            "HTTP STATUS: %s",
            status,
        )

    except Exception as exc:

        log.error(
            "Falha ao abrir página: %s",
            exc,
        )

        return ""

    # --------------------------------------------------------
    # Esperar JavaScript
    # --------------------------------------------------------

    try:

        await page.wait_for_load_state(
            "networkidle",
            timeout=15000,
        )

    except Exception:

        log.warning(
            "networkidle não atingido; "
            "continuando."
        )

    await page.wait_for_timeout(
        WAIT_AFTER_LOAD
    )

    # --------------------------------------------------------
    # Tentar aguardar elementos relacionados
    # --------------------------------------------------------

    selectors = [
        ".guide",
        ".guide-content",
        ".program",
        "[class*='program']",
        "[class*='schedule']",
        "[class*='guide']",
        "[data-start]",
        "[data-program]",
    ]

    for selector in selectors:

        try:

            count = await page.locator(
                selector
            ).count()

            if count:

                log.info(
                    "Seletor encontrado: %s (%d)",
                    selector,
                    count,
                )

                break

        except Exception:
            continue

    # --------------------------------------------------------
    # HTML renderizado
    # --------------------------------------------------------

    content = await page.content()

    log.info(
        "HTML RENDERIZADO: %d bytes",
        len(content),
    )

    return content


# ============================================================
# DEBUG
# ============================================================

def save_debug(
    channel: Channel,
    day: date,
    content: str,
) -> None:

    DEBUG_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    filename = (
        f"{channel.slug}_"
        f"{day.strftime('%Y%m%d')}.html"
    )

    path = (
        DEBUG_DIR
        / filename
    )

    path.write_text(
        content,
        encoding="utf-8",
    )

    log.info(
        "Debug salvo: %s",
        path,
    )


# ============================================================
# EXTRAÇÃO DE ELEMENTOS
# ============================================================

def extract_elements(
    content: str,
    channel: Channel,
    day: date,
) -> list[Program]:

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(
        content,
        "lxml",
    )

    programs = []

    # --------------------------------------------------------
    # Todos elementos com data-*
    # --------------------------------------------------------

    for element in soup.find_all(
        True
    ):

        attrs = element.attrs

        if not attrs:
            continue

        text = clean_text(
            element.get_text(
                " ",
                strip=True,
            )
        )

        if not text:
            continue

        start_value = ""

        stop_value = ""

        for key, value in attrs.items():

            key = str(key).lower()

            value = clean_text(
                value
            )

            if (
                "start" in key
                or "begin" in key
            ):

                if parse_time(
                    value
                ):

                    start_value = value

            if (
                "end" in key
                or "stop" in key
            ):

                if parse_time(
                    value
                ):

                    stop_value = value

        # ----------------------------------------------------
        # Se não existe data-start, tentar encontrar
        # horário diretamente no texto.
        # ----------------------------------------------------

        if not start_value:

            match = re.search(
                r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
                text,
            )

            if match:

                start_value = (
                    match.group(0)
                )

        if not start_value:
            continue

        start = build_datetime(
            day,
            start_value,
        )

        if start is None:
            continue

        stop = None

        if stop_value:

            stop = build_datetime(
                day,
                stop_value,
            )

        if stop is None:

            stop = (
                start
                + timedelta(
                    minutes=30
                )
            )

        title = re.sub(
            r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
            "",
            text,
        )

        title = clean_text(
            title
        )

        if not title:
            continue

        programs.append(
            Program(
                channel_id=channel.id,
                title=title,
                start=start,
                stop=stop,
            )
        )

    return programs


# ============================================================
# SCRIPT / JSON
# ============================================================

def parse_json_objects(
    content: str,
    channel: Channel,
    day: date,
) -> list[Program]:

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(
        content,
        "lxml",
    )

    programs = []

    scripts = soup.find_all(
        "script"
    )

    log.info(
        "Scripts encontrados: %d",
        len(scripts),
    )

    for index, script in enumerate(
        scripts
    ):

        text = (
            script.string
            or script.get_text(
                "",
                strip=False,
            )
        )

        if not text:
            continue

        lower = text.lower()

        if (
            "program" not in lower
            and "schedule" not in lower
            and "start" not in lower
        ):
            continue

        # ----------------------------------------------------
        # DEBUG
        # ----------------------------------------------------

        DEBUG_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        debug_file = (
            DEBUG_DIR
            / f"{channel.slug}_"
              f"{day.strftime('%Y%m%d')}_"
              f"script_{index}.txt"
        )

        debug_file.write_text(
            text,
            encoding="utf-8",
        )

        # ----------------------------------------------------
        # Procurar horários
        # ----------------------------------------------------

        time_matches = re.findall(
            r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
            text,
        )

        if time_matches:

            log.info(
                "SCRIPT %d contém %d horários.",
                index,
                len(time_matches),
            )

        # ----------------------------------------------------
        # JSON completo
        # ----------------------------------------------------

        candidates = []

        stripped = text.strip()

        if (
            stripped.startswith("{")
            or stripped.startswith("[")
        ):

            candidates.append(
                stripped
            )

        # ----------------------------------------------------
        # Blocos JSON dentro do JavaScript
        # ----------------------------------------------------

        for pattern in (
            r"\{[^{}]{0,10000}\}",
            r"\[[^\[\]]{0,10000}\]",
        ):

            for match in re.finditer(
                pattern,
                text,
                flags=re.DOTALL,
            ):

                candidates.append(
                    match.group(0)
                )

        # ----------------------------------------------------
        # Parse
        # ----------------------------------------------------

        for candidate in candidates:

            try:

                data = json.loads(
                    candidate
                )

            except Exception:

                continue

            programs.extend(
                find_programs_recursive(
                    data,
                    channel,
                    day,
                )
            )

    return programs


def find_programs_recursive(
    data: Any,
    channel: Channel,
    day: date,
) -> list[Program]:

    result = []

    if isinstance(
        data,
        dict,
    ):

        keys = {
            normalize(
                str(key)
            )
            for key in data
        }

        title = ""

        for key in (
            "title",
            "name",
            "program",
            "programname",
        ):

            if normalize(
                key
            ) in keys:

                for original_key in data:

                    if normalize(
                        str(original_key)
                    ) == normalize(
                        key
                    ):

                        title = clean_text(
                            data[
                                original_key
                            ]
                        )

                        break

            if title:
                break

        start_value = ""

        for key in (
            "start",
            "starttime",
            "startdate",
            "datetime",
            "time",
        ):

            if normalize(
                key
            ) in keys:

                for original_key in data:

                    if normalize(
                        str(original_key)
                    ) == normalize(
                        key
                    ):

                        value = data[
                            original_key
                        ]

                        start_value = clean_text(
                            value
                        )

                        break

            if start_value:
                break

        if title and start_value:

            start = build_datetime(
                day,
                start_value,
            )

            if start:

                stop = (
                    start
                    + timedelta(
                        minutes=30
                    )
                )

                result.append(
                    Program(
                        channel_id=channel.id,
                        title=title,
                        start=start,
                        stop=stop,
                    )
                )

        for value in data.values():

            result.extend(
                find_programs_recursive(
                    value,
                    channel,
                    day,
                )
            )

    elif isinstance(
        data,
        list,
    ):

        for item in data:

            result.extend(
                find_programs_recursive(
                    item,
                    channel,
                    day,
                )
            )

    return result


# ============================================================
# TEXTO
# ============================================================

def extract_text(
    content: str,
    channel: Channel,
    day: date,
) -> list[Program]:

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(
        content,
        "lxml",
    )

    text = soup.get_text(
        "\n",
        strip=True,
    )

    lines = []

    for line in text.splitlines():

        line = clean_text(
            line
        )

        if line:

            lines.append(
                line
            )

    programs = []

    for index, line in enumerate(
        lines
    ):

        match = re.search(
            r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
            line,
        )

        if not match:
            continue

        start_value = (
            match.group(0)
        )

        start = build_datetime(
            day,
            start_value,
        )

        if start is None:
            continue

        title = re.sub(
            r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
            "",
            line,
        )

        title = clean_text(
            title
        )

        if not title:

            if index + 1 < len(
                lines
            ):

                title = clean_text(
                    lines[
                        index + 1
                    ]
                )

        if not title:
            continue

        programs.append(
            Program(
                channel_id=channel.id,
                title=title,
                start=start,
                stop=(
                    start
                    + timedelta(
                        minutes=30
                    )
                ),
            )
        )

    return programs


# ============================================================
# NORMALIZAR
# ============================================================

def normalize_programs(
    programs: list[Program],
) -> list[Program]:

    unique = {}

    for program in programs:

        title = clean_text(
            program.title
        )

        if not title:
            continue

        key = (
            program.channel_id,
            program.start,
            normalize(title),
        )

        unique[key] = program

    result = list(
        unique.values()
    )

    result.sort(
        key=lambda item: (
            item.channel_id,
            item.start,
        )
    )

    # --------------------------------------------------------
    # Corrigir STOP pelo START seguinte
    # --------------------------------------------------------

    grouped = {}

    for program in result:

        grouped.setdefault(
            program.channel_id,
            [],
        ).append(
            program
        )

    final = []

    for channel_id, items in grouped.items():

        for index, program in enumerate(
            items
        ):

            if index + 1 < len(
                items
            ):

                next_program = (
                    items[index + 1]
                )

                if (
                    next_program.start
                    > program.start
                ):

                    program.stop = (
                        next_program.start
                    )

            if (
                program.stop
                <= program.start
            ):

                program.stop = (
                    program.start
                    + timedelta(
                        minutes=30
                    )
                )

            final.append(
                program
            )

    return final


# ============================================================
# BUSCAR UM CANAL
# ============================================================

async def fetch_channel(
    page,
    channel: Channel,
    day: date,
) -> list[Program]:

    url = make_url(
        channel,
        day,
    )

    content = await load_page(
        page,
        url,
    )

    if not content:
        return []

    save_debug(
        channel,
        day,
        content,
    )

    # --------------------------------------------------------
    # Método 1
    # Elementos renderizados
    # --------------------------------------------------------

    programs = extract_elements(
        content,
        channel,
        day,
    )

    if programs:

        log.info(
            "Elementos: %d programas",
            len(programs),
        )

    # --------------------------------------------------------
    # Método 2
    # JSON / JavaScript
    # --------------------------------------------------------

    json_programs = (
        parse_json_objects(
            content,
            channel,
            day,
        )
    )

    if json_programs:

        log.info(
            "JavaScript/JSON: %d programas",
            len(json_programs),
        )

        programs.extend(
            json_programs
        )

    # --------------------------------------------------------
    # Método 3
    # Texto renderizado
    # --------------------------------------------------------

    text_programs = extract_text(
        content,
        channel,
        day,
    )

    if text_programs:

        log.info(
            "Texto: %d programas",
            len(text_programs),
        )

        programs.extend(
            text_programs
        )

    programs = normalize_programs(
        programs
    )

    if programs:

        log.info(
            "✅ TOTAL %s %s: %d programas",
            channel.name,
            day,
            len(programs),
        )

    else:

        log.warning(
            "❌ Nenhum programa encontrado "
            "para %s em %s",
            channel.name,
            day,
        )

    return programs


# ============================================================
# XMLTV
# ============================================================

def xml_time(
    value: datetime,
) -> str:

    return value.strftime(
        "%Y%m%d%H%M%S +0000"
    )


def generate_xml(
    channels: list[Channel],
    programs: list[Program],
) -> str:

    lines = []

    lines.append(
        '<?xml version="1.0" encoding="UTF-8"?>'
    )

    lines.append(
        '<tv generator-info-name="mi.tv EPG Generator" '
        'generator-info-url="https://mi.tv/">'
    )

    # --------------------------------------------------------
    # Canais
    # --------------------------------------------------------

    for channel in channels:

        lines.append(
            f'  <channel id="{xml_escape(channel.id)}">'
        )

        lines.append(
            f'    <display-name lang="pt">'
            f'{xml_escape(channel.name)}'
            f'</display-name>'
        )

        if channel.logo:

            lines.append(
                f'    <icon src="{xml_escape(channel.logo)}" />'
            )

        lines.append(
            "  </channel>"
        )

    # --------------------------------------------------------
    # Programas
    # --------------------------------------------------------

    for program in programs:

        lines.append(
            f'  <programme '
            f'channel="{xml_escape(program.channel_id)}" '
            f'start="{xml_time(program.start)}" '
            f'stop="{xml_time(program.stop)}">'
        )

        lines.append(
            f'    <title lang="pt">'
            f'{xml_escape(program.title)}'
            f'</title>'
        )

        if program.description:

            lines.append(
                f'    <desc lang="pt">'
                f'{xml_escape(program.description)}'
                f'</desc>'
            )

        if program.category:

            lines.append(
                f'    <category lang="pt">'
                f'{xml_escape(program.category)}'
                f'</category>'
            )

        if program.icon:

            lines.append(
                f'    <icon src="'
                f'{xml_escape(program.icon)}'
                f'" />'
            )

        lines.append(
            "  </programme>"
        )

    lines.append(
        "</tv>"
    )

    return "\n".join(
        lines
    ) + "\n"


# ============================================================
# VALIDAR
# ============================================================

def validate(
    channels: list[Channel],
    programs: list[Program],
) -> None:

    if not programs:

        raise RuntimeError(
            "Nenhum programa foi extraído."
        )

    channel_counts = {}

    for program in programs:

        channel_counts[
            program.channel_id
        ] = (
            channel_counts.get(
                program.channel_id,
                0,
            )
            + 1
        )

    log.info(
        "=" * 70
    )

    log.info(
        "📊 RESUMO"
    )

    log.info(
        "=" * 70
    )

    for channel in channels:

        count = channel_counts.get(
            channel.id,
            0,
        )

        log.info(
            "%s: %d programas",
            channel.name,
            count,
        )

    valid = sum(
        1
        for channel in channels
        if channel_counts.get(
            channel.id,
            0,
        )
        >= MIN_PROGRAMS
    )

    if valid == 0:

        raise RuntimeError(
            "Nenhum canal possui programação."
        )

    log.info(
        "Canais com programação: %d/%d",
        valid,
        len(channels),
    )


# ============================================================
# MAIN
# ============================================================

async def async_main() -> int:

    started = time.time()

    log.info(
        "=" * 70
    )

    log.info(
        "📺 GERADOR EPG MI.TV"
    )

    log.info(
        "=" * 70
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    channels = load_channels()

    log.info(
        "Canais carregados: %d",
        len(channels),
    )

    playwright = None

    browser = None

    all_programs = []

    try:

        playwright, browser = (
            await create_browser()
        )

        context = await browser.new_context(
            locale="pt-BR",
            timezone_id="America/Sao_Paulo",
            viewport={
                "width": 1366,
                "height": 900,
            },
            user_agent=(
                "Mozilla/5.0 "
                "(X11; Linux x86_64) "
                "AppleWebKit/537.36 "
                "(KHTML, like Gecko) "
                "Chrome/131.0.0.0 "
                "Safari/537.36"
            ),
        )

        page = await context.new_page()

        # ----------------------------------------------------
        # Bloquear recursos desnecessários
        # ----------------------------------------------------

        async def route_handler(
            route,
        ):

            request = route.request

            resource = request.resource_type

            if resource in {
                "image",
                "font",
                "media",
            }:

                await route.abort()

            else:

                await route.continue_()

        await page.route(
            "**/*",
            route_handler,
        )

        today = date.today()

        for channel in channels:

            channel_programs = []

            log.info("")
            log.info(
                "📡 CANAL: %s",
                channel.name,
            )

            for offset in range(
                DAYS_AHEAD + 1
            ):

                day = (
                    today
                    + timedelta(
                        days=offset
                    )
                )

                programs = (
                    await fetch_channel(
                        page,
                        channel,
                        day,
                    )
                )

                channel_programs.extend(
                    programs
                )

            channel_programs = (
                normalize_programs(
                    channel_programs
                )
            )

            log.info(
                "TOTAL %s: %d programas",
                channel.name,
                len(channel_programs),
            )

            all_programs.extend(
                channel_programs
            )

        all_programs = (
            normalize_programs(
                all_programs
            )
        )

    finally:

        if browser:

            await browser.close()

        if playwright:

            await playwright.stop()

    # --------------------------------------------------------
    # Validar
    # --------------------------------------------------------

    validate(
        channels,
        all_programs,
    )

    # --------------------------------------------------------
    # XML
    # --------------------------------------------------------

    xml = generate_xml(
        channels,
        all_programs,
    )

    # --------------------------------------------------------
    # Validar XML antes de salvar
    # --------------------------------------------------------

    try:

        root = ET.fromstring(
            xml
        )

    except Exception as exc:

        raise RuntimeError(
            f"XML inválido: {exc}"
        )

    if root.tag != "tv":

        raise RuntimeError(
            "XML sem raiz <tv>."
        )

    if not root.findall(
        "channel"
    ):

        raise RuntimeError(
            "XML sem canais."
        )

    if not root.findall(
        "programme"
    ):

        raise RuntimeError(
            "XML sem programas."
        )

    # --------------------------------------------------------
    # Salvar
    # --------------------------------------------------------

    temporary = (
        OUTPUT_DIR
        / "epg.xml.tmp"
    )

    temporary.write_text(
        xml,
        encoding="utf-8",
    )

    temporary.replace(
        OUTPUT_FILE
    )

    size = OUTPUT_FILE.stat().st_size

    log.info("")
    log.info(
        "=" * 70
    )

    log.info(
        "✅ EPG GERADO COM SUCESSO"
    )

    log.info(
        "=" * 70
    )

    log.info(
        "Arquivo: %s",
        OUTPUT_FILE,
    )

    log.info(
        "Tamanho: %d bytes",
        size,
    )

    log.info(
        "Canais: %d",
        len(channels),
    )

    log.info(
        "Programas: %d",
        len(all_programs),
    )

    log.info(
        "Tempo: %.2f segundos",
        time.time() - started,
    )

    return 0


def main() -> int:

    try:

        return asyncio.run(
            async_main()
        )

    except KeyboardInterrupt:

        log.error(
            "Execução interrompida."
        )

        return 130

    except Exception as exc:

        log.exception(
            "❌ ERRO FATAL: %s",
            exc,
        )

        return 1


if __name__ == "__main__":

    sys.exit(
        main()
    )
