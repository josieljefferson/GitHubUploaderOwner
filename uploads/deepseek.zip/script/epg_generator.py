#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
=============================================================
                🚀 IPTV EPG GENERATOR
=============================================================

Gera:

    output/epg.xml
    output/epg.xml.gz       -> gerado pelo GitHub Actions
    output/playlists.m3u
    output/epg-report.json

Prioridade de fontes (definida em config/channels.json):

    1. mi.tv          (priority = 1)
    2. TV Map         (priority = 2)
    3. ALEPI          (priority = 3)
    4. Guia de TV     (priority = 4)

Fallback:

    Para cada CANAL e DIA:
        fonte 1
          ↓ falhou / sem programação
        fonte 2
          ↓ falhou / sem programação
        fonte 3
          ↓ falhou / sem programação
        fonte 4

Nenhuma fonte posterior é consultada depois que uma fonte
anterior fornece programação válida para aquele canal/dia.

Recursos:

    ✓ XMLTV
    ✓ Playlist M3U
    ✓ Guia de TV por categorias
    ✓ ALEPI
    ✓ mi.tv (com suporte a múltiplos slugs)
    ✓ TV Map
    ✓ fallback automático
    ✓ retries
    ✓ timeout
    ✓ deduplicação
    ✓ relatório JSON
    ✓ gravação atômica
    ✓ preservação do EPG anterior em caso de falha grave
    ✓ proteção contra queda brusca de quantidade de programas
    ✓ execução em GitHub Actions
"""

from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import re
import sys
import traceback
import unicodedata

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import xml.etree.ElementTree as ET


# =============================================================
# CAMINHOS
# =============================================================

ROOT = Path(__file__).resolve().parent.parent

CONFIG_FILE = ROOT / "config" / "channels.json"

OUTPUT_DIR = ROOT / "output"

OUTPUT_FILE = OUTPUT_DIR / "epg.xml"
OUTPUT_GZ_FILE = OUTPUT_DIR / "epg.xml.gz"
PLAYLIST_FILE = OUTPUT_DIR / "playlists.m3u"
REPORT_FILE = OUTPUT_DIR / "epg-report.json"

DEBUG_DIR = ROOT / "debug_epg"


# =============================================================
# CONFIGURAÇÕES
# =============================================================

BR_TZ = timezone(timedelta(hours=-3))

DAYS_AHEAD_ENV = os.getenv("MITV_DAYS_AHEAD")

MIN_PROGRAMS = max(
    1,
    int(os.getenv("MITV_MIN_PROGRAMS", "1")),
)

PAGE_TIMEOUT = max(
    10000,
    int(os.getenv("MITV_PAGE_TIMEOUT", "60000")),
)

WAIT_AFTER_LOAD = max(
    0,
    int(os.getenv("MITV_WAIT", "3000")),
)

MAX_RETRIES = max(
    1,
    int(os.getenv("MITV_RETRIES", "3")),
)

MIN_CHANNEL_COVERAGE = max(
    0.0,
    min(1.0, float(os.getenv("EPG_MIN_CHANNEL_COVERAGE", "0.50"))),
)

MIN_PROGRAM_RATIO = max(
    0.0,
    min(1.0, float(os.getenv("EPG_MIN_PROGRAM_RATIO", "0.50"))),
)

REQUIRE_ALL_CHANNELS = (
    os.getenv("EPG_REQUIRE_ALL_CHANNELS", "0").lower()
    in {"1", "true", "yes", "sim"}
)


# =============================================================
# REGEX
# =============================================================

TIME_RE = re.compile(
    r"(?<!\d)(?:[01]?\d|2[0-3]):[0-5]\d(?!\d)"
)

DATE_TIME_RE = re.compile(
    r"\b\d{1,2}/\d{1,2}/\d{2,4}\s+"
    r"(?:[01]?\d|2[0-3]):[0-5]\d\b"
)


# =============================================================
# LOG
# =============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

LOGGER = logging.getLogger("epg")


# =============================================================
# DATA CLASSES
# =============================================================

@dataclass
class Channel:
    id: str
    name: str
    slug: str = ""
    alt_slugs: list[str] = field(default_factory=list)
    logo: str = ""
    source: str = ""
    stream: str = ""
    group: str = "Brasil"
    aliases: list[str] = field(default_factory=list)


@dataclass
class Program:
    channel_id: str
    title: str
    start: datetime
    stop: datetime
    description: str = ""
    category: str = ""
    icon: str = ""
    source: str = ""


@dataclass
class EPGSource:
    id: str
    name: str
    priority: int
    url: str = ""
    channel_url: str = ""
    urls: list[str] = field(default_factory=list)
    categories: list[dict[str, str]] = field(default_factory=list)
    only_channels: list[str] = field(default_factory=list)


@dataclass
class FetchResult:
    programs: list[Program] = field(default_factory=list)
    detail: str = ""


# =============================================================
# TEXTO
# =============================================================

def clean_text(value: Any) -> str:
    if value is None:
        return ""

    text = html.unescape(str(value))

    text = (
        text.replace("\xa0", " ")
        .replace("\r", "\n")
        .replace("\t", " ")
    )

    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


def normalize(value: Any) -> str:
    text = clean_text(value).lower()

    text = unicodedata.normalize(
        "NFKD",
        text,
    )

    text = "".join(
        char
        for char in text
        if not unicodedata.combining(char)
    )

    text = re.sub(r"[^a-z0-9]+", " ", text)

    return re.sub(r"\s+", " ", text).strip()


def xml_escape(value: Any) -> str:
    return (
        html.escape(
            clean_text(value),
            quote=True,
        )
    )


def m3u_attr(value: Any) -> str:
    return (
        clean_text(value)
        .replace('"', "'")
        .replace("\n", " ")
        .strip()
    )


# =============================================================
# DATAS
# =============================================================

def today_br() -> date:
    return datetime.now(BR_TZ).date()


def requested_days(days_ahead: int) -> list[date]:
    return [
        today_br() + timedelta(days=index)
        for index in range(days_ahead)
    ]


def build_datetime(day: date, time_text: str) -> datetime | None:
    match = TIME_RE.search(clean_text(time_text))

    if not match:
        return None

    hour, minute = map(
        int,
        match.group(0).split(":"),
    )

    return datetime(
        day.year,
        day.month,
        day.day,
        hour,
        minute,
        tzinfo=BR_TZ,
    )


def parse_datetime_value(
    day: date,
    value: Any,
) -> datetime | None:

    if value is None:
        return None

    if isinstance(value, (int, float)):
        try:
            number = float(value)

            if number > 1_000_000_000:
                return datetime.fromtimestamp(
                    number,
                    tz=BR_TZ,
                )
        except Exception:
            pass

    text = clean_text(value)

    if not text:
        return None

    # ISO.
    try:
        parsed = datetime.fromisoformat(
            text.replace("Z", "+00:00")
        )

        if parsed.tzinfo is None:
            parsed = parsed.replace(
                tzinfo=BR_TZ
            )

        return parsed.astimezone(BR_TZ)

    except Exception:
        pass

    # Data + hora.
    match = DATE_TIME_RE.search(text)

    if match:
        try:
            raw = match.group(0)

            parsed = datetime.strptime(
                raw,
                "%d/%m/%Y %H:%M",
            )

            return parsed.replace(
                tzinfo=BR_TZ
            )

        except Exception:
            pass

    return build_datetime(
        day,
        text,
    )


# =============================================================
# CONFIGURAÇÃO
# =============================================================

def default_sources() -> list[EPGSource]:

    return [
        # -----------------------------------------------------
        # PRIORIDADE 1 — mi.tv
        # -----------------------------------------------------
        EPGSource(
            id="mitv",
            name="mi.tv",
            priority=1,
            url="https://mi.tv/br/programacao",
            channel_url=(
                "https://mi.tv/br/canais/{slug}"
            ),
        ),

        # -----------------------------------------------------
        # PRIORIDADE 2 — TV Map
        # -----------------------------------------------------
        EPGSource(
            id="tvmap",
            name="TV Map",
            priority=2,
            urls=[
                "https://tvmap.com.br/Programacao",
                "https://tvmap.com.br/TV-Aberta",
                "https://tvmap.com.br/Principais",
                "https://tvmap.com.br/Claro-TV",
                "https://tvmap.com.br/SKY",
                "https://tvmap.com.br/GVT-TV",
                "https://tvmap.com.br/Vivo-TV",
            ],
        ),

        # -----------------------------------------------------
        # PRIORIDADE 3 — ALEPI
        # -----------------------------------------------------
        EPGSource(
            id="alepi",
            name="ALEPI",
            priority=3,
            url=(
                "https://www.al.pi.leg.br/"
                "comunicacao/tv-assembleia/programacao"
            ),
            only_channels=[
                "tv.assembleia.piaui.br"
            ],
        ),

        # -----------------------------------------------------
        # PRIORIDADE 4 — Guia de TV
        # -----------------------------------------------------
        EPGSource(
            id="guiadetv",
            name="Guia de TV",
            priority=4,
            categories=[
                {
                    "id": "filmes-series",
                    "name": "Filmes e Séries",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/filmes-e-series.html"
                    ),
                },
                {
                    "id": "documentarios",
                    "name": "Documentários",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/documentarios.html"
                    ),
                },
                {
                    "id": "esportes",
                    "name": "Esportes",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/esportes.html"
                    ),
                },
                {
                    "id": "infantil",
                    "name": "Infantil",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/infantil.html"
                    ),
                },
                {
                    "id": "tv-aberta",
                    "name": "TV Aberta",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/tv-aberta.html"
                    ),
                },
                {
                    "id": "noticias",
                    "name": "Notícias",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/noticias.html"
                    ),
                },
                {
                    "id": "variedades",
                    "name": "Variedades",
                    "url": (
                        "https://www.guiadetv.com/"
                        "categorias/variedades.html"
                    ),
                },
            ],
        ),
    ]


def load_config() -> tuple[list[Channel], list[EPGSource], int]:

    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Configuração não encontrada: {CONFIG_FILE}"
        )

    data = json.loads(
        CONFIG_FILE.read_text(
            encoding="utf-8"
        )
    )

    settings = data.get(
        "settings",
        {},
    )

    config_days = int(
        settings.get("days", 2)
    )

    days_ahead = (
        int(DAYS_AHEAD_ENV)
        if DAYS_AHEAD_ENV
        else config_days
    )

    days_ahead = max(
        1,
        days_ahead,
    )

    channels: list[Channel] = []

    seen_ids: set[str] = set()

    for item in data.get("channels", []):

        channel_id = clean_text(
            item.get("id")
        )

        name = clean_text(
            item.get("name")
        )

        if not channel_id:
            raise ValueError(
                "Canal sem id."
            )

        if not name:
            raise ValueError(
                f"Canal {channel_id} sem name."
            )

        if channel_id in seen_ids:
            raise ValueError(
                f"ID de canal duplicado: {channel_id}"
            )

        seen_ids.add(channel_id)

        aliases = item.get(
            "aliases",
            [],
        )

        if not isinstance(aliases, list):
            aliases = []

        aliases = [
            clean_text(alias)
            for alias in aliases
            if clean_text(alias)
        ]

        if name not in aliases:
            aliases.insert(
                0,
                name,
            )

        # -----------------------------------------------------
        # alt_slugs (opcional): múltiplos slugs de mi.tv
        # -----------------------------------------------------
        alt_slugs = item.get(
            "alt_slugs",
            [],
        )

        if not isinstance(alt_slugs, list):
            alt_slugs = []

        alt_slugs = [
            clean_text(slug)
            for slug in alt_slugs
            if clean_text(slug)
        ]

        # Aceita tanto stream quanto url.
        stream = clean_text(
            item.get("stream")
            or item.get("url")
            or ""
        )

        channels.append(
            Channel(
                id=channel_id,
                name=name,
                slug=clean_text(
                    item.get("slug")
                ),
                alt_slugs=alt_slugs,
                logo=clean_text(
                    item.get("logo")
                ),
                source=clean_text(
                    item.get("source")
                ),
                stream=stream,
                group=clean_text(
                    item.get(
                        "group",
                        "Brasil",
                    )
                ) or "Brasil",
                aliases=aliases,
            )
        )

    if not channels:
        raise ValueError(
            "Nenhum canal encontrado em channels.json."
        )

    sources: list[EPGSource] = []

    configured_sources = settings.get(
        "sources"
    )

    if not configured_sources:
        sources = default_sources()

    else:
        for item in configured_sources:

            source_id = clean_text(
                item.get("id")
            )

            if not source_id:
                continue

            categories = item.get(
                "categories",
                [],
            )

            if not isinstance(categories, list):
                categories = []

            categories_clean = []

            for category in categories:

                if not isinstance(
                    category,
                    dict,
                ):
                    continue

                categories_clean.append(
                    {
                        "id": clean_text(
                            category.get("id")
                        ),
                        "name": clean_text(
                            category.get("name")
                        ),
                        "url": clean_text(
                            category.get("url")
                        ),
                    }
                )

            urls = item.get(
                "urls",
                [],
            )

            if not isinstance(urls, list):
                urls = []

            sources.append(
                EPGSource(
                    id=source_id,
                    name=clean_text(
                        item.get(
                            "name",
                            source_id,
                        )
                    ),
                    priority=int(
                        item.get(
                            "priority",
                            999,
                        )
                    ),
                    url=clean_text(
                        item.get("url")
                    ),
                    channel_url=clean_text(
                        item.get(
                            "channel_url"
                        )
                    ),
                    urls=[
                        clean_text(url)
                        for url in urls
                        if clean_text(url)
                    ],
                    categories=categories_clean,
                    only_channels=[
                        clean_text(channel)
                        for channel in item.get(
                            "only_channels",
                            [],
                        )
                        if clean_text(channel)
                    ],
                )
            )

    if not sources:
        sources = default_sources()

    # Compatibilidade com configuração antiga:
    # se um canal tiver source próprio e essa URL ainda
    # não estiver configurada, cria uma fonte exclusiva.
    configured_ids = {
        source.id
        for source in sources
    }

    for channel in channels:

        if (
            channel.source
            and channel.id not in configured_ids
        ):
            sources.insert(
                0,
                EPGSource(
                    id=f"custom-{channel.id}",
                    name=f"{channel.name} - fonte personalizada",
                    priority=0,
                    url=channel.source,
                    only_channels=[
                        channel.id
                    ],
                )
            )

    sources.sort(
        key=lambda source: (
            source.priority,
            source.id,
        )
    )

    return (
        channels,
        sources,
        days_ahead,
    )


# =============================================================
# MATCH DE CANAL
# =============================================================

def text_contains_alias(
    text: str,
    channel: Channel,
) -> bool:

    normalized_text = normalize(text)

    if not normalized_text:
        return False

    for alias in channel.aliases:

        alias_normalized = normalize(
            alias
        )

        if not alias_normalized:
            continue

        # Match de linha inteira.
        for line in normalized_text.split("\n"):

            line = normalize(line)

            if line == alias_normalized:
                return True

    return False


def alias_exact(text: str, channel: Channel) -> bool:

    normalized = normalize(text)

    for alias in channel.aliases:

        if normalized == normalize(alias):
            return True

    return False


# =============================================================
# BEAUTIFULSOUP
# =============================================================

def get_soup(content: str):

    from bs4 import BeautifulSoup

    return BeautifulSoup(
        content,
        "html.parser",
    )


# =============================================================
# BLOCO DO CANAL
# =============================================================

def find_channel_block(
    content: str,
    channel: Channel,
) -> str:

    soup = get_soup(content)

    candidates: list[tuple[int, str]] = []

    # ---------------------------------------------------------
    # Procura imagens com alt/title.
    # ---------------------------------------------------------

    for image in soup.find_all("img"):

        values = [
            image.get("alt", ""),
            image.get("title", ""),
        ]

        if not any(
            alias_exact(value, channel)
            for value in values
            if value
        ):
            continue

        node = image

        for depth in range(10):

            if node is None:
                break

            text = clean_text(
                node.get_text(
                    "\n",
                    strip=True,
                )
            )

            if (
                10 <= len(text) <= 6000
                and TIME_RE.findall(text)
                and text_contains_alias(
                    text,
                    channel,
                )
            ):

                time_count = len(
                    TIME_RE.findall(text)
                )

                if time_count <= 50:

                    score = (
                        time_count * 1000
                        - len(text)
                        - depth * 20
                    )

                    candidates.append(
                        (
                            score,
                            text,
                        )
                    )

            node = node.parent

    # ---------------------------------------------------------
    # Procura elementos cujo texto seja o nome do canal.
    # ---------------------------------------------------------

    for element in soup.find_all(
        [
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "strong",
            "b",
            "a",
            "span",
            "div",
            "li",
        ]
    ):

        direct = clean_text(
            element.get_text(
                " ",
                strip=True,
            )
        )

        if not alias_exact(
            direct,
            channel,
        ):
            continue

        node = element

        for depth in range(10):

            if node is None:
                break

            text = clean_text(
                node.get_text(
                    "\n",
                    strip=True,
                )
            )

            times = TIME_RE.findall(
                text
            )

            if (
                10 <= len(text) <= 6000
                and times
                and len(times) <= 50
                and text_contains_alias(
                    text,
                    channel,
                )
            ):

                score = (
                    len(times) * 1000
                    - len(text)
                    - depth * 20
                )

                candidates.append(
                    (
                        score,
                        text,
                    )
                )

            node = node.parent

    if candidates:
        candidates.sort(
            key=lambda item: item[0],
            reverse=True,
        )

        return candidates[0][1]

    return ""


# =============================================================
# PARSER DE PROGRAMAS
# =============================================================

def parse_program_block(
    text: str,
    channel: Channel,
    day: date,
    source_id: str,
) -> list[Program]:

    text = clean_text(text)

    matches = list(
        TIME_RE.finditer(text)
    )

    if not matches:
        return []

    programs: list[Program] = []

    previous_minutes: int | None = None
    rollover = 0

    for index, match in enumerate(matches):

        time_text = match.group(0)

        hour, minute = map(
            int,
            time_text.split(":"),
        )

        current_minutes = (
            hour * 60 + minute
        )

        if (
            previous_minutes is not None
            and current_minutes < previous_minutes
            and (
                previous_minutes
                - current_minutes
            ) > 120
        ):
            rollover += 1

        previous_minutes = current_minutes

        event_day = (
            day + timedelta(days=rollover)
        )

        start = datetime(
            event_day.year,
            event_day.month,
            event_day.day,
            hour,
            minute,
            tzinfo=BR_TZ,
        )

        next_position = (
            matches[index + 1].start()
            if index + 1 < len(matches)
            else len(text)
        )

        title = text[
            match.end():next_position
        ]

        title = clean_text(
            title
        )

        title = re.sub(
            r"^[\s\-–—:|•·]+",
            "",
            title,
        )

        title = re.sub(
            r"[\s\-–—:|•·]+$",
            "",
            title,
        )

        # Remove lixo muito curto.
        if len(title) < 2:
            continue

        # Não considerar o próprio canal como programa.
        if normalize(title) in {
            normalize(channel.name),
            *[
                normalize(alias)
                for alias in channel.aliases
            ],
        }:
            continue

        # Somente programas pertencentes ao dia solicitado.
        if start.date() != day:
            continue

        programs.append(
            Program(
                channel_id=channel.id,
                title=title,
                start=start,
                stop=start + timedelta(
                    minutes=30
                ),
                source=source_id,
            )
        )

    return programs


# =============================================================
# NORMALIZAÇÃO
# =============================================================

def normalize_programs(
    programs: list[Program],
    requested_day: date | None = None,
) -> list[Program]:

    unique: dict[
        tuple[str, str, str],
        Program
    ] = {}

    for program in programs:

        if requested_day:
            if program.start.date() != requested_day:
                continue

        title = clean_text(
            program.title
        )

        if len(title) < 2:
            continue

        key = (
            program.channel_id,
            program.start.isoformat(),
            normalize(title),
        )

        unique[key] = Program(
            channel_id=program.channel_id,
            title=title,
            start=program.start,
            stop=program.stop,
            description=clean_text(
                program.description
            ),
            category=clean_text(
                program.category
            ),
            icon=clean_text(
                program.icon
            ),
            source=program.source,
        )

    result = sorted(
        unique.values(),
        key=lambda item: (
            item.channel_id,
            item.start,
        ),
    )

    # ---------------------------------------------------------
    # Corrige o STOP usando o próximo programa.
    # ---------------------------------------------------------

    grouped: dict[
        str,
        list[Program]
    ] = {}

    for program in result:
        grouped.setdefault(
            program.channel_id,
            [],
        ).append(program)

    final: list[Program] = []

    for channel_programs in grouped.values():

        for index, program in enumerate(
            channel_programs
        ):

            if (
                index + 1
                < len(channel_programs)
            ):

                next_program = (
                    channel_programs[
                        index + 1
                    ]
                )

                if (
                    next_program.start
                    > program.start
                ):
                    program.stop = (
                        next_program.start
                    )

            if program.stop <= program.start:
                program.stop = (
                    program.start
                    + timedelta(minutes=30)
                )

            final.append(program)

    return final


# =============================================================
# JSON
# =============================================================

def iter_json_objects(
    text: str,
    maximum: int = 50,
):

    decoder = json.JSONDecoder()
    found = 0

    for match in re.finditer(
        r"[\{\[]",
        text,
    ):

        if found >= maximum:
            break

        start = match.start()

        try:
            value, _ = decoder.raw_decode(
                text[start:]
            )

            found += 1

            yield value

        except Exception:
            continue


def parse_json_programs(
    content: str,
    channel: Channel,
    day: date,
    source_id: str,
) -> list[Program]:

    soup = get_soup(content)

    programs: list[Program] = []

    def walk(
        value: Any,
    ):

        if isinstance(value, dict):

            normalized_keys = {
                normalize(key): key
                for key in value.keys()
            }

            title_key = next(
                (
                    normalized_keys[key]
                    for key in (
                        "title",
                        "name",
                        "program",
                        "program name",
                        "programname",
                    )
                    if key in normalized_keys
                ),
                None,
            )

            start_key = next(
                (
                    normalized_keys[key]
                    for key in (
                        "start",
                        "start time",
                        "starttime",
                        "start_date",
                        "datetime",
                        "date",
                        "time",
                    )
                    if key in normalized_keys
                ),
                None,
            )

            stop_key = next(
                (
                    normalized_keys[key]
                    for key in (
                        "stop",
                        "end",
                        "endtime",
                        "end time",
                        "finish",
                    )
                    if key in normalized_keys
                ),
                None,
            )

            if (
                title_key is not None
                and start_key is not None
            ):

                title = clean_text(
                    value.get(title_key)
                )

                start = parse_datetime_value(
                    day,
                    value.get(start_key),
                )

                stop = (
                    parse_datetime_value(
                        day,
                        value.get(stop_key),
                    )
                    if stop_key is not None
                    else None
                )

                if (
                    title
                    and start
                    and start.date() == day
                ):

                    if stop is None:
                        stop = (
                            start
                            + timedelta(
                                minutes=30
                            )
                        )

                    programs.append(
                        Program(
                            channel_id=channel.id,
                            title=title,
                            start=start,
                            stop=stop,
                            description=clean_text(
                                value.get(
                                    "description",
                                    ""
                                )
                            ),
                            category=clean_text(
                                value.get(
                                    "category",
                                    ""
                                )
                            ),
                            source=source_id,
                        )
                    )

            for child in value.values():
                walk(child)

        elif isinstance(value, list):

            for child in value:
                walk(child)

    for script in soup.find_all(
        "script"
    ):

        script_text = script.string or script.get_text()

        if not script_text:
            continue

        for value in iter_json_objects(
            script_text
        ):
            walk(value)

    return programs


# =============================================================
# DOM
# =============================================================

def extract_dom_programs(
    content: str,
    channel: Channel,
    day: date,
    source_id: str,
) -> list[Program]:

    soup = get_soup(content)

    programs: list[Program] = []

    for element in soup.find_all(True):

        attrs = element.attrs

        start_value = ""

        stop_value = ""

        for key, value in attrs.items():

            normalized_key = normalize(
                key
            )

            if normalized_key in {
                "start",
                "data start",
                "data start time",
                "starttime",
                "data starttime",
            }:
                start_value = clean_text(
                    value
                )

            if normalized_key in {
                "end",
                "stop",
                "data end",
                "data stop",
                "endtime",
            }:
                stop_value = clean_text(
                    value
                )

        if not start_value:
            text = clean_text(
                element.get_text(
                    " ",
                    strip=True,
                )
            )

            match = TIME_RE.search(text)

            if not match:
                continue

            start_value = match.group(0)

        start = parse_datetime_value(
            day,
            start_value,
        )

        if not start:
            continue

        if start.date() != day:
            continue

        stop = parse_datetime_value(
            day,
            stop_value,
        )

        if stop is None:
            stop = (
                start
                + timedelta(minutes=30)
            )

        text = clean_text(
            element.get_text(
                " ",
                strip=True,
            )
        )

        # Retira o horário.
        title = TIME_RE.sub(
            "",
            text,
            count=1,
        )

        title = clean_text(
            title
        ).strip(
            " -–—:|•·"
        )

        if len(title) < 2:
            continue

        if len(title) > 300:
            continue

        programs.append(
            Program(
                channel_id=channel.id,
                title=title,
                start=start,
                stop=stop,
                source=source_id,
            )
        )

    return programs


# =============================================================
# PLAYWRIGHT
# =============================================================

async def create_browser():

    from playwright.async_api import (
        async_playwright,
    )

    playwright = await async_playwright().start()

    browser = await playwright.chromium.launch(
        headless=True,
        args=[
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu",
            "--no-zygote",
            "--single-process",
        ],
    )

    context = await browser.new_context(
        locale="pt-BR",
        timezone_id="America/Sao_Paulo",
        user_agent=(
            "Mozilla/5.0 "
            "(X11; Linux x86_64) "
            "AppleWebKit/537.36 "
            "(KHTML, like Gecko) "
            "Chrome/131.0.0.0 "
            "Safari/537.36"
        ),
        extra_http_headers={
            "Accept-Language":
                "pt-BR,pt;q=0.9,en;q=0.5"
        },
    )

    page = await context.new_page()

    page.set_default_timeout(
        PAGE_TIMEOUT
    )

    async def route_handler(route):

        resource_type = route.request.resource_type

        if resource_type in {
            "image",
            "font",
            "media",
        }:
            await route.abort()
        else:
            await route.continue_()

    await page.route(
        "**/*",
        route_handler,
    )

    return (
        playwright,
        browser,
        context,
        page,
    )


# =============================================================
# HTTP / HTML
# =============================================================

async def load_page(
    page,
    url: str,
) -> str:

    last_error = ""

    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            LOGGER.info(
                "🌐 %s | tentativa %d/%d",
                url,
                attempt,
                MAX_RETRIES,
            )

            response = await page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=PAGE_TIMEOUT,
            )

            status = (
                response.status
                if response
                else 0
            )

            if status >= 400:
                raise RuntimeError(
                    f"HTTP {status}"
                )

            try:
                await page.wait_for_load_state(
                    "networkidle",
                    timeout=15000,
                )
            except Exception:
                pass

            if WAIT_AFTER_LOAD:
                await page.wait_for_timeout(
                    WAIT_AFTER_LOAD
                )

            content = await page.content()

            if len(content) < 200:
                raise RuntimeError(
                    "Página retornou conteúdo vazio."
                )

            return content

        except Exception as exc:

            last_error = str(exc)

            LOGGER.warning(
                "⚠️ Falha ao acessar %s: %s",
                url,
                exc,
            )

            if attempt < MAX_RETRIES:
                await asyncio.sleep(
                    min(
                        2 ** (attempt - 1),
                        8,
                    )
                )

    raise RuntimeError(
        f"Falha após {MAX_RETRIES} tentativas: "
        f"{url} | {last_error}"
    )


# =============================================================
# DEBUG
# =============================================================

def save_debug(
    source_id: str,
    channel: Channel,
    day: date,
    content: str,
):

    try:

        DEBUG_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        safe_source = re.sub(
            r"[^a-zA-Z0-9_.-]+",
            "_",
            source_id,
        )

        safe_channel = re.sub(
            r"[^a-zA-Z0-9_.-]+",
            "_",
            channel.id,
        )

        file_path = (
            DEBUG_DIR
            / f"{safe_source}_"
              f"{safe_channel}_"
              f"{day.isoformat()}.html"
        )

        file_path.write_text(
            content,
            encoding="utf-8",
        )

    except Exception:
        LOGGER.debug(
            "Não foi possível salvar debug.",
            exc_info=True,
        )


# =============================================================
# SOURCE: ALEPI
# =============================================================

async def fetch_alepi(
    page,
    source: EPGSource,
    channel: Channel,
    day: date,
) -> FetchResult:

    # Página informada pelo usuário é a programação atual.
    # Não reutilizamos programação de hoje para dias futuros.
    if day != today_br():
        return FetchResult(
            detail="ALEPI disponível apenas para o dia atual."
        )

    if not source.url:
        return FetchResult(
            detail="URL ALEPI não configurada."
        )

    content = await load_page(
        page,
        source.url,
    )

    save_debug(
        source.id,
        channel,
        day,
        content,
    )

    block = find_channel_block(
        content,
        channel,
    )

    if block:
        programs = parse_program_block(
            block,
            channel,
            day,
            source.id,
        )

        programs = normalize_programs(
            programs,
            day,
        )

        if programs:
            return FetchResult(
                programs=programs,
                detail="Bloco do canal localizado.",
            )

    # Página dedicada também pode ser interpretada
    # diretamente caso o HTML não possua um bloco detectável.
    programs = parse_program_block(
        get_soup(content).get_text(
            "\n",
            strip=True,
        ),
        channel,
        day,
        source.id,
    )

    programs = normalize_programs(
        programs,
        day,
    )

    return FetchResult(
        programs=programs,
        detail=(
            "Parser geral ALEPI."
            if programs
            else "Canal/programação não encontrada."
        ),
    )


# =============================================================
# SOURCE: GUIA DE TV
# =============================================================

async def fetch_guiadetv(
    page,
    source: EPGSource,
    channel: Channel,
    day: date,
) -> FetchResult:

    # As categorias fornecidas são páginas de programação
    # do dia atual. Não copiamos essa programação para amanhã.
    if day != today_br():
        return FetchResult(
            detail=(
                "Guia de TV ignorado para "
                "dias futuros."
            )
        )

    checked = []

    for category in source.categories:

        url = clean_text(
            category.get("url")
        )

        category_name = clean_text(
            category.get("name")
        )

        if not url:
            continue

        checked.append(
            category_name or url
        )

        try:

            content = await load_page(
                page,
                url,
            )

            save_debug(
                f"{source.id}-{category.get('id', 'category')}",
                channel,
                day,
                content,
            )

            block = find_channel_block(
                content,
                channel,
            )

            if not block:
                continue

            programs = parse_program_block(
                block,
                channel,
                day,
                f"{source.id}:{category.get('id', '')}",
            )

            programs = normalize_programs(
                programs,
                day,
            )

            if programs:

                return FetchResult(
                    programs=programs,
                    detail=(
                        f"Categoria: "
                        f"{category_name or category.get('id', '')}"
                    ),
                )

        except Exception as exc:

            LOGGER.warning(
                "⚠️ Guia de TV [%s] %s: %s",
                category_name,
                channel.name,
                exc,
            )

            continue

    return FetchResult(
        detail=(
            "Canal não localizado nas categorias: "
            + ", ".join(checked)
            if checked
            else "Nenhuma categoria configurada."
        )
    )


# =============================================================
# SOURCE: MI.TV
# =============================================================

def make_mitv_url(
    source: EPGSource,
    channel: Channel,
    day: date,
    slug: str = "",
) -> str:

    slug = clean_text(slug) or channel.slug

    if not slug:
        return ""

    template = (
        source.channel_url
        or "https://mi.tv/br/canais/{slug}"
    )

    url = template.format(
        slug=slug,
        date=day.isoformat(),
    )

    # Para dias futuros, tenta o padrão utilizado
    # pelo mi.tv.
    if (
        day != today_br()
        and "{date}" not in template
        and url.rstrip("/").endswith(slug)
    ):
        url = (
            url.rstrip("/")
            + "/"
            + day.isoformat()
        )

    return url


def slug_candidates(channel: Channel) -> list[str]:
    """
    Retorna lista única de slugs candidatos para mi.tv,
    priorizando o slug principal e depois os alternativos.
    """

    candidates: list[str] = []
    seen: set[str] = set()

    for value in [channel.slug, *channel.alt_slugs]:

        slug = clean_text(value)

        if slug and slug not in seen:
            seen.add(slug)
            candidates.append(slug)

    return candidates


async def fetch_mitv(
    page,
    source: EPGSource,
    channel: Channel,
    day: date,
) -> FetchResult:

    slugs = slug_candidates(channel)

    if not slugs:
        return FetchResult(
            detail="Canal sem slug para mi.tv."
        )

    last_detail = ""

    for slug in slugs:

        url = make_mitv_url(
            source,
            channel,
            day,
            slug,
        )

        if not url:
            continue

        try:

            content = await load_page(
                page,
                url,
            )

        except Exception as exc:

            last_detail = (
                f"Slug '{slug}' falhou: {exc}"
            )

            LOGGER.warning(
                "⚠️ mi.tv slug '%s' para %s: %s",
                slug,
                channel.name,
                exc,
            )

            continue

        save_debug(
            f"{source.id}-{slug}",
            channel,
            day,
            content,
        )

        programs: list[Program] = []

        # 1. JSON.
        programs.extend(
            parse_json_programs(
                content,
                channel,
                day,
                source.id,
            )
        )

        # 2. DOM.
        programs.extend(
            extract_dom_programs(
                content,
                channel,
                day,
                source.id,
            )
        )

        # 3. Texto.
        soup = get_soup(content)

        text = soup.get_text(
            "\n",
            strip=True,
        )

        programs.extend(
            parse_program_block(
                text,
                channel,
                day,
                source.id,
            )
        )

        programs = normalize_programs(
            programs,
            day,
        )

        if programs:

            return FetchResult(
                programs=programs,
                detail=(
                    f"Programação encontrada "
                    f"(slug='{slug}')."
                ),
            )

        last_detail = (
            f"Slug '{slug}' não retornou "
            f"programas."
        )

    return FetchResult(
        detail=(
            last_detail
            or "Nenhum slug retornou programação."
        )
    )


# =============================================================
# SOURCE: TV MAP
# =============================================================

TVMAP_MONTHS = [
    "jan",
    "fev",
    "mar",
    "abr",
    "mai",
    "jun",
    "jul",
    "ago",
    "set",
    "out",
    "nov",
    "dez",
]


def tvmap_programacao_url(
    day: date,
    hour: int,
) -> str:

    month = TVMAP_MONTHS[
        day.month - 1
    ]

    return (
        "https://tvmap.com.br/"
        "Programacao/"
        f"{day.day:02d}-{month}-{day.year}/"
        f"{hour:02d}.00hs"
    )


def build_tvmap_urls(
    source: EPGSource,
    day: date,
) -> list[str]:

    urls: list[str] = []

    # Páginas fornecidas pelo usuário.
    if day == today_br():

        urls.extend(
            source.urls
        )

    # Páginas de programação por horário.
    # Cobrem 24 horas.
    for hour in (
        0,
        6,
        12,
        18,
    ):
        urls.append(
            tvmap_programacao_url(
                day,
                hour,
            )
        )

    # Remove duplicados preservando ordem.
    result = []

    seen = set()

    for url in urls:

        if url and url not in seen:
            seen.add(url)
            result.append(url)

    return result


async def fetch_tvmap(
    page,
    source: EPGSource,
    channel: Channel,
    day: date,
) -> FetchResult:

    programs: list[Program] = []

    urls = build_tvmap_urls(
        source,
        day,
    )

    successful_pages = 0

    for url in urls:

        try:

            content = await load_page(
                page,
                url,
            )

            successful_pages += 1

            save_debug(
                source.id,
                channel,
                day,
                content,
            )

            block = find_channel_block(
                content,
                channel,
            )

            if not block:
                continue

            found = parse_program_block(
                block,
                channel,
                day,
                source.id,
            )

            programs.extend(
                found
            )

        except Exception as exc:

            LOGGER.warning(
                "⚠️ TV Map %s: %s",
                url,
                exc,
            )

            continue

    programs = normalize_programs(
        programs,
        day,
    )

    return FetchResult(
        programs=programs,
        detail=(
            f"{successful_pages} páginas consultadas."
            if programs
            else "Canal não encontrado nas páginas TV Map."
        ),
    )


# =============================================================
# SOURCE DISPATCH
# =============================================================

def source_applies(
    source: EPGSource,
    channel: Channel,
) -> bool:

    if source.only_channels:

        return (
            channel.id
            in source.only_channels
        )

    if source.id == "mitv":
        # Aceita canal desde que tenha slug principal
        # OU algum slug alternativo.
        return bool(slug_candidates(channel))

    return True


async def fetch_source(
    page,
    source: EPGSource,
    channel: Channel,
    day: date,
) -> FetchResult:

    if source.id == "alepi":

        return await fetch_alepi(
            page,
            source,
            channel,
            day,
        )

    if source.id == "guiadetv":

        return await fetch_guiadetv(
            page,
            source,
            channel,
            day,
        )

    if source.id == "mitv":

        return await fetch_mitv(
            page,
            source,
            channel,
            day,
        )

    if source.id == "tvmap":

        return await fetch_tvmap(
            page,
            source,
            channel,
            day,
        )

    # Fonte desconhecida.
    return FetchResult(
        detail=(
            f"Fonte não implementada: "
            f"{source.id}"
        )
    )


# =============================================================
# REPORT
# =============================================================

def create_report(
    days_ahead: int,
) -> dict[str, Any]:

    now = datetime.now(
        BR_TZ
    )

    days = [
        day.isoformat()
        for day in requested_days(
            days_ahead
        )
    ]

    return {
        "generator": "IPTV EPG Generator",
        "version": "4.1",
        "status": "running",

        "generated_at": now.isoformat(),
        "generated_at_utc": now.astimezone(
            timezone.utc
        ).isoformat(),

        "timezone": "-0300",
        "timezone_id": "America/Sao_Paulo",

        "days_ahead": days_ahead,
        "days": days,

        "minimum_programs": MIN_PROGRAMS,

        "safety": {
            "minimum_channel_coverage":
                MIN_CHANNEL_COVERAGE,
            "minimum_program_ratio":
                MIN_PROGRAM_RATIO,
            "require_all_channels":
                REQUIRE_ALL_CHANNELS,
        },

        "files": {
            "epg_xml": "output/epg.xml",
            "epg_gz": "output/epg.xml.gz",
            "playlist": "output/playlists.m3u",
            "report": "output/epg-report.json",
        },

        "sources": {},
        "channels": {},

        "totals": {
            "channels": 0,
            "successful_channels": 0,
            "partial_channels": 0,
            "failed_channels": 0,
            "programs": 0,
        },

        "publication": {
            "xml": "not_written",
            "playlist": "not_written",
        },

        "fatal_error": None,
    }


def initialize_report_sources(
    report: dict[str, Any],
    sources: list[EPGSource],
):

    for source in sources:

        report["sources"][source.id] = {
            "name": source.name,
            "priority": source.priority,
            "attempts": 0,
            "successes": 0,
            "no_programs": 0,
            "errors": 0,
            "programs": 0,
        }


def initialize_report_channel(
    report: dict[str, Any],
    channel: Channel,
):

    report["channels"][channel.id] = {
        "name": channel.name,
        "status": "pending",
        "programs": 0,
        "dates": {},
    }


def record_attempt(
    report: dict[str, Any],
    channel: Channel,
    day: date,
    source: EPGSource,
    status: str,
    program_count: int = 0,
    detail: str = "",
    error: str = "",
):

    source_report = report[
        "sources"
    ][source.id]

    source_report[
        "attempts"
    ] += 1

    source_report[
        "programs"
    ] += program_count

    if status == "success":
        source_report[
            "successes"
        ] += 1

    elif status == "no_programs":
        source_report[
            "no_programs"
        ] += 1

    elif status == "error":
        source_report[
            "errors"
        ] += 1

    channel_report = report[
        "channels"
    ][channel.id]

    day_key = day.isoformat()

    day_report = channel_report[
        "dates"
    ].setdefault(
        day_key,
        {
            "status": "pending",
            "source": None,
            "programs": 0,
            "attempts": [],
        },
    )

    day_report[
        "attempts"
    ].append(
        {
            "source": source.id,
            "source_name": source.name,
            "priority": source.priority,
            "status": status,
            "programs": program_count,
            "detail": detail,
            "error": error or None,
        }
    )


# =============================================================
# BUSCA POR CANAL/DIA
# =============================================================

async def fetch_channel(
    page,
    channel: Channel,
    sources: list[EPGSource],
    days: list[date],
    report: dict[str, Any],
) -> list[Program]:

    all_programs: list[Program] = []

    for day in days:

        day_key = day.isoformat()

        day_selected = False

        for source in sources:

            if not source_applies(
                source,
                channel,
            ):
                continue

            LOGGER.info(
                "📺 %s | %s | %s",
                channel.name,
                day_key,
                source.name,
            )

            try:

                result = await fetch_source(
                    page,
                    source,
                    channel,
                    day,
                )

                programs = normalize_programs(
                    result.programs,
                    day,
                )

                if len(programs) >= MIN_PROGRAMS:

                    record_attempt(
                        report,
                        channel,
                        day,
                        source,
                        "success",
                        len(programs),
                        result.detail,
                    )

                    report[
                        "channels"
                    ][channel.id][
                        "dates"
                    ][day_key] = {
                        "status": "success",
                        "source": source.id,
                        "source_name": source.name,
                        "programs": len(programs),
                        "attempts": report[
                            "channels"
                        ][channel.id][
                            "dates"
                        ].get(
                            day_key,
                            {}
                        ).get(
                            "attempts",
                            [],
                        ),
                    }

                    all_programs.extend(
                        programs
                    )

                    day_selected = True

                    LOGGER.info(
                        "✅ %s | %s | fonte selecionada: %s | %d programas",
                        channel.name,
                        day_key,
                        source.name,
                        len(programs),
                    )

                    # IMPORTANTE:
                    # encontrou fonte válida;
                    # não testa fontes seguintes.
                    break

                record_attempt(
                    report,
                    channel,
                    day,
                    source,
                    "no_programs",
                    len(programs),
                    result.detail,
                )

            except Exception as exc:

                LOGGER.warning(
                    "❌ %s | %s | %s: %s",
                    channel.name,
                    day_key,
                    source.name,
                    exc,
                )

                record_attempt(
                    report,
                    channel,
                    day,
                    source,
                    "error",
                    0,
                    "Exceção durante consulta.",
                    str(exc),
                )

        if not day_selected:

            report[
                "channels"
            ][channel.id][
                "dates"
            ][day_key] = {
                "status": "failed",
                "source": None,
                "programs": 0,
                "attempts": report[
                    "channels"
                ][channel.id][
                    "dates"
                ].get(
                    day_key,
                    {}
                ).get(
                    "attempts",
                    [],
                ),
            }

            LOGGER.warning(
                "⚠️ Nenhuma fonte conseguiu "
                "%s em %s. "
                "Canal ficará sem EPG neste dia.",
                channel.name,
                day_key,
            )

    all_programs = normalize_programs(
        all_programs
    )

    channel_report = report[
        "channels"
    ][channel.id]

    channel_report[
        "programs"
    ] = len(all_programs)

    successful_dates = sum(
        1
        for item in channel_report[
            "dates"
        ].values()
        if item["status"] == "success"
    )

    if successful_dates == len(days):

        channel_report[
            "status"
        ] = "success"

    elif successful_dates > 0:

        channel_report[
            "status"
        ] = "partial"

    else:

        channel_report[
            "status"
        ] = "failed"

    return all_programs


# =============================================================
# XMLTV
# =============================================================

def xml_time(
    value: datetime,
) -> str:

    if value.tzinfo is None:
        value = value.replace(
            tzinfo=BR_TZ
        )

    value = value.astimezone(
        BR_TZ
    )

    return value.strftime(
        "%Y%m%d%H%M%S %z"
    )


def generate_xml(
    channels: list[Channel],
    programs: list[Program],
) -> str:

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<tv generator-info-name="IPTV EPG Generator">',
    ]

    for channel in channels:

        lines.append(
            f'  <channel id="{xml_escape(channel.id)}">'
        )

        lines.append(
            f'    <display-name>'
            f'{xml_escape(channel.name)}'
            f'</display-name>'
        )

        if channel.logo:

            lines.append(
                f'    <icon src="{xml_escape(channel.logo)}"/>'
            )

        lines.append(
            "  </channel>"
        )

    for program in sorted(
        programs,
        key=lambda item: (
            item.channel_id,
            item.start,
        ),
    ):

        lines.append(
            "  "
            f'<programme '
            f'channel="{xml_escape(program.channel_id)}" '
            f'start="{xml_time(program.start)}" '
            f'stop="{xml_time(program.stop)}">'
        )

        lines.append(
            f"    <title lang=\"pt\">"
            f"{xml_escape(program.title)}"
            f"</title>"
        )

        if program.description:

            lines.append(
                f"    <desc lang=\"pt\">"
                f"{xml_escape(program.description)}"
                f"</desc>"
            )

        if program.category:

            lines.append(
                f"    <category lang=\"pt\">"
                f"{xml_escape(program.category)}"
                f"</category>"
            )

        if program.icon:

            lines.append(
                f'    <icon src="{xml_escape(program.icon)}"/>'
            )

        lines.append(
            "  </programme>"
        )

    lines.append(
        "</tv>"
    )

    return "\n".join(lines) + "\n"


# =============================================================
# PLAYLIST M3U
# =============================================================

def generate_m3u(
    channels: list[Channel],
) -> tuple[str, int]:

    lines = [
        "#EXTM3U"
    ]

    entries = 0

    for channel in channels:

        stream_url = clean_text(
            channel.stream
        )

        if not stream_url:
            LOGGER.warning(
                "⚠️ Canal sem stream: %s",
                channel.name,
            )

            continue

        tvg_id = m3u_attr(
            channel.id
        )

        tvg_name = m3u_attr(
            channel.name
        )

        logo = m3u_attr(
            channel.logo
        )

        group = m3u_attr(
            channel.group
        ) or "Brasil"

        lines.append(
            "#EXTINF:-1 "
            f'tvg-id="{tvg_id}" '
            f'tvg-name="{tvg_name}" '
            f'tvg-logo="{logo}" '
            f'group-title="{group}",'
            f"{tvg_name}"
        )

        lines.append(
            stream_url
        )

        entries += 1

    return (
        "\n".join(lines) + "\n",
        entries,
    )


def write_m3u_atomic(
    channels: list[Channel],
) -> int:

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    content, entries = generate_m3u(
        channels
    )

    if not content.startswith(
        "#EXTM3U\n"
    ):
        raise RuntimeError(
            "Cabeçalho M3U inválido."
        )

    if entries == 0:
        raise RuntimeError(
            "Nenhum canal possui URL de stream."
        )

    temporary = (
        OUTPUT_DIR
        / "playlists.m3u.tmp"
    )

    temporary.write_text(
        content,
        encoding="utf-8",
        newline="\n",
    )

    validation = temporary.read_text(
        encoding="utf-8"
    )

    if not validation.startswith(
        "#EXTM3U\n"
    ):
        temporary.unlink(
            missing_ok=True
        )

        raise RuntimeError(
            "Falha na validação M3U."
        )

    if validation.count(
        "#EXTINF:"
    ) != entries:
        temporary.unlink(
            missing_ok=True
        )

        raise RuntimeError(
            "Quantidade de entradas M3U inválida."
        )

    temporary.replace(
        PLAYLIST_FILE
    )

    return entries


# =============================================================
# VALIDAÇÃO
# =============================================================

def count_programmes_in_xml(
    file_path: Path,
) -> int:

    if not file_path.exists():
        return 0

    try:

        tree = ET.parse(
            file_path
        )

        root = tree.getroot()

        return len(
            root.findall(
                "programme"
            )
        )

    except Exception:
        return 0


def validate_xml(
    xml_content: str,
) -> int:

    root = ET.fromstring(
        xml_content
    )

    if root.tag != "tv":
        raise ValueError(
            "XML não possui raiz <tv>."
        )

    channels = root.findall(
        "channel"
    )

    programmes = root.findall(
        "programme"
    )

    if not channels:
        raise ValueError(
            "XML não possui canais."
        )

    if not programmes:
        raise ValueError(
            "XML não possui programas."
        )

    return len(programmes)


def safety_check(
    channels: list[Channel],
    programs: list[Program],
) -> dict[str, Any]:

    total_channels = len(
        channels
    )

    successful_channels = len({
        program.channel_id
        for program in programs
    })

    coverage = (
        successful_channels
        / total_channels
        if total_channels
        else 0
    )

    previous_count = (
        count_programmes_in_xml(
            OUTPUT_FILE
        )
    )

    new_count = len(
        programs
    )

    result = {
        "new_programs": new_count,
        "previous_programs": previous_count,
        "channel_coverage": coverage,
        "minimum_channel_coverage":
            MIN_CHANNEL_COVERAGE,
        "minimum_program_ratio":
            MIN_PROGRAM_RATIO,
        "passed": True,
        "reason": None,
    }

    if new_count <= 0:

        result["passed"] = False
        result["reason"] = (
            "Nenhum programa novo."
        )

        return result

    if REQUIRE_ALL_CHANNELS:

        if successful_channels < total_channels:

            result["passed"] = False
            result["reason"] = (
                "EPG_REQUIRE_ALL_CHANNELS "
                "está ativado e nem todos os "
                "canais possuem programação."
            )

            return result

    elif coverage < MIN_CHANNEL_COVERAGE:

        result["passed"] = False
        result["reason"] = (
            f"Cobertura de canais "
            f"{coverage:.1%} abaixo do mínimo "
            f"{MIN_CHANNEL_COVERAGE:.1%}."
        )

        return result

    if (
        previous_count > 0
        and new_count
        < previous_count * MIN_PROGRAM_RATIO
    ):

        result["passed"] = False
        result["reason"] = (
            f"Quantidade de programas caiu "
            f"de {previous_count} para "
            f"{new_count}, abaixo de "
            f"{MIN_PROGRAM_RATIO:.1%} "
            f"do EPG anterior."
        )

        return result

    return result


def write_atomic(
    file_path: Path,
    content: str,
):

    file_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    temporary = file_path.with_suffix(
        file_path.suffix + ".tmp"
    )

    temporary.write_text(
        content,
        encoding="utf-8",
        newline="\n",
    )

    temporary.replace(
        file_path
    )


def write_xml_atomic(
    channels: list[Channel],
    programs: list[Program],
    report: dict[str, Any],
):

    xml_content = generate_xml(
        channels,
        programs,
    )

    programme_count = validate_xml(
        xml_content
    )

    safety = safety_check(
        channels,
        programs,
    )

    report["safety_result"] = safety

    if not safety["passed"]:

        raise RuntimeError(
            "Publicação bloqueada pelo "
            "mecanismo de segurança: "
            + str(safety["reason"])
        )

    write_atomic(
        OUTPUT_FILE,
        xml_content,
    )

    report[
        "publication"
    ][
        "xml"
    ] = "success"

    report[
        "publication"
    ][
        "xml_programs"
    ] = programme_count


# =============================================================
# FINALIZAÇÃO DO RELATÓRIO
# =============================================================

def finalize_report(
    report: dict[str, Any],
):

    channels = report[
        "channels"
    ]

    success = sum(
        1
        for channel in channels.values()
        if channel["status"] == "success"
    )

    partial = sum(
        1
        for channel in channels.values()
        if channel["status"] == "partial"
    )

    failed = sum(
        1
        for channel in channels.values()
        if channel["status"] == "failed"
    )

    programs = sum(
        channel["programs"]
        for channel in channels.values()
    )

    report[
        "totals"
    ] = {
        "channels": len(channels),
        "successful_channels": success,
        "partial_channels": partial,
        "failed_channels": failed,
        "programs": programs,
    }

    if report.get(
        "fatal_error"
    ):
        report[
            "status"
        ] = "failed"

    elif programs <= 0:
        report[
            "status"
        ] = "failed"

    elif failed or partial:
        report[
            "status"
        ] = "partial"

    else:
        report[
            "status"
        ] = "success"

    report[
        "outputs"
    ] = {
        "epg.xml": OUTPUT_FILE.exists(),
        "epg.xml.gz": OUTPUT_GZ_FILE.exists(),
        "playlists.m3u": PLAYLIST_FILE.exists(),
        "epg-report.json": REPORT_FILE.exists(),
    }

    report[
        "finished_at"
    ] = datetime.now(
        BR_TZ
    ).isoformat()


def save_report(
    report: dict[str, Any],
):

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    temporary = (
        OUTPUT_DIR
        / "epg-report.json.tmp"
    )

    temporary.write_text(
        json.dumps(
            report,
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )

    temporary.replace(
        REPORT_FILE
    )


# =============================================================
# MAIN
# =============================================================

async def async_main() -> int:

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    report = create_report(
        int(
            DAYS_AHEAD_ENV
            or 2
        )
    )

    browser_resources = None

    try:

        (
            channels,
            sources,
            days_ahead,
        ) = load_config()

        # Atualiza dias reais após ler config.
        report[
            "days_ahead"
        ] = days_ahead

        report[
            "days"
        ] = [
            day.isoformat()
            for day in requested_days(
                days_ahead
            )
        ]

        report[
            "totals"
        ][
            "channels"
        ] = len(channels)

        initialize_report_sources(
            report,
            sources,
        )

        for channel in channels:

            initialize_report_channel(
                report,
                channel,
            )

        LOGGER.info(
            "=================================================="
        )

        LOGGER.info(
            "🚀 Iniciando geração EPG"
        )

        LOGGER.info(
            "📺 Canais: %d",
            len(channels),
        )

        LOGGER.info(
            "📅 Dias: %d",
            days_ahead,
        )

        LOGGER.info(
            "🔀 Fontes (prioridade): %s",
            " → ".join(
                f"{source.name}(p{source.priority})"
                for source in sources
            ),
        )

        LOGGER.info(
            "=================================================="
        )

        browser_resources = (
            await create_browser()
        )

        (
            playwright,
            browser,
            context,
            page,
        ) = browser_resources

        all_programs: list[Program] = []

        days = requested_days(
            days_ahead
        )

        for channel in channels:

            try:

                programs = await fetch_channel(
                    page,
                    channel,
                    sources,
                    days,
                    report,
                )

                all_programs.extend(
                    programs
                )

            except Exception as exc:

                LOGGER.exception(
                    "❌ Falha geral no canal %s",
                    channel.name,
                )

                report[
                    "channels"
                ][
                    channel.id
                ][
                    "status"
                ] = "failed"

                report[
                    "channels"
                ][
                    channel.id
                ][
                    "error"
                ] = str(exc)

        all_programs = normalize_programs(
            all_programs
        )

        LOGGER.info(
            "📊 Total de programas: %d",
            len(all_programs),
        )

        # -----------------------------------------------------
        # XML
        # -----------------------------------------------------

        write_xml_atomic(
            channels,
            all_programs,
            report,
        )

        LOGGER.info(
            "✅ EPG XML gerado: %s",
            OUTPUT_FILE,
        )

        # -----------------------------------------------------
        # PLAYLIST
        # -----------------------------------------------------

        try:

            entries = write_m3u_atomic(
                channels
            )

            report[
                "publication"
            ][
                "playlist"
            ] = "success"

            report[
                "publication"
            ][
                "playlist_entries"
            ] = entries

            LOGGER.info(
                "📺 Playlist M3U gerada: %s "
                "(%d canais)",
                PLAYLIST_FILE,
                entries,
            )

        except Exception as exc:

            LOGGER.exception(
                "❌ Falha ao gerar playlist M3U."
            )

            report[
                "publication"
            ][
                "playlist"
            ] = "failed"

            report[
                "publication"
            ][
                "playlist_error"
            ] = str(exc)

            # Não invalida um XML válido.
            # O GitHub Actions registrará o erro.

        return 0

    except Exception as exc:

        report[
            "fatal_error"
        ] = {
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": traceback.format_exc(),
        }

        LOGGER.exception(
            "❌ ERRO FATAL NA GERAÇÃO DO EPG"
        )

        return 1

    finally:

        if browser_resources:

            try:
                await browser_resources[
                    2
                ].close()
            except Exception:
                pass

            try:
                await browser_resources[
                    1
                ].close()
            except Exception:
                pass

            try:
                await browser_resources[
                    0
                ].stop()
            except Exception:
                pass

        finalize_report(
            report
        )

        try:
            save_report(
                report
            )

            LOGGER.info(
                "📄 Relatório salvo: %s",
                REPORT_FILE,
            )

        except Exception:

            LOGGER.exception(
                "❌ Não foi possível salvar "
                "epg-report.json."
            )


def main() -> int:

    try:
        return asyncio.run(
            async_main()
        )

    except KeyboardInterrupt:

        LOGGER.warning(
            "Execução interrompida."
        )

        return 130


if __name__ == "__main__":
    sys.exit(
        main()
    )