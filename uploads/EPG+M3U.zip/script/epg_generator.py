#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
=============================================================
                 📺 EPG SYSTEM
=============================================================

Gera automaticamente:

    output/epg.xml
    output/epg.xml.gz
    output/playlist.m3u
    output/epg-report.json

Fontes:

    mi.tv
    Guia de TV
    Guia de TV - Filmes e Séries
    iptv-org

Recursos:

    ✓ XMLTV
    ✓ GZIP
    ✓ M3U
    ✓ Fallback automático
    ✓ Prioridade entre fontes
    ✓ Aliases
    ✓ Normalização de nomes
    ✓ America/Sao_Paulo
    ✓ Relatório JSON
    ✓ Retry HTTP
    ✓ Timeout
    ✓ Execução pelo GitHub Actions
=============================================================
"""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import re
import sys
import time
import traceback
import unicodedata
import xml.etree.ElementTree as ET

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup
from zoneinfo import ZoneInfo


# ============================================================
# DIRETÓRIOS
# ============================================================

ROOT_DIR = Path(__file__).resolve().parents[1]

CONFIG_FILE = ROOT_DIR / "config" / "channels.json"

OUTPUT_DIR = ROOT_DIR / "output"

EPG_XML = OUTPUT_DIR / "epg.xml"
EPG_GZ = OUTPUT_DIR / "epg.xml.gz"
PLAYLIST_M3U = OUTPUT_DIR / "playlist.m3u"
REPORT_JSON = OUTPUT_DIR / "epg-report.json"


# ============================================================
# CONSTANTES
# ============================================================

DEFAULT_TIMEZONE = "America/Sao_Paulo"

TIME_RE = re.compile(
    r"(?<!\d)([01]?\d|2[0-3])[:hH]([0-5]\d)(?!\d)"
)

DATE_RE = re.compile(
    r"(?<!\d)(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?(?!\d)"
)

SPACE_RE = re.compile(r"\s+")

INVALID_TITLES = {
    "",
    "-",
    "programação",
    "programacao",
    "hoje",
    "amanhã",
    "amanha",
    "mais",
    "ver mais",
    "menu",
    "início",
    "inicio"
}


# ============================================================
# DATACLASSES
# ============================================================

@dataclass
class Programme:
    channel_id: str
    channel_name: str
    title: str
    start: datetime
    stop: datetime
    description: str = ""
    source_id: str = ""
    source_priority: int = 999


@dataclass
class SourceResult:
    source_id: str
    name: str
    priority: int
    type: str
    url: str
    status: str = "error"
    programmes: List[Programme] = field(default_factory=list)
    channels_found: int = 0
    duration_seconds: float = 0
    error: Optional[str] = None


# ============================================================
# UTILIDADES
# ============================================================

def log(message: str) -> None:
    print(f"[EPG] {message}", flush=True)


def normalize_text(value: str) -> str:
    if not value:
        return ""

    value = unicodedata.normalize("NFKD", value)
    value = "".join(
        char for char in value
        if not unicodedata.combining(char)
    )

    value = value.lower()

    value = re.sub(
        r"\b(fhd|uhd|hd|sd|h264|h265|hevc|aac|ac3)\b",
        " ",
        value,
    )

    value = re.sub(r"[^a-z0-9]+", " ", value)

    return SPACE_RE.sub(" ", value).strip()


def clean_text(value: str) -> str:
    if not value:
        return ""

    value = value.replace("\xa0", " ")
    value = SPACE_RE.sub(" ", value)

    return value.strip()


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    temporary = path.with_suffix(path.suffix + ".tmp")

    temporary.write_text(
        content,
        encoding="utf-8",
        newline="\n",
    )

    temporary.replace(path)


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    temporary = path.with_suffix(path.suffix + ".tmp")

    temporary.write_bytes(data)

    temporary.replace(path)


def parse_env_int(name: str, default: int) -> int:
    value = os.getenv(name)

    if not value:
        return default

    try:
        return int(value)
    except ValueError:
        return default


def load_config() -> dict:
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {CONFIG_FILE}"
        )

    with CONFIG_FILE.open("r", encoding="utf-8") as file:
        return json.load(file)


def get_timezone(config: dict) -> ZoneInfo:
    timezone_id = (
        config
        .get("settings", {})
        .get("timezone_id", DEFAULT_TIMEZONE)
    )

    try:
        return ZoneInfo(timezone_id)
    except Exception:
        return ZoneInfo(DEFAULT_TIMEZONE)


# ============================================================
# HTTP
# ============================================================

def download_url(
    url: str,
    config: dict,
) -> Tuple[bytes, str]:

    settings = config.get("settings", {})

    timeout = parse_env_int(
        "EPG_PAGE_TIMEOUT",
        int(settings.get("request_timeout", 60)),
    )

    retries = parse_env_int(
        "EPG_RETRIES",
        int(settings.get("request_retries", 3)),
    )

    retry_delay = int(
        settings.get("retry_delay", 3)
    )

    user_agent = settings.get(
        "user_agent",
        "Mozilla/5.0",
    )

    headers = {
        "User-Agent": user_agent,
        "Accept": (
            "text/html,application/xhtml+xml,"
            "application/xml;q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        "Cache-Control": "no-cache",
    }

    last_error = None

    for attempt in range(1, retries + 1):

        try:
            log(
                f"Download: {url} "
                f"(tentativa {attempt}/{retries})"
            )

            response = requests.get(
                url,
                headers=headers,
                timeout=timeout,
                allow_redirects=True,
            )

            response.raise_for_status()

            return (
                response.content,
                response.encoding or "utf-8",
            )

        except Exception as exc:

            last_error = exc

            log(
                f"Falha HTTP: {exc}"
            )

            if attempt < retries:
                time.sleep(retry_delay)

    raise RuntimeError(
        f"Não foi possível baixar {url}: {last_error}"
    )


# ============================================================
# CANAIS
# ============================================================

def enabled_channels(config: dict) -> List[dict]:
    channels = []

    for channel in config.get("channels", []):

        if channel.get("enabled", True):
            channels.append(channel)

    return channels


def channel_aliases(channel: dict) -> List[str]:

    values = [
        channel.get("name", ""),
        channel.get("tvg_name", ""),
        channel.get("tvg_id", ""),
    ]

    values.extend(
        channel.get("aliases", [])
    )

    result = []

    for value in values:

        normalized = normalize_text(value)

        if normalized and normalized not in result:
            result.append(normalized)

    return result


def find_channel(
    text: str,
    channels: List[dict],
) -> Optional[dict]:

    normalized_text = normalize_text(text)

    if not normalized_text:
        return None

    # --------------------------------------------------------
    # 1. Correspondência exata
    # --------------------------------------------------------

    for channel in channels:

        for alias in channel_aliases(channel):

            if normalized_text == alias:
                return channel

    # --------------------------------------------------------
    # 2. Alias contido no texto
    # --------------------------------------------------------

    best = None
    best_score = 0

    for channel in channels:

        for alias in channel_aliases(channel):

            if len(alias) < 4:
                continue

            if alias in normalized_text:

                score = len(alias)

                if score > best_score:
                    best = channel
                    best_score = score

    return best


# ============================================================
# DATAS
# ============================================================

MONTHS = {
    "janeiro": 1,
    "fevereiro": 2,
    "marco": 3,
    "abril": 4,
    "maio": 5,
    "junho": 6,
    "julho": 7,
    "agosto": 8,
    "setembro": 9,
    "outubro": 10,
    "novembro": 11,
    "dezembro": 12,
}


def extract_date(text: str, base_date: datetime) -> Optional[datetime]:

    match = DATE_RE.search(text)

    if match:

        day = int(match.group(1))
        month = int(match.group(2))

        year_text = match.group(3)

        if year_text:

            year = int(year_text)

            if year < 100:
                year += 2000

        else:
            year = base_date.year

        try:
            return base_date.replace(
                year=year,
                month=month,
                day=day,
                hour=0,
                minute=0,
                second=0,
                microsecond=0,
            )

        except ValueError:
            pass

    normalized = normalize_text(text)

    for month_name, month_number in MONTHS.items():

        pattern = rf"(\d{{1,2}})\s+de\s+{month_name}"

        match = re.search(pattern, normalized)

        if match:

            day = int(match.group(1))

            try:
                return base_date.replace(
                    month=month_number,
                    day=day,
                    hour=0,
                    minute=0,
                    second=0,
                    microsecond=0,
                )

            except ValueError:
                return None

    return None


def make_datetime(
    base_date: datetime,
    hour: int,
    minute: int,
) -> datetime:

    return base_date.replace(
        hour=hour,
        minute=minute,
        second=0,
        microsecond=0,
    )


# ============================================================
# TÍTULOS
# ============================================================

def clean_program_title(
    text: str,
    channel: Optional[dict] = None,
) -> str:

    if not text:
        return ""

    text = clean_text(text)

    text = TIME_RE.sub("", text)

    text = DATE_RE.sub("", text)

    if channel:

        aliases = sorted(
            channel_aliases(channel),
            key=len,
            reverse=True,
        )

        for alias in aliases:

            if not alias:
                continue

            pattern = re.compile(
                re.escape(alias),
                re.IGNORECASE,
            )

            text = pattern.sub("", text)

    text = re.sub(
        r"^[\s\-–—:|•]+",
        "",
        text,
    )

    text = re.sub(
        r"[\s\-–—:|•]+$",
        "",
        text,
    )

    text = clean_text(text)

    if normalize_text(text) in INVALID_TITLES:
        return ""

    return text


# ============================================================
# EXTRAÇÃO DE HORÁRIOS
# ============================================================

def extract_times(text: str) -> List[Tuple[int, int]]:

    result = []

    for match in TIME_RE.finditer(text):

        hour = int(match.group(1))
        minute = int(match.group(2))

        result.append(
            (hour, minute)
        )

    return result


# ============================================================
# PARSER XMLTV
# ============================================================

def parse_xmltv(
    data: bytes,
    source: dict,
    channels: List[dict],
    config: dict,
    now: datetime,
    limit: datetime,
) -> List[Programme]:

    root = ET.fromstring(data)

    result = []

    source_channels = {}

    for element in root.findall("channel"):

        channel_id = element.attrib.get("id", "")

        names = []

        for display in element.findall("display-name"):

            if display.text:
                names.append(
                    clean_text(display.text)
                )

        source_channels[channel_id] = names

    for programme in root.findall("programme"):

        source_channel_id = programme.attrib.get(
            "channel",
            "",
        )

        names = source_channels.get(
            source_channel_id,
            [],
        )

        channel = None

        for name in names:

            channel = find_channel(
                name,
                channels,
            )

            if channel:
                break

        if not channel:
            continue

        try:
            start = parse_xmltv_datetime(
                programme.attrib.get("start", "")
            )

            stop_text = programme.attrib.get(
                "stop",
                "",
            )

            if stop_text:
                stop = parse_xmltv_datetime(
                    stop_text
                )
            else:
                stop = start + timedelta(
                    minutes=30
                )

        except Exception:
            continue

        if stop <= now:
            continue

        if start >= limit:
            continue

        title_element = programme.find("title")

        title = ""

        if title_element is not None:
            title = clean_text(
                title_element.text or ""
            )

        if not title:
            continue

        desc_element = programme.find("desc")

        description = ""

        if desc_element is not None:
            description = clean_text(
                desc_element.text or ""
            )

        result.append(
            Programme(
                channel_id=channel.get(
                    "tvg_id",
                    channel.get("name", ""),
                ),
                channel_name=channel.get(
                    "name",
                    "",
                ),
                title=title,
                start=start,
                stop=stop,
                description=description,
                source_id=source["id"],
                source_priority=int(
                    source.get("priority", 999)
                ),
            )
        )

    return result


def parse_xmltv_datetime(value: str) -> datetime:

    value = value.strip()

    match = re.match(
        r"^(\d{14})(?:\s*([+-]\d{4}))?",
        value,
    )

    if not match:
        raise ValueError(
            f"Data XMLTV inválida: {value}"
        )

    raw = match.group(1)
    offset_text = match.group(2)

    year = int(raw[0:4])
    month = int(raw[4:6])
    day = int(raw[6:8])
    hour = int(raw[8:10])
    minute = int(raw[10:12])
    second = int(raw[12:14])

    if offset_text:

        sign = 1 if offset_text[0] == "+" else -1

        offset_hours = int(
            offset_text[1:3]
        )

        offset_minutes = int(
            offset_text[3:5]
        )

        offset = timedelta(
            hours=offset_hours,
            minutes=offset_minutes,
        ) * sign

        tz = timezone(offset)

    else:

        tz = timezone.utc

    return datetime(
        year,
        month,
        day,
        hour,
        minute,
        second,
        tzinfo=tz,
    )


# ============================================================
# PARSER HTML
# ============================================================

def get_html_blocks(
    soup: BeautifulSoup,
) -> List:

    selectors = [
        "article",
        "li",
        "tr",
        "[class*='program']",
        "[class*='programme']",
        "[class*='schedule']",
        "[class*='programacao']",
        "[class*='event']",
        "[class*='show']",
        "[class*='episode']",
    ]

    blocks = []

    for selector in selectors:

        try:
            blocks.extend(
                soup.select(selector)
            )
        except Exception:
            continue

    # Remove duplicados mantendo ordem
    result = []
    seen = set()

    for block in blocks:

        identifier = id(block)

        if identifier in seen:
            continue

        seen.add(identifier)

        text = clean_text(
            block.get_text(
                " ",
                strip=True,
            )
        )

        if not text:
            continue

        result.append(block)

    return result


def extract_title_from_block(
    block,
    channel: Optional[dict],
) -> str:

    # --------------------------------------------------------
    # Possíveis seletores de título
    # --------------------------------------------------------

    selectors = [
        ".title",
        ".program-title",
        ".program-name",
        ".programme-title",
        ".event-title",
        ".show-title",
        "[class*='title']",
        "h1",
        "h2",
        "h3",
        "h4",
        "strong",
        "b",
    ]

    for selector in selectors:

        try:
            elements = block.select(selector)
        except Exception:
            elements = []

        for element in elements:

            text = clean_text(
                element.get_text(
                    " ",
                    strip=True,
                )
            )

            title = clean_program_title(
                text,
                channel,
            )

            if len(title) >= 2:
                return title

    return ""


def parse_html(
    data: bytes,
    source: dict,
    channels: List[dict],
    config: dict,
    now: datetime,
    limit: datetime,
) -> List[Programme]:

    soup = BeautifulSoup(
        data,
        "html.parser",
    )

    programmes = []

    blocks = get_html_blocks(soup)

    current_date = now.replace(
        hour=0,
        minute=0,
        second=0,
        microsecond=0,
    )

    last_start_by_channel: Dict[str, datetime] = {}

    # --------------------------------------------------------
    # 1. Parser por blocos
    # --------------------------------------------------------

    for block in blocks:

        text = clean_text(
            block.get_text(
                " ",
                strip=True,
            )
        )

        if len(text) < 3:
            continue

        channel = find_channel(
            text,
            channels,
        )

        if not channel:

            # Procura nos elementos-pai
            parent = block.parent

            for _ in range(4):

                if parent is None:
                    break

                parent_text = clean_text(
                    parent.get_text(
                        " ",
                        strip=True,
                    )
                )

                channel = find_channel(
                    parent_text,
                    channels,
                )

                if channel:
                    break

                parent = parent.parent

        times = extract_times(text)

        if not times:
            continue

        date_hint = extract_date(
            text,
            current_date,
        )

        if date_hint:
            current_date = date_hint

        if channel:

            title = extract_title_from_block(
                block,
                channel,
            )

            if not title:

                # Remove horários e nome do canal
                title = clean_program_title(
                    text,
                    channel,
                )

            if not title:
                continue

            channel_id = channel.get(
                "tvg_id",
                channel.get("name", ""),
            )

            for hour, minute in times:

                start = make_datetime(
                    current_date,
                    hour,
                    minute,
                )

                # Corrige virada de dia
                previous = last_start_by_channel.get(
                    channel_id
                )

                if previous:

                    if start <= previous - timedelta(
                        hours=2
                    ):
                        start += timedelta(days=1)

                stop = start + timedelta(
                    minutes=30
                )

                if start < limit and stop > now:

                    programmes.append(
                        Programme(
                            channel_id=channel_id,
                            channel_name=channel.get(
                                "name",
                                "",
                            ),
                            title=title,
                            start=start,
                            stop=stop,
                            source_id=source["id"],
                            source_priority=int(
                                source.get(
                                    "priority",
                                    999,
                                )
                            ),
                        )
                    )

                    last_start_by_channel[
                        channel_id
                    ] = start

    # --------------------------------------------------------
    # 2. Parser de tabelas
    # --------------------------------------------------------

    for row in soup.select("tr"):

        cells = row.find_all(
            ["td", "th"]
        )

        if not cells:
            continue

        row_text = clean_text(
            row.get_text(
                " ",
                strip=True,
            )
        )

        channel = find_channel(
            row_text,
            channels,
        )

        if not channel:
            continue

        times = extract_times(
            row_text
        )

        if not times:
            continue

        parts = [
            clean_text(
                cell.get_text(
                    " ",
                    strip=True,
                )
            )
            for cell in cells
        ]

        title = ""

        for part in parts:

            if TIME_RE.search(part):
                continue

            candidate = clean_program_title(
                part,
                channel,
            )

            if len(candidate) >= 2:

                if normalize_text(
                    candidate
                ) not in INVALID_TITLES:

                    title = candidate
                    break

        if not title:
            continue

        channel_id = channel.get(
            "tvg_id",
            channel.get("name", ""),
        )

        for hour, minute in times:

            start = make_datetime(
                current_date,
                hour,
                minute,
            )

            stop = start + timedelta(
                minutes=30
            )

            if start < limit and stop > now:

                programmes.append(
                    Programme(
                        channel_id=channel_id,
                        channel_name=channel.get(
                            "name",
                            "",
                        ),
                        title=title,
                        start=start,
                        stop=stop,
                        source_id=source["id"],
                        source_priority=int(
                            source.get(
                                "priority",
                                999,
                            )
                        ),
                    )
                )

    return programmes


# ============================================================
# NORMALIZAÇÃO DAS PROGRAMAÇÕES
# ============================================================

def programme_key(programme: Programme) -> str:

    value = (
        programme.channel_id
        + "|"
        + programme.start.isoformat()
        + "|"
        + normalize_text(
            programme.title
        )
    )

    return hashlib.sha1(
        value.encode("utf-8")
    ).hexdigest()


def remove_duplicates(
    programmes: List[Programme],
) -> List[Programme]:

    result = []
    seen = set()

    for programme in sorted(
        programmes,
        key=lambda item: (
            item.channel_id,
            item.start,
            item.source_priority,
        ),
    ):

        key = programme_key(
            programme
        )

        if key in seen:
            continue

        seen.add(key)

        result.append(programme)

    return result


def merge_sources(
    source_results: List[SourceResult],
    channels: List[dict],
    now: datetime,
    limit: datetime,
) -> List[Programme]:

    selected = []

    # Prioridade menor = mais importante
    ordered = sorted(
        source_results,
        key=lambda item: item.priority,
    )

    for channel in channels:

        channel_id = channel.get(
            "tvg_id",
            channel.get("name", ""),
        )

        channel_programmes = []

        for result in ordered:

            candidates = [
                item
                for item in result.programmes
                if item.channel_id == channel_id
            ]

            candidates.sort(
                key=lambda item: item.start
            )

            for candidate in candidates:

                # Remove completamente fora da janela
                if candidate.stop <= now:
                    continue

                if candidate.start >= limit:
                    continue

                # Procura conflito com fonte superior
                conflict = False

                for existing in channel_programmes:

                    if (
                        candidate.start < existing.stop
                        and candidate.stop > existing.start
                    ):
                        conflict = True
                        break

                if conflict:
                    continue

                channel_programmes.append(
                    candidate
                )

        channel_programmes.sort(
            key=lambda item: item.start
        )

        # ----------------------------------------------------
        # Corrige horários de HTML que possuem duração padrão
        # ----------------------------------------------------

        for index, item in enumerate(
            channel_programmes
        ):

            if index + 1 < len(
                channel_programmes
            ):

                next_item = channel_programmes[
                    index + 1
                ]

                if (
                    next_item.start > item.start
                    and next_item.start < item.stop
                ):
                    item.stop = next_item.start

                elif (
                    item.source_id != "iptv_org"
                    and next_item.start > item.start
                    and next_item.start - item.start
                    <= timedelta(hours=6)
                ):
                    item.stop = next_item.start

            if item.stop <= item.start:

                item.stop = item.start + timedelta(
                    minutes=30
                )

        selected.extend(
            channel_programmes
        )

    return remove_duplicates(
        selected
    )


# ============================================================
# XMLTV
# ============================================================

def xmltv_datetime(value: datetime) -> str:

    local = value.astimezone(
        timezone(timedelta(hours=-3))
    )

    return local.strftime(
        "%Y%m%d%H%M%S %z"
    )


def create_epg_xml(
    programmes: List[Programme],
    channels: List[dict],
    config: dict,
) -> bytes:

    root = ET.Element(
        "tv",
        {
            "generator-info-name":
                "EPG System - GitHub Actions",
            "source-info-name":
                "mi.tv / Guia de TV / iptv-org",
        },
    )

    # --------------------------------------------------------
    # Canais
    # --------------------------------------------------------

    channels_with_programmes = {
        item.channel_id
        for item in programmes
    }

    for channel in channels:

        channel_id = channel.get(
            "tvg_id",
            channel.get("name", ""),
        )

        if channel_id not in channels_with_programmes:
            continue

        element = ET.SubElement(
            root,
            "channel",
            {
                "id": channel_id
            },
        )

        display_name = ET.SubElement(
            element,
            "display-name",
        )

        display_name.text = channel.get(
            "tvg_name",
            channel.get("name", ""),
        )

        logo = channel.get(
            "logo",
            "",
        )

        if logo:

            ET.SubElement(
                element,
                "icon",
                {
                    "src": logo
                },
            )

    # --------------------------------------------------------
    # Programas
    # --------------------------------------------------------

    for programme in sorted(
        programmes,
        key=lambda item: (
            item.channel_id,
            item.start,
        ),
    ):

        element = ET.SubElement(
            root,
            "programme",
            {
                "start": xmltv_datetime(
                    programme.start
                ),
                "stop": xmltv_datetime(
                    programme.stop
                ),
                "channel": programme.channel_id,
            },
        )

        title = ET.SubElement(
            element,
            "title",
            {
                "lang": "pt"
            },
        )

        title.text = programme.title

        if programme.description:

            desc = ET.SubElement(
                element,
                "desc",
                {
                    "lang": "pt"
                },
            )

            desc.text = programme.description

    ET.indent(
        root,
        space="  ",
    )

    return ET.tostring(
        root,
        encoding="utf-8",
        xml_declaration=True,
    )


# ============================================================
# GZIP
# ============================================================

def create_gzip(
    data: bytes,
) -> bytes:

    import io

    buffer = io.BytesIO()

    with gzip.GzipFile(
        fileobj=buffer,
        mode="wb",
        mtime=0,
    ) as gz:

        gz.write(data)

    return buffer.getvalue()


# ============================================================
# PLAYLIST M3U
# ============================================================

def create_playlist(
    channels: List[dict],
    url_tvg: str,
) -> str:

    lines = []

    lines.append(
        f'#EXTM3U url-tvg="{url_tvg}"'
    )

    for channel in channels:

        if not channel.get(
            "enabled",
            True,
        ):
            continue

        url = clean_text(
            channel.get(
                "url",
                "",
            )
        )

        if not url:
            continue

        name = channel.get(
            "name",
            "",
        )

        tvg_id = channel.get(
            "tvg_id",
            name,
        )

        tvg_name = channel.get(
            "tvg_name",
            name,
        )

        group = channel.get(
            "group",
            "Brasil",
        )

        logo = channel.get(
            "logo",
            "",
        )

        attributes = [
            f'tvg-id="{tvg_id}"',
            f'tvg-name="{tvg_name}"',
            f'group-title="{group}"',
        ]

        if logo:
            attributes.append(
                f'tvg-logo="{logo}"'
            )

        lines.append(
            "#EXTINF:-1 "
            + " ".join(attributes)
            + f",{name}"
        )

        lines.append(url)

    return "\n".join(lines) + "\n"


# ============================================================
# RELATÓRIO
# ============================================================

def create_report(
    config: dict,
    source_results: List[SourceResult],
    programmes: List[Programme],
    channels: List[dict],
    started_at: datetime,
    finished_at: datetime,
) -> dict:

    channels_report = []

    for channel in channels:

        channel_id = channel.get(
            "tvg_id",
            channel.get("name", ""),
        )

        channel_programmes = [
            item
            for item in programmes
            if item.channel_id == channel_id
        ]

        sources = sorted(
            {
                item.source_id
                for item in channel_programmes
            }
        )

        channels_report.append(
            {
                "name": channel.get(
                    "name",
                    "",
                ),
                "tvg_id": channel_id,
                "programmes": len(
                    channel_programmes
                ),
                "sources": sources,
                "playlist": bool(
                    clean_text(
                        channel.get(
                            "url",
                            "",
                        )
                    )
                ),
            }
        )

    return {
        "status": "ok",
        "generated_at": finished_at.isoformat(),
        "started_at": started_at.isoformat(),
        "finished_at": finished_at.isoformat(),
        "duration_seconds": round(
            (
                finished_at - started_at
            ).total_seconds(),
            3,
        ),

        "settings": config.get(
            "settings",
            {},
        ),

        "sources": [
            {
                "id": result.source_id,
                "name": result.name,
                "type": result.type,
                "priority": result.priority,
                "url": result.url,
                "status": result.status,
                "programmes": len(
                    result.programmes
                ),
                "channels_found":
                    result.channels_found,
                "duration_seconds":
                    round(
                        result.duration_seconds,
                        3,
                    ),
                "error": result.error,
            }
            for result in source_results
        ],

        "channels": channels_report,

        "totals": {
            "configured_channels":
                len(channels),

            "channels_with_programmes":
                len(
                    {
                        item.channel_id
                        for item in programmes
                    }
                ),

            "programmes":
                len(programmes),

            "playlist_channels":
                len(
                    [
                        channel
                        for channel in channels
                        if clean_text(
                            channel.get(
                                "url",
                                "",
                            )
                        )
                    ]
                ),
        },

        "outputs": {
            "epg_xml":
                str(
                    EPG_XML.relative_to(
                        ROOT_DIR
                    )
                ),

            "epg_xml_gz":
                str(
                    EPG_GZ.relative_to(
                        ROOT_DIR
                    )
                ),

            "playlist":
                str(
                    PLAYLIST_M3U.relative_to(
                        ROOT_DIR
                    )
                ),

            "report":
                str(
                    REPORT_JSON.relative_to(
                        ROOT_DIR
                    )
                ),
        },
    }


# ============================================================
# PROCESSAMENTO DE FONTE
# ============================================================

def process_source(
    source: dict,
    channels: List[dict],
    config: dict,
    now: datetime,
    limit: datetime,
) -> SourceResult:

    started = time.monotonic()

    result = SourceResult(
        source_id=source.get(
            "id",
            "unknown",
        ),
        name=source.get(
            "name",
            source.get(
                "id",
                "unknown",
            ),
        ),
        priority=int(
            source.get(
                "priority",
                999,
            )
        ),
        type=source.get(
            "type",
            "html",
        ),
        url=source.get(
            "url",
            "",
        ),
    )

    try:

        data, _encoding = download_url(
            result.url,
            config,
        )

        if result.type.lower() == "xmltv":

            programmes = parse_xmltv(
                data,
                source,
                channels,
                config,
                now,
                limit,
            )

        else:

            programmes = parse_html(
                data,
                source,
                channels,
                config,
                now,
                limit,
            )

        result.programmes = programmes

        result.channels_found = len(
            {
                item.channel_id
                for item in programmes
            }
        )

        result.status = "ok"

    except Exception as exc:

        result.status = "error"

        result.error = (
            f"{type(exc).__name__}: {exc}"
        )

        log(
            f"Erro na fonte "
            f"{result.source_id}: "
            f"{result.error}"
        )

    finally:

        result.duration_seconds = (
            time.monotonic() - started
        )

    log(
        f"Fonte {result.source_id}: "
        f"{result.status} | "
        f"{len(result.programmes)} programas"
    )

    return result


# ============================================================
# MAIN
# ============================================================

def main() -> int:

    started_at = datetime.now(
        timezone.utc
    )

    try:

        OUTPUT_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        config = load_config()

        timezone_local = get_timezone(
            config
        )

        settings = config.get(
            "settings",
            {},
        )

        days = parse_env_int(
            "EPG_DAYS",
            int(settings.get("days", 2)),
        )

        min_programs = parse_env_int(
            "EPG_MIN_PROGRAMS",
            int(
                settings.get(
                    "min_programs",
                    1,
                )
            ),
        )

        now = datetime.now(
            timezone_local
        )

        limit = now + timedelta(
            days=days
        )

        channels = enabled_channels(
            config
        )

        sources = [
            source
            for source in config.get(
                "sources",
                [],
            )
            if source.get(
                "enabled",
                True,
            )
        ]

        sources.sort(
            key=lambda source: int(
                source.get(
                    "priority",
                    999,
                )
            )
        )

        log(
            "================================================="
        )

        log(
            "📺 INICIANDO GERAÇÃO DO EPG"
        )

        log(
            f"Canais: {len(channels)}"
        )

        log(
            f"Fontes: {len(sources)}"
        )

        log(
            f"Janela: {days} dia(s)"
        )

        log(
            f"Agora: {now.isoformat()}"
        )

        log(
            "================================================="
        )

        # ----------------------------------------------------
        # Processar fontes
        # ----------------------------------------------------

        source_results = []

        for source in sources:

            result = process_source(
                source,
                channels,
                config,
                now,
                limit,
            )

            source_results.append(
                result
            )

        # ----------------------------------------------------
        # Fallback
        # ----------------------------------------------------

        programmes = merge_sources(
            source_results,
            channels,
            now,
            limit,
        )

        # ----------------------------------------------------
        # Verificação
        # ----------------------------------------------------

        if len(programmes) < min_programs:

            raise RuntimeError(
                "Nenhuma programação suficiente "
                "foi encontrada."
            )

        # ----------------------------------------------------
        # XML
        # ----------------------------------------------------

        epg_xml_data = create_epg_xml(
            programmes,
            channels,
            config,
        )

        atomic_write_bytes(
            EPG_XML,
            epg_xml_data,
        )

        # ----------------------------------------------------
        # GZIP
        # ----------------------------------------------------

        epg_gz_data = create_gzip(
            epg_xml_data
        )

        atomic_write_bytes(
            EPG_GZ,
            epg_gz_data,
        )

        # ----------------------------------------------------
        # PLAYLIST
        # ----------------------------------------------------

        playlist_config = config.get(
            "playlist",
            {},
        )

        url_tvg = playlist_config.get(
            "url_tvg",
            "",
        )

        playlist = create_playlist(
            channels,
            url_tvg,
        )

        atomic_write_text(
            PLAYLIST_M3U,
            playlist,
        )

        # ----------------------------------------------------
        # RELATÓRIO
        # ----------------------------------------------------

        finished_at = datetime.now(
            timezone.utc
        )

        report = create_report(
            config,
            source_results,
            programmes,
            channels,
            started_at,
            finished_at,
        )

        atomic_write_text(
            REPORT_JSON,
            json.dumps(
                report,
                ensure_ascii=False,
                indent=2,
            ),
        )

        # ----------------------------------------------------
        # Resumo
        # ----------------------------------------------------

        log("")
        log(
            "================================================="
        )

        log(
            "✅ EPG GERADO COM SUCESSO"
        )

        log(
            f"Programas: {len(programmes)}"
        )

        log(
            "Arquivos:"
        )

        log(
            f"  ✓ {EPG_XML}"
        )

        log(
            f"  ✓ {EPG_GZ}"
        )

        log(
            f"  ✓ {PLAYLIST_M3U}"
        )

        log(
            f"  ✓ {REPORT_JSON}"
        )

        log(
            "================================================="
        )

        return 0

    except Exception as exc:

        log("")
        log(
            "================================================="
        )

        log(
            "❌ ERRO FATAL"
        )

        log(
            f"{type(exc).__name__}: {exc}"
        )

        log(
            "================================================="
        )

        traceback.print_exc()

        return 1


if __name__ == "__main__":
    sys.exit(
        main()
    )