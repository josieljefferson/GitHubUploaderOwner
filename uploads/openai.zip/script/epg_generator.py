#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gerador EPG XMLTV + M3U com fallback mi.tv -> TV Map -> ALEPI -> Guia de TV."""
from __future__ import annotations
import asyncio, html, json, logging, os, re, sys, traceback, unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent.parent
CONFIG=ROOT/'config/channels.json'; OUT=ROOT/'output'; DEBUG=ROOT/'debug_epg'
XML=OUT/'epg.xml'; GZ=OUT/'epg.xml.gz'; M3U=OUT/'playlists.m3u'; M3U_ALIAS=OUT/'playlist.m3u'; REPORT=OUT/'epg-report.json'
TZ=timezone(timedelta(hours=-3))
TIME_RE=re.compile(r'(?<!\d)(?:[01]?\d|2[0-3]):[0-5]\d(?!\d)')
logging.basicConfig(level=logging.INFO,format='%(asctime)s | %(levelname)s | %(message)s'); LOG=logging.getLogger('epg')

@dataclass
class Channel:
    id:str; name:str; slug:str=''; logo:str=''; stream:str=''; group:str='Brasil'; aliases:list[str]=field(default_factory=list)
@dataclass
class Source:
    id:str; name:str; priority:int; url:str=''; channel_url:str=''; urls:list[str]=field(default_factory=list); categories:list[dict[str,str]]=field(default_factory=list); only_channels:list[str]=field(default_factory=list)
@dataclass
class Program:
    channel_id:str; title:str; start:datetime; stop:datetime; description:str=''; category:str=''; icon:str=''; source:str=''
@dataclass
class Result:
    programs:list[Program]=field(default_factory=list); detail:str=''


def clean(v:Any)->str:
    if v is None:return ''
    s=html.unescape(str(v)).replace('\xa0',' ').replace('\r','\n').replace('\t',' ')
    s=re.sub(r'[ ]{2,}',' ',s); s=re.sub(r'\n{3,}','\n\n',s); return s.strip()
def norm(v:Any)->str:
    s=unicodedata.normalize('NFKD',clean(v)).encode('ascii','ignore').decode().lower()
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9]+',' ',s)).strip()
def today()->date:return datetime.now(TZ).date()
def days_list(n:int)->list[date]:return [today()+timedelta(days=i) for i in range(n)]
def xml_escape(v:Any)->str:return html.escape(clean(v),quote=True)
def m3u(v:Any)->str:return clean(v).replace('"',"'").replace('\n',' ')


def load_config():
    data=json.loads(CONFIG.read_text(encoding='utf-8')); st=data.get('settings',{})
    n=max(1,int(os.getenv('MITV_DAYS_AHEAD',st.get('days',2))))
    channels=[]; seen=set()
    for x in data.get('channels',[]):
        cid=clean(x.get('id')); name=clean(x.get('name'))
        if not cid or not name: raise ValueError(f'Canal inválido: {cid or "sem id"}')
        if cid in seen: raise ValueError(f'ID duplicado: {cid}')
        seen.add(cid); aliases=[clean(a) for a in x.get('aliases',[]) if clean(a)]
        if name not in aliases: aliases.insert(0,name)
        channels.append(Channel(cid,name,clean(x.get('slug')),clean(x.get('logo')),clean(x.get('stream') or x.get('url')),clean(x.get('group','Brasil')) or 'Brasil',aliases))
    sources=[]
    for x in st.get('sources',[]):
        cats=x.get('categories',[]) if isinstance(x.get('categories',[]),list) else []
        sources.append(Source(clean(x.get('id')),clean(x.get('name',x.get('id'))),int(x.get('priority',999)),clean(x.get('url')),clean(x.get('channel_url')), [clean(u) for u in x.get('urls',[]) if clean(u)], [{"id":clean(c.get('id')),"name":clean(c.get('name')),"url":clean(c.get('url'))} for c in cats if isinstance(c,dict)], [clean(c) for c in x.get('only_channels',[]) if clean(c)]))
    sources.sort(key=lambda s:(s.priority,s.id))
    if not channels: raise ValueError('Nenhum canal configurado.')
    if not sources: raise ValueError('Nenhuma fonte configurada.')
    return channels,sources,n


def parse_time(day:date,v:Any):
    s=clean(v); m=TIME_RE.search(s)
    if not m:return None
    h,mi=map(int,m.group().split(':')); return datetime(day.year,day.month,day.day,h,mi,tzinfo=TZ)
def normalize_programs(items:list[Program],day:date|None=None):
    d={}
    for p in items:
        if day and p.start.date()!=day:continue
        p.title=clean(p.title)
        if len(p.title)<2:continue
        d[(p.channel_id,p.start.isoformat(),norm(p.title))]=p
    arr=sorted(d.values(),key=lambda p:(p.channel_id,p.start))
    for i,p in enumerate(arr):
        if i+1<len(arr) and arr[i+1].channel_id==p.channel_id and arr[i+1].start>p.start:p.stop=arr[i+1].start
        if p.stop<=p.start:p.stop=p.start+timedelta(minutes=30)
    return arr

def channel_match(text:str,c:Channel)->bool:
    lines={norm(x) for x in clean(text).split('\n') if norm(x)}
    return any(norm(a) in lines for a in c.aliases)

def find_block(content:str,c:Channel)->str:
    from bs4 import BeautifulSoup
    soup=BeautifulSoup(content,'html.parser'); best=''; best_score=-1
    for el in soup.find_all(['h1','h2','h3','h4','h5','strong','b','a','span','div','li','img']):
        vals=[el.get('alt',''),el.get('title','')] if el.name=='img' else [el.get_text('\n',strip=True)]
        if not any(norm(v) in {norm(a) for a in c.aliases} for v in vals if v):continue
        node=el
        for depth in range(8):
            if node is None:break
            text=clean(node.get_text('\n',strip=True)); count=len(TIME_RE.findall(text))
            if 10<=len(text)<=7000 and 1<=count<=60 and channel_match(text,c):
                score=count*1000-len(text)-depth*30
                if score>best_score:best_score,best=score,text
            node=node.parent
    return best

def parse_text(text:str,c:Channel,day:date,source_id:str):
    ms=list(TIME_RE.finditer(clean(text))); out=[]
    for i,m in enumerate(ms):
        start=parse_time(day,m.group());
        if not start:continue
        end=ms[i+1].start() if i+1<len(ms) else len(text); title=clean(text[m.end():end]).strip(' -–—:|•·')
        if len(title)<2 or len(title)>300 or norm(title) in {norm(a) for a in c.aliases}:continue
        out.append(Program(c.id,title,start,start+timedelta(minutes=30),source=source_id))
    return normalize_programs(out,day)

async def create_browser():
    from playwright.async_api import async_playwright
    pw=await async_playwright().start(); browser=await pw.chromium.launch(headless=True,args=['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    ctx=await browser.new_context(locale='pt-BR',timezone_id='America/Sao_Paulo',user_agent='Mozilla/5.0 Chrome/131 Safari/537.36')
    page=await ctx.new_page(); page.set_default_timeout(int(os.getenv('MITV_PAGE_TIMEOUT','60000'))); return pw,browser,ctx,page

class PageCache:
    def __init__(self,page):self.page=page;self.cache={};self.lock=asyncio.Lock()
    async def get(self,url:str):
        if url in self.cache:return self.cache[url]
        async with self.lock:
            if url in self.cache:return self.cache[url]
            last=''
            for attempt in range(1,max(1,int(os.getenv('MITV_RETRIES','3')))+1):
                try:
                    LOG.info('🌐 %s | tentativa %d/%s',url,attempt,os.getenv('MITV_RETRIES','3'))
                    r=await self.page.goto(url,wait_until='domcontentloaded',timeout=int(os.getenv('MITV_PAGE_TIMEOUT','60000')))
                    if r and r.status>=400:raise RuntimeError(f'HTTP {r.status}')
                    try:await self.page.wait_for_load_state('networkidle',timeout=10000)
                    except Exception:pass
                    wait=int(os.getenv('MITV_WAIT','3000'))
                    if wait:await self.page.wait_for_timeout(wait)
                    content=await self.page.content()
                    if len(content)<200:raise RuntimeError('conteúdo vazio')
                    self.cache[url]=content;return content
                except Exception as e:
                    last=str(e)
                    if attempt<max(1,int(os.getenv('MITV_RETRIES','3'))):await asyncio.sleep(min(2**(attempt-1),5))
            raise RuntimeError(f'Falha após tentativas: {url} | {last}')

def debug(source,c,day,content):
    try:
        DEBUG.mkdir(parents=True,exist_ok=True); p=DEBUG/f'{source}_{re.sub(r"[^\w.-]+","_",c.id)}_{day.isoformat()}.html';p.write_text(content,encoding='utf-8')
    except Exception:pass

async def fetch_mitv(cache:PageCache,s:Source,c:Channel,day:date):
    if not c.slug:return Result(detail='Canal sem slug no mi.tv.')
    url=(s.channel_url or 'https://mi.tv/br/canais/{slug}').format(slug=c.slug,date=day.isoformat())
    if '{date}' not in (s.channel_url or '') and day!=today():url=url.rstrip('/')+'/'+day.isoformat()
    content=await cache.get(url);debug(s.id,c,day,content); from bs4 import BeautifulSoup
    text=BeautifulSoup(content,'html.parser').get_text('\n',strip=True); p=parse_text(text,c,day,s.id)
    return Result(p,'Programação encontrada.' if p else 'Nenhum programa encontrado.')

async def fetch_tvmap(cache:PageCache,s:Source,c:Channel,day:date):
    months=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez']; urls=[]
    if day==today():urls+=s.urls
    for h in (0,6,12,18):urls.append(f'https://tvmap.com.br/Programacao/{day.day:02d}-{months[day.month-1]}-{day.year}/{h:02d}.00hs')
    out=[];ok=0
    for url in dict.fromkeys(urls):
        try:
            content=await cache.get(url);ok+=1;debug(s.id,c,day,content);block=find_block(content,c)
            if block:out+=parse_text(block,c,day,s.id)
        except Exception as e:LOG.warning('⚠️ TV Map %s: %s',url,e)
    out=normalize_programs(out,day);return Result(out,f'{ok} páginas consultadas.' if out else 'Canal não encontrado nas páginas TV Map.')

async def fetch_alepi(cache:PageCache,s:Source,c:Channel,day:date):
    if day!=today():return Result(detail='ALEPI fornece somente a programação do dia atual.')
    content=await cache.get(s.url);debug(s.id,c,day,content);block=find_block(content,c)
    if not block:
        from bs4 import BeautifulSoup;block=BeautifulSoup(content,'html.parser').get_text('\n',strip=True)
    p=parse_text(block,c,day,s.id);return Result(p,'Bloco ALEPI localizado.' if p else 'Canal/programação não encontrada.')

async def fetch_guiadetv(cache:PageCache,s:Source,c:Channel,day:date):
    if day!=today():return Result(detail='Guia de TV não usado para dias futuros.')
    for cat in s.categories:
        try:
            content=await cache.get(cat['url']);debug(f"{s.id}-{cat['id']}",c,day,content);block=find_block(content,c)
            if block:
                p=parse_text(block,c,day,f"{s.id}:{cat['id']}")
                if p:return Result(p,f"Categoria: {cat['name']}")
        except Exception as e:LOG.warning('⚠️ Guia [%s]: %s',cat['name'],e)
    return Result(detail='Canal não localizado nas categorias.')

async def fetch_source(cache,s,c,day):
    if s.only_channels and c.id not in s.only_channels:return None
    if s.id=='mitv':return await fetch_mitv(cache,s,c,day)
    if s.id=='tvmap':return await fetch_tvmap(cache,s,c,day)
    if s.id=='alepi':return await fetch_alepi(cache,s,c,day)
    if s.id=='guiadetv':return await fetch_guiadetv(cache,s,c,day)
    return Result(detail=f'Fonte não implementada: {s.id}')

def report_base(days,sources,channels):
    return {'generator':'IPTV EPG Generator','version':'5.0','status':'running','generated_at':datetime.now(TZ).isoformat(),'timezone':'-0300','timezone_id':'America/Sao_Paulo','days_ahead':days,'days':[d.isoformat() for d in days],'safety':{'minimum_channel_coverage':float(os.getenv('EPG_MIN_CHANNEL_COVERAGE','0.50')),'minimum_program_ratio':float(os.getenv('EPG_MIN_PROGRAM_RATIO','0.50')),'require_all_channels':os.getenv('EPG_REQUIRE_ALL_CHANNELS','0').lower() in {'1','true','yes','sim'}},'sources':{s.id:{'name':s.name,'priority':s.priority,'attempts':0,'successes':0,'no_programs':0,'errors':0,'programs':0} for s in sources},'channels':{c.id:{'name':c.name,'status':'pending','programs':0,'dates':{}} for c in channels},'totals':{},'publication':{'xml':'not_written','playlist':'not_written'},'fatal_error':None}

async def collect(channels,sources,days,cache,report):
    allp=[]; minp=max(1,int(os.getenv('MITV_MIN_PROGRAMS','1')))
    for c in channels:
        for day in days:
            selected=False
            for s in sources:
                if s.id=='mitv' and not c.slug:continue
                if s.only_channels and c.id not in s.only_channels:continue
                try:r=await fetch_source(cache,s,c,day)
                except Exception as e:
                    LOG.warning('❌ %s | %s | %s: %s',c.name,day,s.name,e);report['sources'][s.id]['errors']+=1;continue
                if r is None:continue
                p=normalize_programs(r.programs,day); sr=report['sources'][s.id];sr['attempts']+=1;sr['programs']+=len(p)
                if len(p)>=minp:
                    sr['successes']+=1; dr={'status':'success','source':s.id,'source_name':s.name,'programs':len(p),'detail':r.detail};report['channels'][c.id]['dates'][day.isoformat()]=dr;allp+=p;selected=True
                    LOG.info('✅ %s | %s | fonte selecionada: %s | %d programas',c.name,day,s.name,len(p));break
                sr['no_programs']+=1
            if not selected:
                report['channels'][c.id]['dates'][day.isoformat()]={'status':'failed','source':None,'programs':0};LOG.error('❌ Nenhuma fonte conseguiu %s em %s.',c.name,day)
        cr=report['channels'][c.id];cr['programs']=sum(x['programs'] for x in cr['dates'].values()); ok=sum(x['status']=='success' for x in cr['dates'].values());cr['status']='success' if ok==len(days) else ('partial' if ok else 'failed')
    return normalize_programs(allp)

def xml_time(d):return d.astimezone(TZ).strftime('%Y%m%d%H%M%S %z')
def make_xml(channels,programs):
    lines=['<?xml version="1.0" encoding="UTF-8"?>','<tv generator-info-name="IPTV EPG Generator">']
    for c in channels:
        lines.append(f'  <channel id="{xml_escape(c.id)}"><display-name>{xml_escape(c.name)}</display-name>')
        if c.logo:lines.append(f'    <icon src="{xml_escape(c.logo)}"/>')
        lines.append('  </channel>')
    for p in sorted(programs,key=lambda x:(x.channel_id,x.start)):
        lines.append(f'  <programme channel="{xml_escape(p.channel_id)}" start="{xml_time(p.start)}" stop="{xml_time(p.stop)}"><title lang="pt">{xml_escape(p.title)}</title></programme>')
    lines.append('</tv>');return '\n'.join(lines)+'\n'
def write_atomic(path,content):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp');tmp.write_text(content,encoding='utf-8');tmp.replace(path)
def make_m3u(channels):
    lines=['#EXTM3U'];n=0
    for c in channels:
        if not c.stream:continue
        lines.append(f'#EXTINF:-1 tvg-id="{m3u(c.id)}" tvg-name="{m3u(c.name)}" tvg-logo="{m3u(c.logo)}" group-title="{m3u(c.group) or "Brasil"}",{m3u(c.name)}');lines.append(c.stream);n+=1
    if n==0:raise RuntimeError('Nenhum canal possui stream.')
    return '\n'.join(lines)+'\n',n
def safety(channels,programs):
    coverage=len({p.channel_id for p in programs})/len(channels);old=0
    if XML.exists():
        try:old=len(ET.parse(XML).getroot().findall('programme'))
        except Exception:old=0
    ratio=float(os.getenv('EPG_MIN_PROGRAM_RATIO','0.50'));minimum=float(os.getenv('EPG_MIN_CHANNEL_COVERAGE','0.50'))
    ok=bool(programs) and coverage>=minimum and (not old or len(programs)>=old*ratio)
    if os.getenv('EPG_REQUIRE_ALL_CHANNELS','0').lower() in {'1','true','yes','sim'}:ok=ok and len({p.channel_id for p in programs})==len(channels)
    return {'passed':ok,'new_programs':len(programs),'previous_programs':old,'channel_coverage':coverage,'reason':None if ok else 'Cobertura/quantidade abaixo do limite de segurança.'}

def save_report(r):write_atomic(REPORT,json.dumps(r,ensure_ascii=False,indent=2)+'\n')

async def main_async():
    channels,sources,n=load_config();days=days_list(n);report=report_base(days,sources,channels);res=None
    LOG.info('==================================================');LOG.info('🚀 Iniciando geração EPG');LOG.info('📺 Canais: %d',len(channels));LOG.info('📅 Dias: %d',n);LOG.info('🔀 Fontes: %s',' → '.join(f'{s.priority}:{s.name}' for s in sources));LOG.info('==================================================')
    try:
        res=await create_browser();pw,browser,ctx,page=res;cache=PageCache(page);programs=await collect(channels,sources,days,cache,report);LOG.info('📊 Total de programas: %d',len(programs))
        check=safety(channels,programs);report['safety_result']=check
        if not check['passed']:raise RuntimeError(check['reason'])
        content=make_xml(channels,programs);ET.fromstring(content);write_atomic(XML,content);report['publication']['xml']='success'
        m3u_content,entries=make_m3u(channels);write_atomic(M3U,m3u_content);write_atomic(M3U_ALIAS,m3u_content);report['publication'].update({'playlist':'success','playlist_entries':entries})
        return 0
    except Exception as e:
        report['fatal_error']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};LOG.exception('❌ ERRO FATAL NA GERAÇÃO DO EPG');return 1
    finally:
        if res:
            try:await res[2].close()
            except Exception:pass
            try:await res[1].close()
            except Exception:pass
            try:await res[0].stop()
            except Exception:pass
        report['totals']={'channels':len(report['channels']),'successful_channels':sum(x['status']=='success' for x in report['channels'].values()),'partial_channels':sum(x['status']=='partial' for x in report['channels'].values()),'failed_channels':sum(x['status']=='failed' for x in report['channels'].values()),'programs':sum(x['programs'] for x in report['channels'].values())}
        report['status']='failed' if report['fatal_error'] else ('partial' if report['totals']['failed_channels'] or report['totals']['partial_channels'] else 'success')
        report['outputs']={'epg.xml':XML.exists(),'epg.xml.gz':GZ.exists(),'playlists.m3u':M3U.exists(),'playlist.m3u':M3U_ALIAS.exists(),'epg-report.json':REPORT.exists()}
        report['finished_at']=datetime.now(TZ).isoformat();save_report(report)

def main():
    try:return asyncio.run(main_async())
    except KeyboardInterrupt:return 130
if __name__=='__main__':sys.exit(main())
