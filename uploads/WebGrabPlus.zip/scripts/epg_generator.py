#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
=============================================================
                    📺 EPG GENERATOR
=============================================================

Gera:

    output/epg.xml
    output/epg.xml.gz
    output/epg-report.json

Catálogos:

    config/band.uol.com.br.channels.xml
    config/tvmap.com.br.channels.xml
    config/redeglobo.globo.com.channels.xml

Características:

    • XMLTV
    • UTF-8
    • Horário -0300
    • 2 dias de programação
    • Retry automático
    • Timeout
    • Cache HTTP
    • Deduplicação de canais
    • Relatório JSON
    • Validação do XML
    • Compatível com GitHub Actions

IMPORTANTE:

Os arquivos *.channels.xml são catálogos WebGrab+Plus.
Eles NÃO contêm necessariamente a programação.

O programa utiliza esses arquivos para descobrir os canais
e consulta as fontes de programação configuradas abaixo.
=============================================================
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
import re
import sys
import time
import unicodedata

from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import quote, urljoin

import requests
import xml.etree.ElementTree as ET


# ============================================================
# CONFIGURAÇÃO
# ============================================================

ROOT_DIR = Path(__file__).resolve().parent.parent

CONFIG_DIR = ROOT_DIR / "config"
OUTPUT_DIR = ROOT_DIR / "output"
CACHE_DIR = ROOT_DIR / ".cache" / "epg"

OUTPUT_XML = OUTPUT_DIR / "epg.xml"
OUTPUT_GZ = OUTPUT_DIR / "epg.xml.gz"
OUTPUT_REPORT = OUTPUT_DIR / "epg-report.json"


# Quantidade de dias de EPG
DAYS = int(os.getenv("EPG_DAYS", "2"))

# Fuso oficial
TIMEZONE_OFFSET = "-0300"

# Timezone Python
BRAZIL_TZ = timezone(timedelta(hours=-3))

# HTTP
REQUEST_TIMEOUT = int(os.getenv("EPG_TIMEOUT", "30"))
REQUEST_RETRIES = int(os.getenv("EPG_RETRIES", "3"))

# Tempo de cache
CACHE_SECONDS = int(os.getenv("EPG_CACHE_SECONDS", "21600"))

# User Agent
USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 "
    "(KHTML, like Gecko) "
    "Chrome/140.0 Safari/537.36 "
    "EPG-Generator/1.0"
)


# ============================================================
# FONTES
# ============================================================

CATALOG_FILES = [
    CONFIG_DIR / "band.uol.com.br.channels.xml",
    CONFIG_DIR / "clarotv.com.br.channels.xml",
    CONFIG_DIR / "clarotvmais.com.br.channels.xml",
    CONFIG_DIR / "foxplaybrasil.com.br.channels.xml",
    CONFIG_DIR / "guiadatv.com.channels.xml",
    CONFIG_DIR / "hagah.com.br.channels.xml",
    CONFIG_DIR / "hbobrasil.com.channels.xml",
    CONFIG_DIR / "lineup.net.br.channels.xml",
    CONFIG_DIR / "mais.sbt.com.br.channels.xml",
    CONFIG_DIR / "meuguia.tv.channels.xml",
    CONFIG_DIR / "netcombo.com.br.channels.xml",
    CONFIG_DIR / "oi.com.br.channels.xml",
    CONFIG_DIR / "redeglobo.globo.com.channels.xm
    CONFIG_DIR / "sky.com.br.channels.xml",
    CONFIG_DIR / "telecineplay.com.br.channels.xml",
    CONFIG_DIR / "tvinside.com.br.channels.xml",
    CONFIG_DIR / "tvmap.com.br.channels.xml",
    CONFIG_DIR / "vcfaz.tv.channels.xml",
    CONFIG_DIR / "vivo.com.br.channels.xml",
    
]


# Fontes de programação.
#
# A implementação tenta descobrir a programação das fontes
# por busca de página/canal.
#
# As fontes podem ser alteradas futuramente sem alterar
# os catálogos XML.
SOURCES = [
    {
        "name": "Band",
        "base": "https://band.uol.com.br",
        "priority": 1,
    },
    {
        "name": "Claro TV",
        "base": "https://clarotv.com.br",
        "priority": 2,
    },
    {
        "name": "Claro TV Mais",
        "base": "https://clarotvmais.com.br",
        "priority": 3,
    },
    {
        "name": "Fox Play Brasil",
        "base": "https://foxplaybrasil.com.br",
        "priority": 4,
    },
    {
        "name": "Globo",
        "base": "https://redeglobo.globo.com",
        "priority": 5,
    },
    {
        "name": "Guia de TV",
        "base": "https://guiadetv.com",
        "priority": 6,
    },
    {
        "name": "Hagah",
        "base": "https://hagah.com.br",
        "priority": 7,
    },
    {
        "name": "HBO Brasil",
        "base": "https://hbobrasil.com",
        "priority": 8,
    },
    {
        "name": "Lineup",
        "base": "https://lineup.net.br",
        "priority": 9,
    },
    {
        "name": "Mais SBT",
        "base": "https://mais.sbt.com.br",
        "priority": 10,
    },
    {
        "name": "Meu Guia",
        "base": "https://meuguia.tv",
        "priority": 11,
    },
    {
        "name": "Net Combo",
        "base": "https://netcombo.com.br",
        "priority": 12,
    },
    {
        "name": "Oi",
        "base": "https://oi.com.br",
        "priority": 13,
    },
    {
        "name": "Sky",
        "base": "https://sky.com.br",
        "priority": 14,
    },
    {
        "name": "Telecine Play",
        "base": "https://telecineplay.com.br",
        "priority": 15,
    },
    {
        "name": "TV Inside",
        "base": "https://tvinside.com.br",
        "priority": 16,
    },
    {
        "name": "TV Map",
        "base": "https://tvmap.com.br",
        "priority": 17,
    },
    {
        "name": "VC Faz TV",
        "base": "https://vcfaz.tv",
        "priority": 18,
    },
    {
        "name": "Vivo",
        "base": "https://vivo.com.br",
        "priority": 19,
    },
]


# ============================================================
# LOG
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

log = logging.getLogger("EPG")


# ============================================================
# MODELOS
# ============================================================

@dataclass
class Channel:
    xmltv_id: str
    name: str
    site: str
    site_id: str
    source: str


@dataclass
class Programme:
    channel: str
    start: datetime
    stop: datetime
    title: str
    description: str = ""
    category: str = ""


# ============================================================
# HTTP SESSION
# ============================================================

SESSION = requests.Session()

SESSION.headers.update(
    {
        "User-Agent": USER_AGENT,
        "Accept": (
            "text/html,application/xhtml+xml,"
            "application/xml;q=0.9,*/*;q=0.8"
        ),
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
    }
)


# ============================================================
# UTILITÁRIOS
# ============================================================

def ensure_directories() -> None:
    """Cria os diretórios necessários."""

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_DIR.mkdir(parents=True, exist_ok=True)


def normalize_text(value: str) -> str:
    """Normaliza espaços."""

    if not value:
        return ""

    value = value.replace("\xa0", " ")

    value = re.sub(r"\s+", " ", value)

    return value.strip()


def normalize_key(value: str) -> str:
    """
    Cria chave de comparação sem acentos,
    pontuação ou diferença de maiúsculas.
    """

    value = normalize_text(value)

    value = unicodedata.normalize("NFKD", value)

    value = "".join(
        c for c in value
        if not unicodedata.combining(c)
    )

    value = value.lower()

    value = re.sub(r"[^a-z0-9]+", "", value)

    return value


def safe_filename(url: str) -> str:
    """Gera nome de cache baseado na URL."""

    return hashlib.sha256(
        url.encode("utf-8")
    ).hexdigest() + ".cache"


def now_brazil() -> datetime:
    """Retorna horário atual em Brasília."""

    return datetime.now(BRAZIL_TZ)


# ============================================================
# HTTP / CACHE
# ============================================================

def fetch(
    url: str,
    *,
    use_cache: bool = True,
) -> Optional[str]:

    cache_file = CACHE_DIR / safe_filename(url)

    # --------------------------------------------------------
    # CACHE
    # --------------------------------------------------------

    if use_cache and cache_file.exists():

        age = time.time() - cache_file.stat().st_mtime

        if age < CACHE_SECONDS:

            try:

                text = cache_file.read_text(
                    encoding="utf-8"
                )

                log.info(
                    "💾 Cache: %s",
                    url,
                )

                return text

            except Exception:
                pass

    # --------------------------------------------------------
    # DOWNLOAD
    # --------------------------------------------------------

    last_error = None

    for attempt in range(1, REQUEST_RETRIES + 1):

        try:

            log.info(
                "🌐 Acessando [%s/%s]: %s",
                attempt,
                REQUEST_RETRIES,
                url,
            )

            response = SESSION.get(
                url,
                timeout=REQUEST_TIMEOUT,
            )

            response.raise_for_status()

            response.encoding = (
                response.apparent_encoding
                or response.encoding
                or "utf-8"
            )

            text = response.text

            if use_cache:

                try:

                    cache_file.write_text(
                        text,
                        encoding="utf-8",
                    )

                except Exception as exc:

                    log.warning(
                        "⚠️ Falha ao salvar cache: %s",
                        exc,
                    )

            return text

        except Exception as exc:

            last_error = exc

            log.warning(
                "⚠️ Falha HTTP: %s",
                exc,
            )

            if attempt < REQUEST_RETRIES:

                time.sleep(2 * attempt)

    log.error(
        "❌ Não foi possível acessar: %s | %s",
        url,
        last_error,
    )

    return None


# ============================================================
# LEITURA DOS CATÁLOGOS
# ============================================================

def parse_catalog(
    file_path: Path,
) -> List[Channel]:

    channels: List[Channel] = []

    if not file_path.exists():

        log.warning(
            "⚠️ Catálogo não encontrado: %s",
            file_path,
        )

        return channels

    try:

        tree = ET.parse(file_path)

        root = tree.getroot()

    except Exception as exc:

        log.error(
            "❌ Erro lendo catálogo %s: %s",
            file_path,
            exc,
        )

        return channels

    site = root.attrib.get(
        "site",
        "",
    )

    for node in root.findall(
        ".//channel"
    ):

        xmltv_id = normalize_text(
            node.attrib.get(
                "xmltv_id",
                "",
            )
        )

        site_id = normalize_text(
            node.attrib.get(
                "site_id",
                "",
            )
        )

        name = normalize_text(
            node.text or xmltv_id
        )

        if not xmltv_id:

            continue

        channels.append(
            Channel(
                xmltv_id=xmltv_id,
                name=name,
                site=site,
                site_id=site_id,
                source=site,
            )
        )

    return channels


def load_channels() -> List[Channel]:

    result: List[Channel] = []

    seen = set()

    for catalog in CATALOG_FILES:

        items = parse_catalog(catalog)

        log.info(
            "📡 %s: %d canais",
            catalog.name,
            len(items),
        )

        for channel in items:

            key = normalize_key(
                channel.xmltv_id
            )

            if not key:
                continue

            if key in seen:

                continue

            seen.add(key)

            result.append(channel)

    result.sort(
        key=lambda x: normalize_key(x.name)
    )

    log.info(
        "📺 Total de canais únicos: %d",
        len(result),
    )

    return result


# ============================================================
# IDENTIFICAÇÃO DE FONTE
# ============================================================

def source_for_channel(
    channel: Channel,
) -> Optional[dict]:

    site = channel.site.lower()

    if "band.uol.com.br" in site:

        return SOURCES[0]

    if "tvmap.com.br" in site:

        return SOURCES[1]

    if "redeglobo.globo.com" in site:

        return SOURCES[2]

    return None


# ============================================================
# BUSCA DE URL DO CANAL
# ============================================================

def build_candidate_urls(
    channel: Channel,
) -> List[str]:

    source = source_for_channel(channel)

    if not source:

        return []

    base = source["base"].rstrip("/")

    site_id = channel.site_id.strip()

    name = channel.name.strip()

    candidates = []

    # --------------------------------------------------------
    # URLs genéricas
    # --------------------------------------------------------

    if site_id:

        candidates.extend(
            [
                f"{base}/{quote(site_id)}",
                f"{base}/programacao/{quote(site_id)}",
                f"{base}/programacao/{quote(site_id.lower())}",
                f"{base}/programacao/{quote(site_id.replace('/', '-'))}",
            ]
        )

    if name:

        candidates.extend(
            [
                f"{base}/programacao/{quote(name)}",
                f"{base}/programacao/{quote(name.lower())}",
            ]
        )

    # --------------------------------------------------------
    # Remove duplicados
    # --------------------------------------------------------

    unique = []

    seen = set()

    for url in candidates:

        if url in seen:
            continue

        seen.add(url)

        unique.append(url)

    return unique


# ============================================================
# PARSING GENÉRICO DE PROGRAMAÇÃO
# ============================================================

TIME_RE = re.compile(
    r"\b([01]?\d|2[0-3]):([0-5]\d)\b"
)


def parse_time(
    value: str,
    base_date: datetime,
) -> Optional[datetime]:

    match = TIME_RE.search(value or "")

    if not match:
        return None

    hour = int(match.group(1))
    minute = int(match.group(2))

    return base_date.replace(
        hour=hour,
        minute=minute,
        second=0,
        microsecond=0,
    )


def extract_title(
    element: ET.Element,
) -> str:

    # Prioridade para atributos comuns
    for attr in (
        "title",
        "name",
        "program",
        "program-title",
    ):

        value = element.attrib.get(
            attr,
            "",
        )

        if value:

            return normalize_text(value)

    # Depois tenta tags
    for tag in (
        "title",
        "name",
        "program",
        "h1",
        "h2",
        "h3",
    ):

        child = element.find(
            ".//" + tag
        )

        if child is not None and child.text:

            value = normalize_text(
                child.text
            )

            if value:

                return value

    return ""


def extract_description(
    element: ET.Element,
) -> str:

    for attr in (
        "description",
        "desc",
        "summary",
    ):

        value = element.attrib.get(
            attr,
            "",
        )

        if value:

            return normalize_text(value)

    for tag in (
        "description",
        "desc",
        "summary",
        "p",
    ):

        child = element.find(
            ".//" + tag
        )

        if child is not None and child.text:

            value = normalize_text(
                child.text
            )

            if value:

                return value

    return ""


# ============================================================
# EXTRAÇÃO DE PROGRAMAÇÃO HTML
# ============================================================

def extract_programmes_from_html(
    html: str,
    channel: Channel,
) -> List[Programme]:

    """
    Parser genérico.

    Como os sites podem mudar o HTML,
    são analisados vários padrões.

    Caso uma fonte tenha um layout específico,
    uma função específica pode ser adicionada
    posteriormente sem alterar o restante do sistema.
    """

    programmes: List[Programme] = []

    if not html:
        return programmes

    # --------------------------------------------------------
    # 1. Tenta encontrar JSON-LD
    # --------------------------------------------------------

    json_blocks = re.findall(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>'
        r'(.*?)'
        r'</script>',
        html,
        flags=re.I | re.S,
    )

    for block in json_blocks:

        try:

            data = json.loads(
                block.strip()
            )

        except Exception:

            continue

        if isinstance(data, dict):

            data = [data]

        if not isinstance(data, list):

            continue

        for item in data:

            if not isinstance(item, dict):
                continue

            title = normalize_text(
                str(
                    item.get(
                        "name",
                        ""
                    )
                )
            )

            start_raw = item.get(
                "startDate"
            )

            end_raw = item.get(
                "endDate"
            )

            if not title or not start_raw:
                continue

            try:

                start = datetime.fromisoformat(
                    str(start_raw).replace(
                        "Z",
                        "+00:00",
                    )
                )

                if start.tzinfo is None:

                    start = start.replace(
                        tzinfo=BRAZIL_TZ
                    )

                start = start.astimezone(
                    BRAZIL_TZ
                )

            except Exception:

                continue

            if end_raw:

                try:

                    stop = datetime.fromisoformat(
                        str(end_raw).replace(
                            "Z",
                            "+00:00",
                        )
                    )

                    if stop.tzinfo is None:

                        stop = stop.replace(
                            tzinfo=BRAZIL_TZ
                        )

                    stop = stop.astimezone(
                        BRAZIL_TZ
                    )

                except Exception:

                    stop = start + timedelta(
                        minutes=30
                    )

            else:

                stop = start + timedelta(
                    minutes=30
                )

            programmes.append(
                Programme(
                    channel=channel.xmltv_id,
                    start=start,
                    stop=stop,
                    title=title,
                )
            )

    if programmes:

        return programmes

    # --------------------------------------------------------
    # 2. Procura elementos contendo horário
    # --------------------------------------------------------

    try:

        parser = ET.fromstring(
            f"<root>{html}</root>"
        )

    except Exception:

        # HTML não é XML válido.
        # Continua para parser textual.
        parser = None

    if parser is not None:

        for element in parser.iter():

            text = " ".join(
                element.itertext()
            )

            text = normalize_text(text)

            if not text:
                continue

            match = TIME_RE.search(text)

            if not match:
                continue

            start = parse_time(
                text,
                now_brazil(),
            )

            if start is None:
                continue

            title = extract_title(
                element
            )

            if not title:

                parts = [
                    normalize_text(x)
                    for x in text.split()
                    if x
                ]

                title = " ".join(
                    parts[1:]
                )[:200]

            if not title:
                continue

            description = extract_description(
                element
            )

            programmes.append(
                Programme(
                    channel=channel.xmltv_id,
                    start=start,
                    stop=start + timedelta(
                        minutes=30
                    ),
                    title=title,
                    description=description,
                )
            )

    # --------------------------------------------------------
    # 3. Parser textual de fallback
    # --------------------------------------------------------

    if not programmes:

        text = re.sub(
            r"<[^>]+>",
            " ",
            html,
        )

        text = normalize_text(text)

        matches = list(
            TIME_RE.finditer(text)
        )

        for index, match in enumerate(matches):

            start = parse_time(
                match.group(0),
                now_brazil(),
            )

            if start is None:
                continue

            begin = match.end()

            if index + 1 < len(matches):

                end = matches[
                    index + 1
                ].start()

            else:

                end = min(
                    len(text),
                    begin + 250,
                )

            title = normalize_text(
                text[begin:end]
            )

            title = re.sub(
                r"^[|:\-–—]+",
                "",
                title,
            )

            title = title[:200]

            if not title:
                continue

            programmes.append(
                Programme(
                    channel=channel.xmltv_id,
                    start=start,
                    stop=start + timedelta(
                        minutes=30
                    ),
                    title=title,
                )
            )

    return programmes


# ============================================================
# NORMALIZAÇÃO DE PROGRAMAS
# ============================================================

def normalize_programmes(
    programmes: List[Programme],
) -> List[Programme]:

    result = []

    seen = set()

    for program in programmes:

        title = normalize_text(
            program.title
        )

        if not title:
            continue

        start = program.start
        stop = program.stop

        if stop <= start:

            stop = start + timedelta(
                minutes=30
            )

        key = (
            program.channel,
            start.isoformat(),
            normalize_key(title),
        )

        if key in seen:
            continue

        seen.add(key)

        result.append(
            Programme(
                channel=program.channel,
                start=start,
                stop=stop,
                title=title,
                description=normalize_text(
                    program.description
                ),
                category=normalize_text(
                    program.category
                ),
            )
        )

    result.sort(
        key=lambda x: (
            x.channel,
            x.start,
        )
    )

    return result


# ============================================================
# BUSCAR PROGRAMAÇÃO
# ============================================================

def fetch_channel_programmes(
    channel: Channel,
) -> Tuple[List[Programme], str]:

    urls = build_candidate_urls(
        channel
    )

    if not urls:

        return [], "sem_url"

    for url in urls:

        html = fetch(url)

        if not html:
            continue

        programmes = (
            extract_programmes_from_html(
                html,
                channel,
            )
        )

        programmes = normalize_programmes(
            programmes
        )

        if programmes:

            log.info(
                "✅ %s | %d programas | %s",
                channel.name,
                len(programmes),
                url,
            )

            return programmes, url

    log.warning(
        "⚠️ Sem programação: %s",
        channel.name,
    )

    return [], "nao_encontrado"


# ============================================================
# XMLTV
# ============================================================

def xml_escape(
    value: str,
) -> str:

    return (
        value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def xml_time(
    value: datetime,
) -> str:

    value = value.astimezone(
        BRAZIL_TZ
    )

    return value.strftime(
        "%Y%m%d%H%M%S -0300"
    )


def build_xml(
    channels: List[Channel],
    programmes: List[Programme],
) -> bytes:

    root = ET.Element(
        "tv",
        {
            "generator-info-name":
                "EPG Generator Python",
            "generator-info-url":
                "https://github.com/",
        },
    )

    # --------------------------------------------------------
    # CHANNELS
    # --------------------------------------------------------

    for channel in channels:

        node = ET.SubElement(
            root,
            "channel",
            {
                "id": channel.xmltv_id,
            },
        )

        display = ET.SubElement(
            node,
            "display-name",
        )

        display.text = channel.name

        # Informação da fonte
        source = ET.SubElement(
            node,
            "icon",
        )

        # Não adicionamos URL falsa de logo.
        source.set(
            "src",
            "",
        )

    # --------------------------------------------------------
    # PROGRAMMES
    # --------------------------------------------------------

    for program in programmes:

        node = ET.SubElement(
            root,
            "programme",
            {
                "channel": program.channel,
                "start": xml_time(
                    program.start
                ),
                "stop": xml_time(
                    program.stop
                ),
            },
        )

        title = ET.SubElement(
            node,
            "title",
            {
                "lang": "pt",
            },
        )

        title.text = program.title

        if program.description:

            desc = ET.SubElement(
                node,
                "desc",
                {
                    "lang": "pt",
                },
            )

            desc.text = (
                program.description
            )

        if program.category:

            category = ET.SubElement(
                node,
                "category",
                {
                    "lang": "pt",
                },
            )

            category.text = (
                program.category
            )

    # --------------------------------------------------------
    # INDENTAÇÃO
    # --------------------------------------------------------

    try:

        ET.indent(
            root,
            space="  ",
        )

    except AttributeError:

        pass

    data = ET.tostring(
        root,
        encoding="utf-8",
        xml_declaration=True,
    )

    return data


# ============================================================
# VALIDAÇÃO
# ============================================================

def validate_xml(
    data: bytes,
) -> Tuple[bool, int, int]:

    try:

        root = ET.fromstring(
            data
        )

    except Exception as exc:

        log.error(
            "❌ XML inválido: %s",
            exc,
        )

        return False, 0, 0

    channels = root.findall(
        "channel"
    )

    programmes = root.findall(
        "programme"
    )

    valid_channels = 0

    for channel in channels:

        if channel.attrib.get(
            "id"
        ):

            valid_channels += 1

    valid_programmes = 0

    for program in programmes:

        if (
            program.attrib.get(
                "channel"
            )
            and program.attrib.get(
                "start"
            )
            and program.attrib.get(
                "stop"
            )
        ):

            valid_programmes += 1

    valid = (
        valid_channels > 0
        and valid_programmes > 0
    )

    return (
        valid,
        valid_channels,
        valid_programmes,
    )


# ============================================================
# ESCRITA ATÔMICA
# ============================================================

def atomic_write(
    path: Path,
    data: bytes,
) -> None:

    temporary = path.with_suffix(
        path.suffix + ".tmp"
    )

    temporary.write_bytes(
        data
    )

    temporary.replace(
        path
    )


# ============================================================
# GZIP
# ============================================================

def write_gzip(
    data: bytes,
    path: Path,
) -> None:

    temporary = path.with_suffix(
        path.suffix + ".tmp"
    )

    with gzip.open(
        temporary,
        "wb",
        compresslevel=9,
    ) as file:

        file.write(data)

    temporary.replace(
        path
    )


# ============================================================
# RELATÓRIO
# ============================================================

def write_report(
    channels: List[Channel],
    programmes: List[Programme],
    statuses: Dict[str, dict],
    elapsed: float,
) -> None:

    successful = sum(
        1
        for item in statuses.values()
        if item["programmes"] > 0
    )

    failed = len(statuses) - successful

    report = {
        "generated_at": now_brazil().isoformat(),
        "timezone": TIMEZONE_OFFSET,
        "days": DAYS,

        "statistics": {
            "channels": len(channels),
            "channels_with_epg": successful,
            "channels_without_epg": failed,
            "programmes": len(programmes),
            "execution_seconds": round(
                elapsed,
                2,
            ),
        },

        "sources": SOURCES,

        "channels": statuses,
    }

    OUTPUT_REPORT.write_text(
        json.dumps(
            report,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


# ============================================================
# MAIN
# ============================================================

def main() -> int:

    start_time = time.time()

    log.info(
        "=========================================="
    )

    log.info(
        "📺 EPG GENERATOR"
    )

    log.info(
        "=========================================="
    )

    log.info(
        "📅 Dias: %d",
        DAYS,
    )

    log.info(
        "🕐 Timezone: %s",
        TIMEZONE_OFFSET,
    )

    ensure_directories()

    # --------------------------------------------------------
    # Canais
    # --------------------------------------------------------

    channels = load_channels()

    if not channels:

        log.error(
            "❌ Nenhum canal encontrado."
        )

        return 1

    # --------------------------------------------------------
    # Programação
    # --------------------------------------------------------

    all_programmes: List[Programme] = []

    statuses: Dict[str, dict] = {}

    for index, channel in enumerate(
        channels,
        start=1,
    ):

        log.info(
            "🔎 [%d/%d] %s",
            index,
            len(channels),
            channel.name,
        )

        programmes, source = (
            fetch_channel_programmes(
                channel
            )
        )

        # ----------------------------------------------------
        # Filtra janela de tempo
        # ----------------------------------------------------

        now = now_brazil()

        limit = now + timedelta(
            days=DAYS
        )

        filtered = []

        for program in programmes:

            if (
                program.stop >= now
                and program.start <= limit
            ):

                filtered.append(
                    program
                )

        all_programmes.extend(
            filtered
        )

        statuses[
            channel.xmltv_id
        ] = {
            "name": channel.name,
            "site": channel.site,
            "site_id": channel.site_id,
            "source": source,
            "programmes": len(filtered),
        }

    # --------------------------------------------------------
    # Deduplicação
    # --------------------------------------------------------

    all_programmes = normalize_programmes(
        all_programmes
    )

    log.info(
        "📺 Programas encontrados: %d",
        len(all_programmes),
    )

    # --------------------------------------------------------
    # Gera XML
    # --------------------------------------------------------

    xml_data = build_xml(
        channels,
        all_programmes,
    )

    # --------------------------------------------------------
    # Validação
    # --------------------------------------------------------

    valid, channel_count, programme_count = (
        validate_xml(
            xml_data
        )
    )

    if not valid:

        log.error(
            "❌ Validação falhou."
        )

        log.error(
            "Canais: %d | Programas: %d",
            channel_count,
            programme_count,
        )

        # NÃO substitui um EPG válido existente.

        return 2

    # --------------------------------------------------------
    # Grava arquivos
    # --------------------------------------------------------

    atomic_write(
        OUTPUT_XML,
        xml_data,
    )

    write_gzip(
        xml_data,
        OUTPUT_GZ,
    )

    elapsed = time.time() - start_time

    write_report(
        channels,
        all_programmes,
        statuses,
        elapsed,
    )

    # --------------------------------------------------------
    # Resultado
    # --------------------------------------------------------

    log.info(
        "=========================================="
    )

    log.info(
        "✅ EPG GERADO COM SUCESSO"
    )

    log.info(
        "=========================================="
    )

    log.info(
        "📡 Canais: %d",
        len(channels),
    )

    log.info(
        "📺 Programas: %d",
        len(all_programmes),
    )

    log.info(
        "📄 %s",
        OUTPUT_XML,
    )

    log.info(
        "🗜️ %s",
        OUTPUT_GZ,
    )

    log.info(
        "📊 %s",
        OUTPUT_REPORT,
    )

    log.info(
        "⏱️ Tempo: %.2fs",
        elapsed,
    )

    return 0


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    try:

        sys.exit(
            main()
        )

    except KeyboardInterrupt:

        log.error(
            "⛔ Execução interrompida."
        )

        sys.exit(130)

    except Exception as exc:

        log.exception(
            "💥 Erro inesperado: %s",
            exc,
        )

        sys.exit(1)